
/**
 * @module pilotoFC
 */
import mainModule from './mainApp';

(() => {
  //var initInjector = angular.injector(['ng']);
  //var $http = initInjector.get('$http');

  function bootAngular(data) {
    data['swagger-api']['swagger-spec'] = require('./configuration/endpoints');
    data.languages.preferredLanguageData = require('./configuration/languages/preferredLanguage.json');
    angular.module('configModule', []).constant('CONFIG', data);

    angular.element(document).ready(function () {
      angular.bootstrap(document, [mainModule]);
    });
  }
  bootAngular(require('./configuration/default-config.json'));
})();