/* eslint-disable */

function mensajeriaEvents({client, chatCb}) {
  client.on('attention', (attention) => {
    console.log('attention');
    console.log(attention);
  });
  client.on('auth:failed', (auth) => {
    console.log('auth:failed');
    console.log(auth);
  });
  client.on('auth:success', (auth) => {
    console.log('auth:success');
    console.log(auth);
  });
  client.on('avatar', (avatar) => {
    console.log('avatar');
  });
  client.on('available', (available) => {
    console.log('available');
    console.log(available);
  });
  client.on('block', (block) => {
    console.log('block');
  });
  client.on('bosh:terminate', (bosh) => {
    console.log('bosh:terminate');
  });
  client.on('carbon:received', (carbon) => {
    console.log('carbon:received');
    console.log(carbon);
  });
  client.on('carbon:sent', (carbon) => {
    console.log('carbon:sent');
    console.log(carbon);
  });
  client.on('chat', chatCb);
  client.on('chat:state', (data) => {
    console.log('data');
    console.log(data);
  });
  client.on('connected', (connected) => {
    console.log('connected');
    console.log(connected);
  });
  client.on('credentials:update', (credentials) => {
    console.log('credentials:update');
  });
  client.on('dataform', (data) => {
    console.log('dataform');
  });
  client.on('disco:caps', (data) => {
    console.log('disco:caps');
  });
  client.on('disconnected', (data) => {
    console.log('disconnected');
    console.log(data);
  });
  client.on('geoloc', (data) => {
    console.log('geoloc');
  });
  client.on('groupchat', (data) => {
    console.log('groupchat');
  });
  client.on('id:ID', (data) => {
    console.log('id:ID');
    console.log(data);
  });
  client.on('iq:get:NAME', (data) => {
    console.log('iq:get:NAME');
  });
  client.on('iq:set:NAME', (data) => {
    console.log('iq:set:NAME');
  });
  client.on('jingle:accepted', (data) => {
    console.log('jingle:accepted');
  });
  client.on('jingle:hold', (data) => {
    console.log('jingle:hold');
  });
  client.on('jingle:incoming', (data) => {
    console.log('jingle:incoming');
  });
  client.on('jingle:localstream:added', (data) => {
    console.log('jingle:localstream:added');
  });
  client.on('jingle:localstream:removed', (data) => {
    console.log('jingle:localstream:removed');
  });
  client.on('jingle:mute', (data) => {
    console.log('jingle:mute');
  });
  client.on('jingle:outgoing', (data) => {
    console.log('jingle:outgoing');
  });
  client.on('jingle:remotestream:added', (data) => {
    console.log('jingle:remotestream:added');
  });
  client.on('jingle:remotestream:removed', (data) => {
    console.log('jingle:remotestream:removed');
  });
  client.on('jingle:resumed', (data) => {
    console.log('jingle:resumed');
  });
  client.on('jingle:ringing', (data) => {
    console.log('jingle:ringing');
  });
  client.on('jingle:terminated', (data) => {
    console.log('jingle:terminated');
  });
  client.on('jingle:unmute', (data) => {
    console.log('jingle:unmute');
  });
  client.on('message', (data) => {
    console.log('message');
    // Aparentemente los eventos chat y message son iguales
    console.log(data)
  });
  client.on('message:error', (data) => {
    console.log('message:error');
  });
  client.on('message:sent', (data) => {
    console.log('message:sent');
    console.log(data);
  });
  client.on('muc:available', (data) => {
    console.log('muc:available');
  });
  client.on('muc:declined', (data) => {
    console.log('muc:declined');
  });
  client.on('muc:error', (data) => {
    console.log('muc:error');
  });
  client.on('muc:invite', (data) => {
    console.log('muc:invite');
  });
  client.on('muc:join', (data) => {
    console.log('muc:join');
  });
  client.on('muc:leave', (data) => {
    console.log('muc:leave');
  });
  client.on('muc:subject', (data) => {
    console.log('muc:subject');
  });
  client.on('muc:unavailable', (data) => {
    console.log('muc:unavailable');
  });
  client.on('muc:destroyed', (data) => {
    console.log('muc:destroyed');
  });
  client.on('nick', (data) => {
    console.log('nick');
  });
  client.on('presence', (data) => {
    console.log('presence');
  });
  client.on('presence:error', (data) => {
    console.log('presence:error');
  });
  client.on('pubsub:event', (data) => {
    console.log('pubsub:event');
  });
  client.on('raw:incoming', (data) => {
    console.log('raw:incoming');
    console.log(data);
    // Se trata de los datos XML que envia MongooseIM
  });
  client.on('raw:outgoing', (data) => {
    console.log('raw:outgoing');
    console.log(data);
    // // Se trata de los datos XML que se envian a MongooseIM
  });
  client.on('reachability', (data) => {
    console.log('reachability');
  });
  client.on('receipt[:ID]', (data) => {
    console.log('receipt[:ID]');
    console.log(data);
  });
  client.on('replace[:ID]', (data) => {
    console.log('replace[:ID]');
  });
  client.on('roster:update', (data) => {
    console.log('roster:update');
  });
  client.on('roster:ver', (data) => {
    console.log('roster:ver');
  });
  client.on('sasl:abort', (data) => {
    console.log('sasl:abort');
  });
  client.on('sasl:challenge', (data) => {
    console.log('sasl:challenge');
  });
  client.on('sasl:failure', (data) => {
    console.log('sasl:failure');
    console.log(data);
  });
  client.on('sasl:success', (data) => {
    console.log('sasl:success');
  });
  client.on('session:bound', (data) => {
    console.log('session:bound');
  });
  client.on('session:end', (data) => {
    console.log('session:end');
  });
  client.on('session:error', (data) => {
    console.log('session:error');
  });
  client.on('session:started', (data) => {
    console.log('session:started');
  });
  client.on('stanza', (data) => {
     console.log('stanza');
  });
  client.on('stanza:acked', (data) => {
     console.log('stanza:acked');
  });
  client.on('stream:data', (data) => {
     console.log('stream:data');
     console.log(data);
  });
  client.on('stream:end', (data) => {
    console.log('stream:end');
  });
  client.on('stream:error', (data) => {
    console.log('stream:error');
  });
  client.on('stream:management:enabled', (data) => {
    console.log('stream:management:enabled');
  });
  client.on('stream:management:failed', (data) => {
    console.log('stream:management:failed');
  });
  client.on('stream:management:resumed', (data) => {
    console.log('stream:management:resumed');
  });
  client.on('stream:management:ack', (data) => {
     console.log('stream:management:ack');
  });
  client.on('subscribe', (data) => {
    console.log('subscribe');
  });
  client.on('subscribed', (data) => {
    console.log('subscribed');
  });
  client.on('tune', (data) => {
    console.log('tune');
  });
  client.on('unavailable', (data) => {
    console.log('unavailable');
  });
  client.on('unblock', (data) => {
    console.log('unblock');
  });
  client.on('unsubscribe', (data) => {
    console.log('unsubscribe');
  });
  client.on('unsubscribed', (data) => {
    console.log('unsubscribed');
  });
  client.on('attention', (data) => {
    console.log('attention');
  });
  client.on('attention', (data) => {
    console.log('attention');
  });
}
export default mensajeriaEvents;