/* eslint-disable */
import mensajeriaEvents from './mensajeria-events';
mensajeriaService.$inject = [];
/* eslint-disable */
function mensajeriaService() {
  let XMPP = require('stanza.io');
  let props = {
    conf: null
  };
  let result = {
    start        : start,
    connect      : connect,
    disconnect   : disconnect,
    init         : init,
    props        : props,
    sendMessage  : sendMessage,
    nuevoContacto: nuevoContacto,
    getContactos : getContactos
  };
  let default_conf = {
    jid      : '02101534151',
    password : 'pass',
    transport: 'websocket',
    // wsURL    : 'ws://52.213.132.189:5280/ws-xmpp'
    wsURL    : 'ws://movcli-prepro-app-load-balancer-995841810.eu-west-1.elb.amazonaws.com/ws-xmpp'
  };
  function init(conf , sessionStartedCb, chatCb) {
    props.conf = conf;
    let client = start(conf, XMPP);
    evSessionStarted(client, props, sessionStartedCb);
    evPresence(client);
    evChat(client);
    mensajeriaEvents({
      client,
      chatCb
    });
    client.connect();
    return client;
  }
  function getContactos(client, cb, data = props) {
    client.getRoster((err, roster) => {
      data.roster     = roster;
      data.presenceId = client.sendPresence();
      if (cb) cb(data);
    });
  }
  function nuevoContacto(client, jid) {
    client.subscribe(jid);
  }
  function connect(client) {
    client.connect();
  }
  function disconnect(client) {
    client.disconnect();
  }
  function evSessionStarted(client, props, cb) {
    client.on('session:started', function (jid) {
      props.jid = jid;
      getContactos(client, cb, props);
    });
  }
  function evPresence(client) {
    client.on('presence', (presence) => {
       console.log(presence.delay.from.bare);
       console.log(presence.from.bare);
    });
  }
  function evChat(client) {
    client.on('chat', function (msg) {
       console.log();
       console.log(msg);
    });
  }
  function sendMessage({client, to, body}) {
    client.sendMessage({
      to  : to,
      body: body,
      type: 'chat'
    });
  }
  function start(conf, xmpp = XMPP) {
    return xmpp.createClient(conf);
  }
  return result;
}
export default mensajeriaService;