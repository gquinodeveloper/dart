/* eslint-disable */
msjService.$inject = [];
/* eslint-disable */
function msjService() {
  let props = {
    last: 0,
    current: 0
  };
  let result = {
    props: props,
    setNumber: setNumber
  };
  function setNumber(num) {
    props.last = props.current;
    props.current = num;
  }
  return result;
}
export default msjService;