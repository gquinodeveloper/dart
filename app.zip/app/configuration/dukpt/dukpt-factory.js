dukptService.$inject = [];

function dukptService() {
  let Dukpt = require('@atmira/dukpt3des');
  let constant = {
    seed: ""
  };

  let result = {
    encrypt: encrypt,
    encryptForPinBlock: encryptForPinBlock,
    decryptForPinBlock: decryptForPinBlock,
    decrypt: decrypt,
    setSeed: setSeed,
    getSeed: getSeed,
    encryptForKey: encryptForKey,
    decryptForKey: decryptForKey,
    encryptForControlDigit: encryptForControlDigit,
    validateIpekCtrl: validateIpekCtrl
  };



  function encrypt(plain) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES'
    };
    var encrypted = "";
    var encryptionBDK = decryptForKey(localStorage.getItem('bm-key-bdk'));
    var ksn = decryptForKey(localStorage.getItem('bm-key-ksn'));

    var dukpt = new Dukpt(encryptionBDK, ksn);
    encrypted = dukpt.dukptEncrypt(plain, options);
    return encrypted;
  }

  function encryptForPinBlock(plain, account) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES',
      forPinBlock: true
    };
    var encrypted = "";
    var encryptionBDK = decryptForKey(localStorage.getItem('bm-key-bdk'));
    var ksn = decryptForKey(localStorage.getItem('bm-key-ksn'));
    ksn = ksn.substring(0, ksn.length - 4);
    ksn = ksn + account.substring(account.length - 4, account.length);
    //ksn =ksn + 'ABCD';
    
    //ksn = '5555544444E01234';
    ksn = ksn.toUpperCase();
    var ipek = decryptForKey(localStorage.getItem('bm-key-ipek'));
    var dukpt = new Dukpt(encryptionBDK, ksn);
    dukpt._deriveDukptSessionKeyForPinBlock(ipek);
    encrypted = dukpt.dukptEncrypt(plain, options);
    return encrypted;
  }
  
  function decryptForPinBlock(encrypted, account){
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES',
      forPinBlock: true
    };
    var plain = "";
    var encryptionBDK = decryptForKey(localStorage.getItem('bm-key-bdk'));
    var ksn = decryptForKey(localStorage.getItem('bm-key-ksn'));
    ksn = ksn.substring(0, ksn.length - 4);
    ksn = ksn + account.substring(account.length - 4, account.length);
    //ksn =ksn + '0002';
    
    var ipek = decryptForKey(localStorage.getItem('bm-key-ipek'));
    var dukpt = new Dukpt(encryptionBDK, ksn);
    dukpt._deriveDukptSessionKeyForPinBlock(ipek);
    plain = dukpt.dukptDecrypt(encrypted, options);
    return plain;
  }

  function decrypt(plain) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      decryptionMode: '3DES'
    };
    var encryptionBDK = decryptForKey(localStorage.getItem('bm-key-bdk'));

    var ksn = decryptForKey(localStorage.getItem('bm-key-ksn'));
    var decrypted = "";

    var dukpt = new Dukpt(encryptionBDK, ksn);
    decrypted = dukpt.dukptDecrypt(plain, options);
    return decrypted;
  }

  function encryptForKey(plain) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES'
    };
    var encrypted = "";
    var udid = "";
    var encryptionBDK = "11111111111111111111111111111111";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      udid = encryptionBDK;
    }
    if (udid.length > encryptionBDK.length) {
      udid = udid.substring(0, encryptionBDK.length);
    } else if (udid.length < encryptionBDK.length) {
      for (let i = 0; i < (encryptionBDK.length - udid.length); i++) {
        udid = "0" + udid;
      }
    }

    encryptionBDK = udid;
    var ksn = '9876543210E00000';

    var dukpt = new Dukpt(encryptionBDK, ksn);
    encrypted = dukpt.dukptEncrypt(plain, options);
    return encrypted;
  }

  function decryptForKey(plain) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      decryptionMode: '3DES'
    };
    var udid = "";
    var encryptionBDK = "11111111111111111111111111111111";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      udid = encryptionBDK;
    }
    if (udid.length > encryptionBDK.length) {
      udid = udid.substring(0, encryptionBDK.length);
    } else if (udid.length < encryptionBDK.length) {
      for (let i = 0; i < (encryptionBDK.length - udid.length); i++) {
        udid = "0" + udid;
      }
    }

    encryptionBDK = udid;

    var ksn = '9876543210E00000';
    var decrypted = "";

    var dukpt = new Dukpt(encryptionBDK, ksn);
    decrypted = dukpt.dukptDecrypt(plain, options);
    return decrypted;
  }

  function validateIpekCtrl(ipek, ctrl) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES'
    };
    var ksn = decryptForKey(localStorage.getItem('bm-key-ksn'));
    var dukpt = new Dukpt(ipek, ksn);

    var encrypted = dukpt.dukptEncrypt("0000000000000000", options);
    var digits = encrypted.substring(0, 6);
    return (ctrl == digits);
  }

  function encryptForControlDigit(key) {
    let options = {
      inputEncoding: 'hex',
      outputEncoding: 'hex',
      encryptionMode: '3DES'
    };
    var ksn = '0000000000000000';

    var dukpt = new Dukpt(key, ksn);
    var encrypted = dukpt.dukptEncrypt('0000000000000000', options);
    return encrypted;
  }
  

  function setSeed(seed) {
    constant.seed = seed;
  }

  function getSeed() {
    return constant.seed;
  }
  return result;
}

export default dukptService;