function pushNotificationConfig() {

  var pushConfig = require("./push-notification-config.json");

  window.push = window.PushNotification.init({
    android: {
      // project number in the Google Developer Console
      senderID: pushConfig.senderID,
      sound: true,
      vibrate: true
    },
    ios: {
      alert: "true",
      badge: "true",
      sound: "true",
      clearBadge: true
    }
  });

  window.push.on('registration', function(data) {
    window.deviceToken = data.registrationId;
  });

  window.push.on('error', function(e) {
    console.log(e.message); // eslint-disable-line
  });
}

export default pushNotificationConfig;
