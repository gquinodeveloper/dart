/*
  Crea un servicio value de nombre "historyLog" de Angular que mantiene las ultimas 5 rutas visitadas a modo de historial
 */

historyRun.$inject = ['$rootScope', 'historyLog'];

function historyRun($rootScope, historyLog) {

  let deregisterationStateChangeSuccess = $rootScope.$on('$stateChangeSuccess',
    function (ev, to, toParams, from) {
      historyLog.push(from.name || null);
      historyLog.shift();
    });

  $rootScope.$on('$destroy', function () {
    deregisterationStateChangeSuccess();
  });
}

export default angular.module('HistoryLogModule', [])
  .value('historyLog', [null, null, null, null, null])
  .run(historyRun)
  .name;

