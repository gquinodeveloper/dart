dynamicLanguaje.$inject = 'tmhDynamicLocaleProvider';

function dynamicLanguaje(tmhDynamicLocaleProvider) {
  tmhDynamicLocaleProvider.localeLocationPattern('/public/vendor/i18n/angular-locale_{{locale}}.js');
}

export default dynamicLanguaje;