ionicCacheConfig.$inject = ['$ionicConfigProvider'];

function ionicCacheConfig($ionicConfigProvider) {
  $ionicConfigProvider.views.maxCache(0);

}

export default ionicCacheConfig;