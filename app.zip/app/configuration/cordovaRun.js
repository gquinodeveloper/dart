cordovaRun.$inject = ['$window', '$ionicPlatform', '$rootScope', '$state', '$ionicHistory', '$ionicPopup', '$ionicLoading', '$timeout'];

function cordovaRun($window, $ionicPlatform, $rootScope, $state, $ionicHistory, $ionicPopup, $ionicLoading, $timeout) {
  var warnedExit = false;
  $ionicPlatform.ready(function () {
    if ($window.cordova && $window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if ($window.StatusBar) {
      StatusBar.styleDefault();
    }
    if(screen.availWidth < 640 || screen.availHeight < 640){
      screen.orientation.lock('portrait');
    }
    // INICIALIZAMOS VARIABLES DE IMPRESORA
    localStorage.setItem('connectedPrinter', 0);
    localStorage.setItem('printerHasPaper', 0);

    if (!$ionicPlatform.is('browser')) {
      cordova.plugins.notification.local.cancel(1);
      $window.broadcaster.addEventListener("DatecsPrinter.connectionStatus", function (e) {
        if(!!e){
          let correctJson = (e.userdata.replace(/(['"])?([a-z0-9A-Z_]+)(['"])?:/g, '"$2": '));
          let status = JSON.parse(correctJson);
          if (!status.isConnected && localStorage.getItem('connectedPrinter') == '1') {
            localStorage.setItem('connectedPrinter', 0);
            cordova.plugins.notification.local.schedule({
              id: 1,
              smallIcon: 'res://ic_stat_print_disabled',
              icon: 'res://icon',
              title: 'Bancamía Corresponsales',
              text: 'Impresora Desconectada',
              foreground: false,
              sticky: false,
              vibrate: false,
            });
          } else if (status.isConnected && localStorage.getItem('connectedPrinter') == '0'){
            localStorage.setItem('connectedPrinter', 1);
            cordova.plugins.notification.local.schedule({
              id: 1,
              smallIcon: 'res://ic_stat_print',
              icon: 'res://icon',
              title: 'Bancamía Corresponsales',
              text: 'Impresora Conectada',
              foreground: false,
              sticky: false,
              vibrate: false,
            });
          }
          if (!status.hasPaper) {
            localStorage.setItem('printerHasPaper', 0);
          } else {
            localStorage.setItem('printerHasPaper', 1);
          }
        }
      });
    }
  });

  $rootScope.lan = "ES";

  $rootScope.doNavigate = function (target) {
    $state.go(target);
  };

  $rootScope.$on('$stateChangeSuccess', (event, toState, toParams, fromState) => {
    $rootScope.$emit('metrics-pagina-vista', toState.url, fromState.url);
  });

  $rootScope.$on('$stateChangeStart', (event, toState, toParams, fromState) => {
    $rootScope.$emit('metrics-navegacion-hacia', toState.url, fromState.url);
  });

  $rootScope.$on('$stateChangeError', (event, toState, toParams, fromState, fromParams, error) => {
    $rootScope.$emit('metrics-error-navegacion', toState.url, fromState.url, error);
  });

  $rootScope.$on('$stateNotFound', (event, unfoundState, fromState) => {
    $rootScope.$emit('metrics-error-pagina-no-encontrada', unfoundState.to, fromState.url);
  });


  $ionicPlatform.registerBackButtonAction(function (event) {
    switch(document.location.hash){
      case "#!/login":
        var alertPopup = $ionicPopup.confirm({
          template: '¿Deseas salir de la aplicación?',
          okText: 'Si',
          cancelText: 'No',
        });
        alertPopup.then((e) => {
          if(!!e){
            ionic.Platform.exitApp();
          }
        });
        break;
      case "#!/changeValidate":
        $ionicHistory.goBack();
        break;
      default:
        event.preventDefault();
        break;
    }
  }, 100);
}

export default cordovaRun;
