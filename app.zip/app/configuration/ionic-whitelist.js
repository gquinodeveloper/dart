ionicWhitelistConfig.$inject = ['$sceDelegateProvider', '$compileProvider'];

function ionicWhitelistConfig($sceDelegateProvider, $compileProvider) {
  // para poder insertar html en tiempo de ejecución
  $sceDelegateProvider.resourceUrlWhitelist([
    'self',
    '*',
    '**',
    'http://**',
    'http://*',
    'https://*',
    '*://*'
  ]);
  $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|mailto|tel|file|blob|content|http):|data:image\//);
}

export default ionicWhitelistConfig;