cyptojsService.$inject = [];

function cyptojsService() {
  let CryptoJS = require("crypto-js/crypto-js");
  let result = {
    encryptPassphrase: encryptPassphrase,
    encryptOTP: encryptOTP,
  };

  function encryptPassphrase(passphrase) {
    return CryptoJS.MD5(passphrase).toString().substr(0, 16);
  }

  function encryptOTP(otp, passphrase) {
    let key = CryptoJS.enc.Utf8.parse(passphrase);
    let iv1 = CryptoJS.enc.Utf8.parse(passphrase);
    let encryptedOTP = CryptoJS.AES.encrypt(otp, key, {
      keySize: 16,
      iv: iv1,
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    });
    return encryptedOTP + "";
  }

  return result;
}
export default cyptojsService;