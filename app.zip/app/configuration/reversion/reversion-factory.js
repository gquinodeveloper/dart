/* eslint-disable */
reversionService.$inject = ['$ionicPopup', '$ionicLoading', 'swagger', '$state', '$rootScope'];
/* eslint-disable */
function reversionService($ionicPopup, $ionicLoading, swagger, $state, $rootScope) {
  let constant = {
    data: {},
    popup: null
  };
  let result = {
    doReversion: doReversion,
    setReversionData: setReversionData,
    clearReversionData: clearReversionData
  };

  function setReversionData(data) {
    constant.data = data;
    localStorage.setItem("bm-persistent-tx-data", JSON.stringify(data));
  }

  function doReversion() {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });

    var endpoint = null;
    var data = {};
    if (!!constant.data.operacion && !!constant.data.operacion.codAutorizacion && constant.data.operacion.codAutorizacion != "") {
      switch (constant.data.tipoOp + "") {
        case "1":
          endpoint = swagger.api.corresponsales.reversionDeposito.post;
          data = {
            depositoARevertirDTO: {
              deposito: constant.data,
              operacion: constant.data.operacion
            }
          };
          break;
        case "2":
          endpoint = swagger.api.corresponsales.reversionPago.post;
          data = {
            pagoARevertirDTO: {
              pago: constant.data,
              operacion: constant.data.operacion
            }
          };
          break;
        case "4":
          endpoint = swagger.api.corresponsales.reversionRetiro.post;
          data = {
            retiroARevertirDTO: {
              retiro: constant.data,
              operacion: constant.data.operacion
            }
          };
          break;
      }
    } else {
      switch (constant.data.tipoOp + "") {
        case "1":
          endpoint = swagger.api.corresponsales.reversionDepositoError.post;
          data = {
            depositoARevertirDTO: {
              deposito: constant.data,
              operacion: null
            }
          };
          break;
        case "2":
          endpoint = swagger.api.corresponsales.reversionPagoError.post;
          data = {
            pagoARevertirDTO: {
              pago: constant.data,
              operacion: null
            }
          };
          break;
        case "4":
          endpoint = swagger.api.corresponsales.reversionRetiroError.post;
          data = {
            retiroARevertirDTO: {
              retiro: constant.data,
              operacion: null
            }
          };
          break;
      }
    }
    try {
      endpoint.call(data).then(() => {
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
          title: "Información",
          template: "Por un error inesperado se ha procedido a realizar el extorno de esta transacción.",
          okText: "Aceptar",
        });
        constant.popup = alertPopup;
        alertPopup.then(() => {
          constant.popup = null;
          $state.go("menu.homeCustomer");
        });
        clearReversionData();
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'evento: Error de extorno',
          tag: 'Extorno',
          data: [{
              name: "err",
              value: JSON.stringify(err)
            },
            {
              name: "reversion",
              value: JSON.stringify(data)
            }]
        });
        var alertPopup = $ionicPopup.alert({
          title: "Información",
          template: err.data.message,
          okText: "Aceptar",
        });
        constant.popup = alertPopup;
        alertPopup.then(() => {
          constant.popup = null;
          $state.go("menu.homeCustomer");
        });
//        if (!!err.data && (err.data.code + "" != "500" && err.data.code + "" != "401" && err.data.code + "" != "403" && err.data.code + "" != "409")) {
//          clearReversionData();
//        }
        if (!!err.data && (err.data.code + "" == "200" || err.data.code + "" == "400")){
          clearReversionData();
        }
      })
    } catch (e) {
      $ionicLoading.hide();
      console.log(e);
      var alertPopup = $ionicPopup.alert({
        title: "Información",
        template: "Por un error inesperado se ha procedido a realizar el extorno de esta transacción.",
        okText: "Aceptar",
      });
      constant.popup = alertPopup;
      alertPopup.then(() => {
        constant.popup = null;
        $state.go("menu.homeCustomer");
      });
    }
  }

  function clearReversionData() {
    let data = constant.data;
    constant.data = {};
    localStorage.removeItem("bm-persistent-tx-data");
    return data;
  }

  return result;
}
export default reversionService;