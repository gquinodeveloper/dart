loginConfig.$inject = ['$logProvider'];

function loginConfig($logProvider) {
  $logProvider.debugEnabled(require('./default-config').enableLog);
}

export default loginConfig;
