import pushNotificationConfig from '../push-notification';
(()=>{
  document.addEventListener('deviceready', deviceready, false);
  function deviceready(){
    pushNotificationConfig();
  }
})();
