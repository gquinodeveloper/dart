/* eslint-disable */
txFailureService.$inject = ['$ionicPopup', '$ionicLoading', 'swagger', '$state', '$rootScope', 'printerService', '$filter', 'reversionService'];
/* eslint-disable */
function txFailureService($ionicPopup, $ionicLoading, swagger, $state, $rootScope, printerService, $filter, reversionService) {
  let constant = {
    data: {},
    texts: {
      info: "Información",
      ok: "Aceptar",
      noConection: "No es posible establecer conexión. Vuelva a intentar acceder transcurridos unos instantes."
    },
    popup: null
  };
  let result = {
    txFailureLauncher: txFailureLauncher
    //printLastTx: printLastTx,
    //printLastTxErr: printLastTxErr
  };

  function validateConection() {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  }

  function errorLogout() {
    $ionicLoading.hide();
    var alertPopup = $ionicPopup.alert({
      title: constant.texts.info,
      template: constant.texts.noConection,
      okText: constant.texts.ok,
    });
    alertPopup.then(() => {
      $state.go('login');
      return false;
    });
    $state.go("login");
    return false;
  }

  function errorLog(data, tag) {
    $rootScope.$emit('metrics-custom', {
      event: 'txFailure',
      tag: 'txFailure - ' + tag,
      data: [{
        name: "msg",
        value: JSON.stringify(data)
      }]
    });
  }

  function getTxType(type) {
    switch (type + '') {
      case '1':
        return 'Depósito';
      case '2':
        return 'Pago de obligación en efectivo';
      case '4':
        return 'Retiro';
    }
  }

  function getAmmountLabel(type) {
    switch (type + '') {
      case '1':
        return 'Valor depósito:';
      case '2':
        return 'Valor pagado:';
      case '4':
        return 'Valor retirado:';
    }
  }
  function getaccOrObl(type) {
    switch (type + '') {
      case '1':
        return 'Cuenta:';
      case '2':
        return 'Nº Créd.:';
      case '4':
        return 'Cuenta:';
    }
  }

  function getPayType(data) {
    var type = "Tipo: Pago total.";
    if (data.monto * 1 > data.obligacion.min) {
      type = "Tipo: Próximas cuotas.";
    }
    return `${type}{br}`;
  }

  function setIndent(lengthTitle, lengthData) {
    var line = 32;
    return new Array(line - (lengthTitle + lengthData)).join(' ');
  }

  function printTx(tx) {
    var ticketLines = [];
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    var t = new Date(tx.fechaTxTimestamp * 1);
    var day = $filter('date')(t, 'dd/MM/yyyy h:mm a');
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: "CORRESPONSAL{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: config.cabecera.codCorresponsal + "{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: tx.corresponsalNombre + "{br}"});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "{left}"});
    ticketLines.push({text: "Tipo de transacción:{br}"});
    ticketLines.push({text: getTxType(tx.tipoTX) + "{br}"});
    ticketLines.push({text: "{br}{center}{b}TRANSACCIóN EXITOSA{/b}{br}{br}"});
    ticketLines.push({text: day});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "T:"+ setIndent(2,tx.codTerminal.length) + tx.codTerminal});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "NO:"+ setIndent(3,tx.numTx.length) + tx.numTx});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "NA:"+ setIndent(3,(!!tx.codAut ? tx.codAut.length : 1)) + (!!tx.codAut ? tx.codAut : '')});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: getaccOrObl(tx.tipoTX) + setIndent(getaccOrObl(tx.tipoTX).length,tx.numCta.length) + tx.numCta});
    ticketLines.push({text: "{br}"});
    if (tx.tipoTX + '' == '2') {
      ticketLines.push({text: "Nº de cuota:"+ setIndent(12,tx.cuota.length) + tx.cuota });
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "Fecha de vcto.:"+ setIndent(15,10) + tx.fec});
      ticketLines.push({text: "{br}"});
    }
    ticketLines.push({text: getAmmountLabel(tx.tipoTX) + setIndent(getAmmountLabel(tx.tipoTX).length,($filter('number')(tx.monto, 2)).length + 3) +"S/ " + $filter('number')(tx.monto, 2)});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "Costo Transacción:"+ setIndent(18,7) +"S/ " + (!!tx.costoTx ? $filter('number')(tx.costoTx, 2) : '0.00')});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "{b}" + tx.titular + "{/b}"});
    ticketLines.push({text: "{br}{br}"});
    if (tx.tipoTX + '' == '4') {
      ticketLines.push({text: "{center}{s}Con el ingreso del código{br}{center} enviado a su celular "});
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "{center}"});
      ticketLines.push({text: "acabado en " + tx.telTitular});
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "{center}"});
      ticketLines.push({text: " usted autorizó esta transacción{/s}"});
      ticketLines.push({text: "{br}{br}"});
    }
    ticketLines.push({text: "{center}{s}" + printerService.disclaimer + "{/s}"});
    ticketLines.push({text: "{br}{br}{br}{br}{br}{br}{br}"});
    printerService.connectForTicket(ticketLines);
  }

  function printLastTxErr(tx) {
    printerService.printErrorTicket(getTxType(tx.tipoTX), tx.rpta);
  }
  function printLastTx(tx) {
    var ticketLines = [];
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    var t = new Date(tx.fechaTxTimestamp * 1);
    var day = $filter('date')(t, 'dd/MM/yyyy h:mm a');
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: "CORRESPONSAL{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: config.cabecera.codCorresponsal + "{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: tx.corresponsalNombre + "{br}"});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "{left}"});
    ticketLines.push({text: "Tipo de transacción:{br}"});
    ticketLines.push({text: getTxType(tx.tipoTX) + "{br}"});
    ticketLines.push({text: "{br}{center}{b}TRANSACCIóN EXITOSA{/b}{br}{br}"});
    ticketLines.push({text: day});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "T:"+ setIndent(2,tx.codTerminal.length) + tx.codTerminal});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "NO:"+ setIndent(3,tx.numTx.length) + tx.numTx});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "NA:"+ setIndent(3,(!!tx.codAut ? tx.codAut.length : 1)) + (!!tx.codAut ? tx.codAut : '')});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: getaccOrObl(tx.tipoTX) + setIndent(getaccOrObl(tx.tipoTX).length,tx.numCta.length) + tx.numCta});
    ticketLines.push({text: "{br}"});
    if (tx.tipoTX + '' == '2') {
      ticketLines.push({text: "Nº de cuota:"+ setIndent(12,tx.cuota.length) + tx.cuota });
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "Fecha de vcto.:"+ setIndent(15,10) + tx.fec});
      ticketLines.push({text: "{br}"});
    }
    ticketLines.push({text: getAmmountLabel(tx.tipoTX) + setIndent(getAmmountLabel(tx.tipoTX).length,($filter('number')(tx.monto, 2)).length + 3) +"S/ " + $filter('number')(tx.monto, 2)});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "Costo Transacción:"+ setIndent(18,7) +"S/ " + (!!tx.costoTx ? $filter('number')(tx.costoTx, 2) : '0.00')});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "{b}" + tx.titular + "{/b}"});
    ticketLines.push({text: "{br}{br}"});
    if (tx.tipoTX + '' == '4') {
      ticketLines.push({text: "{center}{s}Con el ingreso del código{br}{center} enviado a su celular "});
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "{center}"});
      ticketLines.push({text: "acabado en " + tx.telTitular});
      ticketLines.push({text: "{br}"});
      ticketLines.push({text: "{center}"});
      ticketLines.push({text: " usted autorizó esta transacción{/s}"});
      ticketLines.push({text: "{br}{br}"});
    }
    ticketLines.push({text: "{center}{s}" + printerService.disclaimer + "{/s}"});
    ticketLines.push({text: "{br}{br}{br}{br}{br}{br}{br}"});

    localStorage.setItem("bm-last-ticket", JSON.stringify(ticketLines));

    //printerService.printLast();
  }


  function txFailureLauncher(tx) {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    reversionService.setReversionData(tx);
    localStorage.setItem("bm-persistent-tx-data", JSON.stringify(tx));

    if (!validateConection()) {
      errorLog(tx, 'no connection');
      errorLogout();
      return false;
    }
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.transaccion.get.call({
      udid: udid,
      numTx: tx.idTx
    }).then((data) => {
      $ionicLoading.hide();
      localStorage.removeItem("bm-persistent-tx-data");
      if (data.data.estadoTx + '' == '0'){
        //printTx(data.data);
        return false;
      } else {
        //printerService.printErrorTicket(getTxType(data.data.tipoTX), data.data.rpta);
        return false;
      }
    }).catch((err) => {
      errorLog(err, 'response error');
      errorLogout();
    });
  }


  return result;
}
export default txFailureService;
