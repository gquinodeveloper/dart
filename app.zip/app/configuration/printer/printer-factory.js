/* eslint-disable */

printerService.$inject = ['$ionicPopup', '$ionicLoading', '$window', '$state', 'reversionService', '$filter', '$rootScope', 'authFactory', '$ionicPlatform'];
/* eslint-disable */
function printerService($ionicPopup, $ionicLoading, $window, $state, reversionService, $filter, $rootScope, authFactory, $ionicPlatform) {
  let constant = {
    printers: ['DPP-250'],
    connected: '',
    logoW: 301,
    logoH: 193,
    logoB64: "/9j/4AAQSkZJRgABAAEAYABgAAD//gAfTEVBRCBUZWNobm9sb2dpZXMgSW5jLiBWMS4wMQD/2wCEAAUFBQgFCAwHBwwMCQkJDA0MDAwMDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0BBQgICgcKDAcHDA0MCgwNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDf/EAaIAAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKCwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoLEAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+foRAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/AABEIAMEBLQMBEQACEQEDEQH/2gAMAwEAAhEDEQA/APsugCrNf21s2yaWONuuHdVOPXBINWoSlrGLa8k2ZupCDtKUU+zaRXGs2BOBcwEj/prH/wDFVfsqi+xL/wABf+RHtqXScP8AwJf5lZ769Oox28MCvYPCZHud44cltqqv8XAU8dQ2cjac2oQVNycrVFKyhbp1bfTr93mZudT2sYRgnScbud9nrZJden3+Rt1zHWFABQAUAFABQAUAFABQBjaFeXt7AZNRt/scvmMFj3h8oPusSOhPIx3xnABFdFaMKcuWlLnVld2tr1Ry0J1KkXKtD2cruyvfTo/69TZrnOoKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoA+f/G7aG+uW8hYM3n7dQBEuAq+WvQD+6G/1eSTX1GEVdUJJKy5b0vh3d3+dtz4zHPDPEwbevPat8Wysu3a/wAJ0EN94FhG2NInJ6D7PcSMcem6Nj/SuVwxz3cl/wBvwS/Bo7Yzy2OkVF/9uTk/xizqINZkGuwaVahUsDp4nCCPYQS5VOCAUAUKAhAxkgjOMcbpL2Eq07+09ry3vfpd+ut9T0I1n9Zhh6dlS9jz2ta2tl2a0tpY1vEOtvon2QogcXV5FbNnI2rIHJZcdwVGM8dawoUlW57u3JCU16q2n4nTiK7w/s7K/PUjB+SlfVeehznivxxJok5t7KD7R9mEcl25zsiSRgqrwR+8bcCM8AEHDc7evDYRVo81SXLzXUF1bSu36K3/AA3XhxeOeHlyUoc3JZ1H0ipOyWn2nf8A4D1t6IGBG4dMZz7V5Pke15nj0CXPiGO716fUbmwtIZZVtlhYpH5UXAdlJ+feeCMAlgR3AHvtxw7p4WNKE5tRcuZXfNLon0t+R8zFTxKqYyVedOnGUlBRdo8serXW/wCL+46Dwfrd9d6DJqd6wnlTz2j+UKSsS8BtoHJZW5xnBrlxNKEMQqNNcqfKn11k+l/Jo7cHXqTw0q9V80lztaW0itnbzTJpPGnk6Nb6kYt93egLDbpn55SSuB1O0Yye+CBnJFSsLetOinaENZSfSO/3lPG8uHhX5b1KmkYLrK9tOtuv4Gv4S1yTX7AXU6CKdXeKVFzgOhwcZJI4xwSeawxNJYepyQd42TT8mdOErvE0lUmrSTcZJbJpmX4l1fUTeQ6NohRLqRGnlkkGViiB2jsRl2yOhPTpnI2oUqahLEYi7gnyxS0bk9fwRhia1X2kcLhLKo05Sk1pGK0Xfd6bGh4a1i71LTWub6MQ3ETSo4CsqkxkjcA3Y9DyRkHBHQZV6UKdRQpO8WotbN+900NsNWnVoupWjyzi5J6NL3eqv/V7jfBOqXOtaTDe3hDSyGTJChQQsrqOBx0GOPT1p4unGjWlTp6RVut90mLBVZ16EatX4nzdLbSa/Q828X+NZbi8msrO4ks0s9yARDM1xchioVSpIEQPJyRkA5DMVWvXw2EUYRqTipudnr8MINXu7/a/rRXZ4WMxspVJUqU5U1TuvdXvTmnayt9n7uu7sju9S1+90dNL+0iNTeSRw3ZYcq7ovKkMFXDbicgjj0zXmU6MKrrcl/cTlC3VJ9dLvSx7FSvUoLD86S55RjUv0bS21stb3H2PiDUdcnWTTII101ZNrXFwWDSqDhzAi4IHBCs/BPXGCAp0adCNq0n7W2kY2tF9OZv8UhwxFXESTw8IqinZzndOSW7gl+DZy8CXHid7zWJNQubCytZZI4BAxRNkQG6RhnDBu4xknIzjArtfLhlTw6pQnUkk5cyu7y6LsefFTxbq4mVadOlCTUOV2Vo7yfe/4/gdJ8PdSvdW003N9J5xMrrExVVPloAvzBQOSwY5OTXHjacKVXkpLl91NrXd66fKx3ZfUqVqPtK0ub3mouyTsrLW3W9zuq809cKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKAPPtdtFufEemKEU+WlzJJkKcqECrnuQGPGRjJ45zj1KMnDDVtXq4Jb73u/wPFrwU8Xh1ZaKpJ7bWsr/ADO+SNI+EUL9AB/KvMu+p7KSWyseZay+qadr8lxp9o901zZxwxSHIiiIkJYyNjGAQCVLKTketexSVKeHUKtRQUZuTX2nppZfrqeBWdalinOjTc3OmoxltGOt3d/ja6IvFmna21hYKD9uvIrxZZGjQKith/LOABiNN20sQAfvNiqw06CqVX8FNwaSbu7aX+b3t9xOLp4h0qK/iVI1FJuKSSevL6RV7XfqzbtPBixaPcWEz+Zd36s9xMxJ3TsMg54OxHwQO/JI5Irmlim60KsVaFNpRiukV+rR1wwSjQnRk71KibnJ9Zvr6J7f8E56O18Taxbrb3SfYkson5ST57uZY2WMHa2PKJ27wx2tknnI2dTlhqMnKD53OS3WlOLab6fFva2q/PiUMZXioVF7NU4vaWtSSTUVo/h2vfR/lmaFoWpeILWDTr2J7HTbFcNGwKvczjJyQQPkDnPQgnPUn5d61alh5yq0pKdWb0a1UI/52/rvhQoVsTCFCrF06NNaxaadSer+6/y+e3SeF7W5TwtJZeTJDcJFdxhJEKszt5jKVBxkEuFBPUg1x4iUfrSqcycXKDundJKyd/uud2FjNYJ0uWUZqNSKTVm2+Zqy+din4E8MXSiHUdWDI9tH5VpA2QYlOQ7spxh3JOAeQOv8ONMZiIe9SoWtJ3nJfafRJ9l/XUywGFmuSviU04R5acHpyrW7a7u/9aWWSw13SLm8sNKhQ2+oTGeO5LBRbmUYlJXOSVwNgA4wCAc4Ap0KsadWtJ81OPK4W+Pl+H7+o3TxNCdWjh4rkqy51O9uTm+LTuun67DFW58GanJcSQXepx3NrBGk0SmVxJCu11kycqJD8+cntgNg4fu4ukoKUKTjOTcW+VWk7pr02/yJtPAVpTlCpWU6cEpRXM7xVmpdrvX/ADNmzg1jV/tGoXimzDW0kNrabs4LrnzZsYBckAKDgqM8L1bnk6NLkpU3z2mpTna2z2j5fn5nVCOIrc9aqnTvCUadO99Wvil57JLp5dcjwh/bksFrZLCdMtLIATPKmZZyGJZI0dRsVuQWxkZJDE8HfE+wUp1Ob2k5/CovSOm7aerXb8Dmwf1lxp0lH2NOn8TkvenrdpJrRPq/uZl6TrOneGZLsXtu8mrG8nZFWAtLIHb5PLk2kBCDnhhwSQDkZ2qUqmIUPZySo8kU/eslZa3Xc56NalhHUVWDeI9pNpKF5Su9OWVtn6/J31veNILzXNL0/wC2QmCWa9jEsSBnMaSCRQTgZBCEbhj7xx7VnhXChVq+zlzRjTdm7K7Vn+e3kbY2NTEUaPtY8spVYqUVd8qlzJX+Vr+Z6ebUWtoba1UII4ikajoMLhR/Lv8AjXjc3NPnm73d2/nqe/y8kOSmrWjaK7aaHj3h7QtS1y0h0q9iew02yJMykFZLqXez45A/dAtyRkEjqWxs9+vWpUJyr0pKdWfwvdQja336f11+Zw9CtiIRw9WLp0afxLaVSV27f4df6drdr8PIJbPSRbTxSQPDNKpEild2XLBlBAyvzYB9Qa87GtSq88JJpxi9He2lrPz0PUy6MqdBU5xcXGUlqrX1vdeWtvkdzXmnrhQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQA3y13B8DcAQGwMgHBIz1wSASO+B6U7u1unYVle9te46kMKACgAoAKACgAoAKACgAoAKACgBpRSQxAJXocDI7cHtxTvbQVlv2HUhhQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFADXcRqWYgKoJJPQAckn6UeQbHxX4w+M2sa1cumlzPYWKsRGsYCyuoPDyScsGbrtRgqjA+YgsfqqOCp00vaLml1vsvJL/M+SrY2pOTVN8sOltG/Nv/ACOLtvH/AIjt3EkWo3hYHOGmeQfirllI9iMV1PD0WrOEfuS/I5FiKyd1OX3t/mex/tAa/fwXdvpMUjxWUlsJnVSVEshkkQq5GNwRUUhTkAtkjODXmZfTi4yqNJyUrLyVk9PW56uY1JqUaSbUeW783drX0scN8Gtdv9P8QW1jbu7W12zJNDklCBG7b9vQMhG7cOcAg8E114ynGVKU2lzR2fXdafM48FUlGrGEW+WWjXTZ6/I+4K+TPrwoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKAPJvE3xl0Hw5I9sjPfXMZIZIACisOzSsQnXg7N5HcZ4r0aWDq1EpNKMe7/y3++x5lXG0qTcVeUl0W337fdc89b9o5Q2F0s7fU3YB/L7MR+tdv9nf9PP/ACX/AO2OL+0v+nf/AJN/9qdp4Y+N2keILiKymimsrid1jjDASRs7kKq70+YEk4yyKo7kCuWrgqlJOaakkrvo7Lyf+Z1UsdTqtQacZN2XVXfmv8j2ZmCAsxAAGSTwAPU15Z6x4x4j+OWh6K7QWYk1GVDgmLCxAjqPNb731RXU9jXqU8DUmrytBee/3L9bHk1cfSpu0Lzflovv/wArnGp+0ahbD6Yyp6i7BP8A3ybdR/49XV/Zz6VP/Jf/ALY5VmS609P8X/2p6p4S+KWieLnFtbyNb3bDiCcbWb12MCUf6Bt+BnbivPq4WpQXM1ePdfr1X5Ho0cXTrvli7S7PT7uj/M9GrhO8+fL79oCysbiW2NjOxhkeMkSoASjFcj5e+M17UcvlJKXOtUns+p4ksxjFuPI9G1uuh22i/FjRNT0p9YuZPsKQyGJ45Tuk34DKEVAWk3KQRtX+9nG0muSeEqQmqUVzNq6a0VvO+x1wxdOdN1ZPlSdmnvfytucBqX7RFlBIVsLGW5QfxSyrBn6KEmOPqQfYV2Ry6TXvzS9Ff9UcUsyinaEG15u36M6Lwf8AG3TfE10mn3ML2FxOwSLLiWJmP3V3hUKsx4GUCk4G7JArGtgp0YucWpJb6Wa+Wv5m9HHQqyUJJwb0Wt19+n5Gn8TfiHD4MjWylgedr+CYKyuqhCAE5yCTy4PHpWeGw7rvmTS5Wunz/Q0xWJWHXI4t8ydtbW6fqfDdfWnx57b8PfihpvgnTzaSWDT3DyM8kytGCwOAq8ruwoHAJIzkjrXk4jCzrz5lOySslqevhsVDDw5HC7u23oerfF7xRodhPDpWt6e2obohPHIkgiaPc7oQrDDjOzJAO08ZBIFedg6VSSdSjPk1s1a99E9tup6WMq0oNU60ObS6adratb79DC+FXiTwo+qiy0vTpbG8uFYRSyyGfO1Wd0DMxMeVUn5Rh8YJ6A7YqnXUOapNSit0lbfRPzMcJVoc/JTg4yezbv0u15afee7+IvE2n+FLb7bqkvkQlhGpCu5ZyGYKFRWOSFJycAY5IryKdKdZ8lNXe/RafM9mpVhQjz1HZbbN6/I8X1H9ofTYG22NnPcAfxSOkIP0AEpx9QD7V6kcvm/jkl6Jv/I8mWZQXwQb9Wl/mZUf7Ryk4fSyo9VuwT+Rtl/nWn9ndqn/AJL/APbGazLvT/8AJv8A7U9P8I/FfRfF0wtIWe1u2HywzgLvwORG6lkYj+7kMRyFwDjgrYSpQXM7OPddPVHoUcXTrvlV4y7Pr6Pb9Tudb1NdEsLjUXUyLaQyTFAcFhGhcqCeATjANckI88owWl2l97OycvZwlN/ZTdvRXPBh+0VY55sJwO/72P8AwFev/Z0v519zPG/tKH8j+9Ho2qfFTQNIsYL+aYsbuJZooI13TFWGfmUHEeD8uXZQSCATg1xRwtWcnBL4XZt6L/g/I7p4ulTipt/ErpLf7unzPL7j9oyFZCINNd488M9yEbHqUWCQA47bz6Z713rLnbWok/KN/wBV+R57zJJ+7TdvOVvws/zPUvAvxJ07xyHjt1e3u4V3PBJgnbnG9GHDqCQDwCpIyuCCfPr4aeHs3rF7Nfk+x6OHxUMRdRupLdP80+pS8e/FC38B3MNrPbSXJuIzIGR1UABiuDkHnjNXQwrxCclJKztqiMRilhmouLd1fR2OD/4aKsf+fCf/AL+x/wDxNdn9nS/nX3M4/wC0o/yP70H/AA0VY/8APhP/AN/Y/wD4mj+zpfzr7mH9pR/kf3o1dD+O1nrd/b6cllNG13NHCHMiEKZGCgkAZIGc4FZTwMqcZT517qbtZ9DSnj41JxpqDXM0t11PTPFXjXSvBkccmqyNGZ9/lIiM7ybNu/G0bRjeuS7KOetcNKhOu2qa2td3slfb8uh6FWvDDpOo7XvZJXbtv+fU8dvv2irKJiLOwmmXsZZkhJ/BUm/n+FenHLpfaml6Jv8AVHlSzKK+CDfq0v0ZVh/aNjLYm0xkX1S6Dn8jboP1qnlz6VP/ACW36slZkutO3pK//tqPXvCHxF0jxpmOwkaO4Qbmt5hskC/3lwSrr6lGO3jcBkZ8yth6mH1mtO62/wCB8z1KOJp4jSDtJfZej/4PyO6rkOwKACgDwP44+N5tDto9GsHMdxeqzzOvDLb8ptU9jKwYEjnajD+LNexgaCqN1ZrSOy/vb/h+p4uPrulFUoOzlv5R2/H9D5HtLWW+mS2t1MkszBERRlmZjgAD1JNfSNqKcnolqz5lJyajFXb0SPozT/2dp5bcNe36Q3DDJSOEyovsXMkZY+uFA9CeteJLMUnaELru3Z/dZnuxy1tXnOz7JXS+d0ZGjfBzxBoWu2k5jjntba6gkaeOVACiyKzHY5WTIAORtPI+UsME6TxlKpSkrtScWrNPdrutDKGCq0qsXZOKkndNbX7PU6X48eNZrdk8OWbbFdFlumU4JDE+XDwcgYG9wfvAp2yDhgKCd68u9o/q/wBF8zozCu1ahDTS8v0X6v5Hzv4f0K58S38OmWQBmuG2gnO1R1Z2IBIVFBZiATgcAnAr26lRUoupLZf1b5nhU6cqslThu/w8z3jV/wBnqa0smmsLz7TdRru8povLWQjkqjB2Ksf4dwIJwCVzkePDME5WnG0e972/A9meXOMbwneS6Wtf01PnJHe2kDIWjkjbIIyrKyngg9QQR9Qa9zRq3RnhaxemjX4H3R8J/GT+MNIDXR3XlmwhnPTfxmOXHq65DerqxAAwK+SxdFUKlo/DLVeXdfL8j7DB13Xp+98UdH59n8/zufFOv/8AISu/+vmf/wBGtX1NP4I/4V+R8nU+OX+J/mdP4I+HmoeOzN9heGJLUoJGmZh/rN23aERyT8hznA6c1hXxEMPbnTbd7W8vmu50UMNPE35Gko2ve/W/ZPsX/HHwu1DwLBHd3MsNxBK/l7ot4KuVZgGVlHBCnBBPTkDjMUMVDENximmlfXsXXwk8MlKTTTdtL7nm8Ez28iyxkq8bBlI4IZTkEehBFdzV1Z7M4E+VprdH238S/h7H4zgjvpLhrdrC3mYKEDByVD8ksCOUxxnrXymGxDw7cFG/M11tbp+p9disMsQlNytyxfTfr+h8QV9YfIHvPgT4NweMNIj1WS8e3aV5F8tYlYAI5TqXHXGelePXxjoVHTUU7W1vbdX7Hs4fBKvTVRyavfS3Z27jv2hf+Q3a/wDXiv8A6PnpZf8Aw5f4/wBEPMf4sf8AB+rOK+En/I16f/vy/wDoiWuvF/wJ+i/NHJg/48PV/wDpLPpv4xeGdQ8U6TDaaVF58yXSSMu9EwgilUnLso6soxnPPSvBwdWFGo5VHZcrWz3uux9BjaU61NRpq7Uk90tLPv6nkOi/s+aldoJNTuorLIz5aKZ3HsxDRoD/ALruPevSnmEI6U4uXm9F+r/I8uGXTavUko+S1f6L8Wc74/8AhDceCbQalHcreW29Uf8AdmJ0L52nG51ZSQATuBBIG0jmtsPi1XlyOPLK11rdO33GOIwbw8faKXNG9npZq/3nkdvPJaypPCxSSJldGU4KspBUgjoQQCK9NpNNPZ6HlpuLTWjWqPvbxDetqXg25vHGGudJklIHQGS1LkDr3NfHU48mIjFdKiX3SsfaVJc+HlN9abf3xufAlfZHxR7B4V+DGq+KLGLU0ntre3nBMe8yM5AZl5VUIHKn+POO1eZVxkKMnTak2t7Wt+f6HqUsFUrRVROKi9r3v+X6nE+MfCN34Jv/AOzr1o3cxrKjxklWRiygjcFIO5GUgjqDgkYNdVGtGvHnhda2s+j/AKZyVqMsPL2c7bXTW1n/AMMdD8H7h7fxVY7DgSGVGHqrQScH6EAj3ArHGK9CflZ/ijfBO1eFut1+DPpT4i/C0+PbqC6F4LP7PEYtvkebuy5bOfNjx1xjB+teFh8V9Wi48vNd33t+jPfxOE+syUublsrbX6+qPNLn9npLKJ7i41dIoolLu7WmFVVGSSTdYAA5rvWYczUY0229lzf/AGp57y7lTk6qSWrfL/8AbHzpexQwTyR20hnhR2VJSnlmRQcB9m5tu4c7SxIzzzXtxbaTkrO2qve3lc8KSSbUXdJ6O1r+duh6L8JvDV5ruu29xbLiDT5oriaRshQqOGCAgcu+MKv1JwATXDi6sadKUXvJNJeq39Ed2DpSqVYyjtBqTfo9vVnu/wAa/BureLTp/wDZMP2j7N9p835402+Z9n2ffZc52N0zjHPUV5GCrQoc/tHa/LbRvbmvt6ns46hUr8nsle3NfVLfltv6M4jS/wBne8lTdqN9Fbuf4IY2mx7F2aIZHfCkehrrlmMVpCDa7t2/DU5IZbK3vzS8kr/joeefEP4a3PgFoXaZbq2uSypIEMbKyBSVdCWAyD8pDtkA5C9D24fErEXSXK1ut9+z/wCAcOJwrw1ne8Xs7W27r/gnIeGdUl0TVLW+gYq8M8bcd13AOp9mUlSO4JrpqwU4Sg9mn/wDlpTdOcZx0aa/4P3n6P18OfeBQAUAfFPx2dm8TMD0W2gA9hhj/Mk19VgdKP8A28z5LH/xv+3UZPwbhSbxXZCQAhfPYA/3lt5Sp+oPI9xmtMY7UJ28v/SkZ4JJ14X8/wD0ln3ZXyJ9iFAHwT8WpZJfFV+ZRtKyIoH+ysMYU/8AAlw3419hhElQhbs/zdz4zGNuvO/dfdZHXfs/xq3iCZiBlLKQr7Eywg4/AkVzZhpSS/vL8mdOXL96/wDC/wA0fZFfMH1R+dfjaJINe1GOIAIt7cAADAH71uAOwHQfSvtqDbpQb/lj+R8LXSVWaW3NL8z279nN2E+ooPumO3J+oaUD9Ca8nMdoPzl+h6+W71F5R/U8A1//AJCV3/18z/8Ao1q9mn8Ef8K/I8Wp8cv8T/M+jv2cv9Vqf+/a/wAp68TMd6f/AG9+h7uW7VPWP/tx0P7QX/IAg/6/Y/8A0TPWGX/xX/hf5o3zH+Ev8a/Jnx1X058sfpLqn/IMn/69pP8A0U1fCx+Nf4l+Z97P4Jf4X+R+bVfdHwR9xfBL/kVbb/rpcf8Ao96+Sxv8eXpH8kfX4H+BH1l+bPGP2hf+Q5a/9eK/+j569TL/AOHL/H+iPKzH+LH/AAfqzivhJ/yNen/78v8A6Ilrrxf8CfovzRyYP+PD1f8A6Sz6q+I/xGg8B26KqC4vbgN5URbaqqODJIRk7A2AFGC5yAwwSPnsNhniG9bRW7/Ref5H0eJxKwyVleT2X6vy/M+Yb74w+KtSl/d3XkBjhYoIowBnoASjSH2y5PpXvRwdCC1jfzbf+aX4Hz0sbXk9JW8kl/k3+JD4i8R+MbvTmtdc+1fYZWQsZ7URruBDJ+98lCOQMLuwfTrVU6eHjNSo8vMr7Sv66XFUq4hwca3NyO28bemtkeZ13nnn3dff8iE//YDH/pEK+Qj/ALyv+vv/ALcfZS/3V/8AXr/2w+Ea+vPjT74+E/8AyKun/wDXJ/8A0dJXx2L/AI8/Vfkj7TB/wIej/Nnz7+0J/wAjBb/9g+L/ANKLqvay/wDhS/xv/wBJieJmP8WP+Bf+lSON+E3/ACNWn/8AXST/ANEy104v+BP0X5o5MH/Hh6v8mfe5IUZPAFfHn2h8dfF34nHxDK2i6W+NPhbEsin/AI+XX0P/ADyRvu4OHID8gLj6bCYX2S9rUXvvZfyr/N/hsfLYzFe1fsqb9xbv+Z/5L8dzy3wp4WvPF9+mnWS8tzJIR8sUYPzSP04HYZyzYUcmvQq1Y0Iucvku77HnUaUq81Th832Xdn3t4Y8M2fhKxTTrBdqJy7nG+Rz96Rz3Y/kowowABXx9WrKtJznv0XRLsj7OlSjQiqcNl97fdnnXxN+K6+C3XT7CNLi/dQ7byfLhU/d3KuCzOMkKGXAwxJBAPdhsJ7f35tqG2m7/AMjhxWL+r+5BJz312X/BZ89N8VfF+qzhILuUyOcJFbwx5J7BVWMs34liehzXtfVaEFdxVl1bf+Z4f1vETdoyd+iSX6IzPF+ueJ9Sght/EguBHG7ND59uISWIw2GEUZfgjglscdK0owowbdC1+tpX/V2M61SvJKNfmsnpeNv0VzirP/Xx/wDXRP8A0IV1S2fozkjuvVH6Z18GfoAUAFAHyv8AtB+HJEuLbXYxmJ0FtLgfddS7xsf99WZf+AAdTX0OX1FaVF7p8y9Nn/XmfOZjSacay2tyv11a+/8AQ8F8Pa3N4c1GDU7bBktZA4B6MMFWU45wyllOOxr2KkFVg6ctmrHi05ulONSO6d/6+R9hWfxx8M3Fv580stvKBzA8Ls+cdFaMNGQTwCXHqQtfMvA1k7JJrvdJfjr+B9THH0WrttPtZ3/DT8TnbP48Q6pq0Gm2Vkxt7meKFZpZQjjzHVSxiVHHBOQPM5A5IzgbPAOFNzlPVJuyWmnndfkYRzBTqRpwho2lduz1faz/ADOD+PfhiWy1RNbjUm3vUVJGxwk0a7cHjADxhSuTklX9K7MBVUoOk94u69H/AJP9DizCk4zVZbSVn5Nf5r9TzXwD4rPg3V4tRILw8xzov3mifG7bkgblIDqCQCVAJANd+Ipe3puns916o4MPW+r1FPps15P+rn1Tqvxs8O2dk1zaTG6uCuY7cRyKxcjgOWUKgB+8dx4B27jivnYYKq5cslyrq7rbyPo546jGPNF3fSNmtfPt5nxXd3Ul7PJczHdLM7SOx6lnYsx/EkmvqklFKK2SsvkfJtuTcnu22/Vn2F8CvDEui6TJqNypSXUmRkU9RBGCIzjqN5d2912GvmcdVU5qEdoX+97/AHWX4n1GApOnTc5aOdrei2++7/A+S9f/AOQld/8AXzP/AOjWr6On8Ef8K/I+aqfHL/E/zPo79nL/AFWp/wC/a/ynrxMx3p/9vfoe7lu1T1j/AO3HQ/tBf8gCD/r9j/8ARM9YZf8AxX/hf5o3zH+Ev8a/Jnx1X058sfpLqn/IMn/69pP/AEU1fCx+Nf4l+Z97P4Jf4X+R+bVfdHwR9xfBL/kVbb/rpcf+j3r5LG/x5ekfyR9fgf4EfWX5s8Y/aF/5Dlr/ANeK/wDo+evUy/8Ahy/x/ojysx/ix/wfqzivhJ/yNen/AO/L/wCiJa68X/An6L80cmD/AI8PV/8ApLOo+PokHiNC/wB02cOz/d8ybP8A49u6Vz4C3snb+Z3+5HRmF/bK/wDKrfe/1Oe+Ees6dofiCO41UqkRjkSOV/uxStja5P8ACCAybv4d+SQMkbYuE6lJxp73TaXVdv1MMHOFOqpVNFZpN9H3/T5ntnxk8a6Ne6DJptndRXVzcPEVWBhIAEkV2LspKqMDABOSTwMZI8rB0KkaqnKLjFJ76bq2h6+Nr05UnThJOTa2d9nfWx8jV9KfMH3dff8AIhP/ANgMf+kQr5CP+8r/AK+/+3H2Uv8AdX/16/8AbD4Rr68+NPvj4T/8irp//XJ//R0lfHYv+PP1X5I+0wf8CHo/zZ8+/tCf8jBb/wDYPi/9KLqvay/+FL/G/wD0mJ4mY/xY/wCBf+lSON+E3/I1af8A9dJP/RMtdOL/AIE/Rfmjkwf8eHq/yZ7L8cvHtzpxHhyx3RGaISXMo4LRuSFiQg5AbafMPBIwo4LZ8vA0FL9/PWztFefd/oetj8Q4fuIaXV5PyfRfqfKwGTjp7+n5V9CfNn1J4E8feDvBGnraQyTPcSYa4m+ztmSTHbuEXoi9AMsRuZifn6+HxFefM0kl8K5tl/m+p9Fh8Rh8NDlTd38T5d3/AJLoek6P8XfD+uXkWn2jzGe4bYgaFlGcE8k9OlcM8JVpxc5JWWr1PQhjKVSSpxbu9FofKvxXEo8U6h52d3mrtz/c8pNmPbZjFfQ4S3sYW7fjd3/E+bxd/bzv3X3WVvwOt+BviDStB1G5/tR0t5J4kWCeQhUXaxMkZY8KZMowJwP3ZGckA8+OpzqQj7NNpN3S38nby1+86sBUp0py9o0m0rN7LuvK+n3HQfHbxXpetQWllp1xHdSwyvJIYjvRVKBRlx8pJPZSSADnHGcMDSnTcpTi4ppJX0e/Y2x9aFRRhTkm023bZad9j53s/wDXx/8AXRP/AEIV7ctn6M8OO69UfpnXwZ+gBQAUAUtS0221e2ksr2NZoJlKujDgg/qCOoYYIIBBBGauMnBqUHZrZkSippwmrp7o+afEP7PcplaXQ7pPLYkiG5DKUHoJUD7x6ZRTjqSea92nmCtarF37x6/J2t954FTLne9GSt2l0+av+Rw6/AzxQX2GKBVzjeZ02j3wMvj/AIDn2rr+vUbXu/Sz/wCGOP6hXvay9eZf8P8AgeleDfgTNpF7BqWqXaFrWVJVht1JBZCGXdK+3C7gMgR5I4DDrXBWxynF06cd01d+fkv8z0KGAdOSqVJL3WmlHy83/kfQWqaXa6zbSWN9Gs9vMNro3Q9wRjkMDgqwIKkAggivGjKVNqcHZrZntzhGpFwmrxe6PmfxB+z1OsjSaJdI0RyRFc7lZfYSIrB+c8lEwMA56171PMFa1WLv3j/k9vvZ8/Uy53vRkrdpaW+a3+5HGw/AvxPI+xo7eNc/fadSv1woZv8Ax2ul46ildN+ljlWArXtaK87/AOR6r4Q+A1rpcy3euSrfOmCtuilYQwIILsTulH+yVRT/ABBhxXn1sfKa5aK5V3e/y7fiejRy+MHzVnzW+ytvn39ND6DVQgCqAABgAcAD0ArxT3D5H1P4D67e3c9wk1mEmmkkUGSXIDuWGcQnnB55NfSRx9KMVFqWiS2XRep8xPL6spOScdW3u+r9D1r4TeAb/wACpeLqDwyG6aEp5LO2PLEobduRMZ3jGM9+ledi8RHEOPImuW97+dvN9j08Hh5YZSU2veta1+l/JdzV+KXg+88a6ZHY2DRRyR3CzEyllXascikAqrnOXHbGM81lha0cPNznezjbT1Xp2NcXRliIKELJqSevo+yfc8C/4Z+1/wD57WX/AH8l/wDjNez/AGhS7S+5f5ni/wBnVe8Pvf8AkfXN7bNcWctsuA8kLxgnplkKjPtk+lfNxdpKXZp/ifTSV4uK6pr8D5G/4Z+1/wD57WX/AH8l/wDjNfSf2hS7S+5f5nzP9nVe8Pvf+R9H/Drw1c+EtEh0u8aN5onlYmIkph5GcYLKp6HnjrXh4ioq1R1I3Sdt99FY93DUnQpqnK103ttq7nn3xU+GGp+NtRhvbCS3jjithCwmZ1bcJJHyAsbjGHHcHOeK7cLioYeDhNO7lfS3ZLuuxxYvCzxE1ODiko21v3b6J9znvAvwb1jwzrdrql1LatDbM5YRvIXIaJ0GA0Sjqw6kcZravjKdWnKnFSu7bpW3T7mGHwVSjUjUk42V9m77Ndj1f4g/Dy18d2yq7fZ7uDPkzhd2AfvRuuRuRuvBBVvmGfmVvOw+Ilhnorxe62+a8z0sRho4mKW0ls/0fkfOFx8BvEkUmyP7LKnZ1mKj8QyK3HU4B9s17ix9G13zLyt/kzwXl9ZOy5X53/4B2Wifs9P5UravdqJmRlhW3BZEcj5ZHZwhcA/8s1Vc9d/auWeYar2UdL633t2Vr29fwOunl2j9rLW2nLsn3d7fd+JzTfs+68CQs9kR2PmSj9PJrf8AtCl2l9y/zOf+zqveH3v/ACPpS58P3E3hltCVkFydN+x7iT5fmfZ/Kznbu2buc7c47Z4rwlUSre115efm87c1/vPfdNuj7HTm5OXyvy2+4+af+Gftf/57WX/fyX/4zXvf2hS7S+5f5ngf2dV7w+9/5H074I0Ofw3otrpd0Uaa2RlcxklCTI7fKSFPRh1A5rwK81VqSqRvZvS++yPoKFN0acacrXS6bbtnlvxT+F2qeNtUiv7CS3jijtUgImd1bcsszkgLG424kXvnOePX0MLioYeDhNO7k3pbsl3XY87F4SeImpwcUlFLVvu32fcwPA/wa1jw1rdrql1LatDbOzMI3kLkNG6DaDEo6sOpHFbV8ZTq05U4qV3tdK26fcxoYKpRqRqScbK+zd9muxr/ABM+FOq+MdX/ALRsZLaOLyI48SvIrbkLE8LGwx8wxz+FZ4bFQoU+Sale7eiXX5o0xWEnXqe0g4pWS1b6fJnnn/DP2v8A/Pay/wC/kv8A8Zrt/tCl2l9y/wAzi/s6r3h97/yD/hn7X/8AntZf9/Jf/jNH9oUu0vuX+Yf2dV7w+9/5HTeDfgtrPh7WbTUrmW0aG2lDuEeQsRgj5QYlGee5Fc9bG06lOVOKldqyul/mb0MDUpVI1JONk76N3/I9F+JPwrh8cFby2kFrfxLs3MCY5UGSqyY5UqSdrgE4JUqw27eLDYp4f3JK8Hrbqn5f5HfisIsR70XyzWnk15/5ng5+A/iVZPLAtSuceZ53y49cFN+P+A59jXr/AF+ja/velv8Ag2PG/s+te3u+t/8AgXO2tf2eiunSi4u1OpOFMJQN5EeDllYn533jjdtXZ1CvXK8w99csfcW/d/orfj5HWsu9x80vf6W2X6u/4eZzkHwB16KVHM1kQrKT+8l6Ag/88a3ePpNNWl9y/wAzBZdVTTvH73/kfYNfMn1AUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFAHPa/4s0rwuqNqtzHbeZ9xWyzt6kIgZto7tjAPBOa3p0p1dKcW7f1uYVK1Ojb2kkr7d/uWppaZqlrrNul5YSpcQSDKuhyDg4I9QQeCCAQeCKzlGVNuM1ZrozSE4zSlBpp9UX6gsKACgAoAKACgAoAKACgAoAKACgAoAa7rGpZiFVQSSTgADkkk8ADuaPJBsclp3j7QdWvDp1newy3IJAQFgGI6hHICSH0CM2RyMiumWHqwjzyg1Hv29VuvmcscRSnL2cJpy7f5dH8jr65jqCgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoA+Ufj74avzfR64imWy8hIGYc+S6u5ww7I+/Kt035U4JXd9FgKkVF0dpXb9VZfij5vMKUuZVlrGyXo7v8Hf7zy7wN8QNQ8DXG+3Pm2kjAzWzHCv23KcHy5AOjgc4AYMBivQr4eOIVnpJbS7f5o87D4ieGfu6x6x6P8AyfmfafhPxppvjG3E+nyAuoHmwNxLET2Ze4z0dcq3Y5yB8tVozoPlmtOj6P8ArsfWUa8K65qb16rqv67nWVzHSFABQAUAFABQAUAFABQAUAFAGfqeq2miwNd38qW0CdXkYKPXA7sxxwqgsewNXGEpvlgm32REpxprmm0kurPkP4lfF6bxOG03Sd1vp2SHY8SXAzxkYzHHxwgOW6uf4R9LhsGqPv1NZ9F0j/m/P7j5fFYx1v3dLSHXvL/JeX3nF/Drw3f+ItZtxYqyrbTRTTTDIWFEcNknj5jghFzlj7AkdWIqRpU5c/VNJd21/Vzkw1KVWpHk2i02+yT/AKsfoBXxp9sFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQBFPbx3UbQzKskcgKsjgMrKeCGU5BBHUGmm4u60a2E0mrNXXY+ZfHHwIYs154aIwcs1nI2Me0Eh4x1OyRhjs/Ra96hjre5X/APAl+q/VfcfP18v+3h//AAF/o/0f3nz4yan4VvMET6feQH/bikX6HglT6jKsPUGva9ytHpKL+aPD9+hLrCS9Uz3fwr8f57cCDxBD9oUYH2i3AWT6vGSEb6oY8Y+6c149XL09aLt5Pb5Pf77ns0cxcdK6v5rR/NbfdY+gNA8caJ4lA/s67ikc/wDLJj5co9vLfaxxnGQCuehNePUoVKXxxaXfdfetD26denV/hyV+2z+56nV1zHSFABQAUAFABQAUAZWq67p+hR+dqNxFapgkeY6qTjn5VzuY8dFBJ7CtIU5VHaEW/RGc6kKSvOSivNnhvif4/wBlZhodBhN3J0E0waOEHPUJxK4xng+Vzg89K9all8nrWfKuy1f37L8Tx6uYRjpRXM+70X3bv8D5v8QeKNU8W3HnajM87E/JGMiNM/wxxjhfTgbj3JNe7TpQoK0El3fV+rPBqVZ1nebb7LovRHpHgz4J6przJcaqG06zPJDDFw4/2YyDsz/elwRnIRq4K2NhSvGn70v/ACVfPr8vvO+hgZ1LSqe5H/yZ+i6fP7j610Dw9Y+GLVbHTYlhiXk4+87YALyN1dzgZJ+gwAAPnKlSVWXPN3f5eS7I+mp040Y8lNWX5+b7s2qyNQoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAyNZ0DT/ABBD9n1K3juY+wdeV91YYZD7qwPvWsKkqTvTbi/IynThVXLUimvP+tDxfXf2ftLvMvpVxLYt2Rx58f0GWWQfUu/0r1KeYTjpUSl6e6/8vwR5NTLoS1pycfJ6r9H+LPLdT+A/iKxObX7PeAHjy5fLfHYkShFH0DnB9etehHH0n8V4+quvwv8AkedLL60fh5Zejs/xt+ZXtm+IfhYBIV1JEXgAxm5jAHYBlmQD6U39Uq6vk+/lf6MS+t0dEp29OZfqjbg+M/i3Sh5d/axysOSZraWJ/wDxwxrj/gFZPBUJ6wk16STX43/M1WNxENJxT9YtP8Lfka8f7RN0gAm06PdjnE7r+IBjbA/E/Ws/7Oj0m/u/4Jqsykt6a+9r9D0jw78VTruh32tGxkjbTRny1fesuVz8smwYK9ZPlOxcNznA4KmF9nUhS517/W1rfK/3dzvpYv2lKdbka5Ol739Hb79NDzlv2i5jwmmpn3uGP8ohXd/Zy/n/APJf+CcP9pPpTX/gX/AM2f47+IrvK2VlBHuyF/dzSsM9MfMqkjtlcZ6qelaLAUo/FN/ekZvH1pfBBL5N/qYtx4i+Iuv/ALtV1BVbtDamAAdfvpEjAe7P9TWqp4Slr7nzlf8ABt/kYupjKmi5/lHl/FJfmVLP4OeLNak867jEBkOWkup1LE+rBTLJk/7QBqnjKFNWi726RX/DImOCr1HeSt5yf+V2ei6N+zvEhD6tes47x2ybO3/PWQsev/TIcd+eOGeYvalC3nJ/ov8AM7oZalrUn8oq34v/ACPafDvgTRPCwzptrHHJ3lbMkv8A38csyg/3VKr7V5dSvUq/HJ27bL7ketTw9Oj/AA4pPvu/vf6HXVzHUFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFACEA9aAG+Wn90fkKYrDgoUYAAHpSGN8pP7o/IU7isOCgdAB+FIYtABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQB89+IfiL4qHia68OeHbO0vDaokgEm5X2FImZmZp4k4aUAAYOCODya9WFCl7KNarKUb6ad7vyfY4JVantHTppO3/AAPNdzqvB+seOL3UFi8Q6fa2diUctLEylw4HyDAuZTgnr8n4isasKEY3ozbl2f49EaU5VXK1SKUfL/h2etVwHWFABnHFABQB5b8WfHF54E0qK/09IZZJrhYf3wZlClJHJAR0OfkA645PFduGoxrTcZXSSvp6r/M5a1R0oqUbau2p6lXEdQgIYZHI9qAFJC8nigDM1qe7tbGebTYlubxInaCJm2q8gB2qSSMAn3XPTcuci4JOSU3aN9X2RMrpNxV3bRFTwxd6le6bBPrUCWl86kzQodyqQxC4O58blCsRubaTgniqqKMZNU3ePR/1YUHJxTmrPqjn31fWr/xGdOsokg0myjRrq5mjYtNI43LFbfMoIAwGfaQpD99gbXlhGlzyd5t+6k9l3ZnzSc+WKtFbt9X2R31cpuGRnHf0oAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgD5QupNci+JOpHw2lrLd/ZVDC7LiIReXa7j8jI27fsAwehOR6e4vZ/Voe2uo3+zve8u/zPLfOq8vZ2vbrtbQ7vxdceIz4O1ZvEiWcE6pH5JsWk2lDJHu3b3YhgehBAIPTiuakqSrU/Y8zWt+a3Z9jabn7KftLJ9OX1NS1kb/hXIfJ3f2Kxzk5z9nPOeufes3/vNv8Ap5+pa/g/9ufoeO6vPIPhRp8gdt5umy245/4+rvvnNehFL63Nf3f/AG2Jxy/3ePr+rNDx98OIdM8MN4nlvLy61eJbWUzyynH72SGMoijlFTzMphiQV64OBNGu5VfYqMVB8ysl2Tf6FVKSjT9o23JWd797f5mr481G/wDENr4Z8P8AnvEmuRwteSKcNICsAOT3Hzu+0/Kz7c9BWdGMabrVbfA3yrtv/wAAuo3JU6d7c1r/AIHJfGL4bWXgjSoJ9LnuRBJcrHJbyyb4y/lyFZlGFCuArKeDkNxtAwejC15VptTSuldNKztdaGNekqUU4N2vs/Tc9Y+LkOkTTWw1zU7q3tth/wCJZacy3T7vlcKoLY+8hLgocAIyNuLcGGc0n7KCb/nltHy/XQ66/Ldc8ml/Kt2eY/D6ePQ/HFtp+jw6lp2nahBL5lvqKlHk2QTyLIq8grviG18kj51zgkV211z0HOo4SlFqzhra7St+JzUvcqqMFKMWnpLTo9fwNzQvD5+MOs6pea9PP9g064a2tbWOTYq/MwDdwCEUFiFy7NkthdpznP6nCEaSXNJXbaLjH6xKTm3yp2SO7HhG78FeFtctJL6S9tfsd41mkg+e3jFvKdu/OSWJHChUUruUAuwHL7VVqtKSiovmjzW6u66G/I6VOa5rqzt5aM83uPFF/oHw30z+z5Giub+ZrfzgxDoplnZirdVY7QobOVBJBBwR1qnGeJnzrSKvbpsjnc3ChHl0bdr/ADZe8VfCaPwNozeINHvLqPVtPVZZZjJ8s2WUSDbgEDkkAlgygq4bdmpp4n20/ZVIx5JaJW27DnQ9lH2kG+Zat9yr8QtVu/Etv4Ruo5WtLnUXG6WPI2SyNZoZFUEZCuSyqT04zVUIqk68bXUej7Lm0FVbmqTTs3+bsVPiX4Ih+Hradr2mXN29+16iTSzyl2lbBk3k4BGShDLkqytg+9Yeq6/PSmoqPK7JK1un6iq01R5Zxb5r6tv5n1upyAa8E9UWgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgDyPSPBmoWXjm+8SSCMWN1a+TGQ+ZN+LYcpjgfun5z6etd8qsXQjRV+ZSu+32v8zkjTkqsqn2Wrfl/kdt4z0BvFGjXeko4ie6iKo5ztDgh03Y52llAbGSASQCeK5qU/ZTjPszepHni4LqjxG08I+P7jQ28NTyWNpaQwNCsinfPOgBCQ5B2ojcKzlUcIR947hXpOrh1U9slJybvbZJ9/XyOJQrcns20klbzfkXNQ+GmsXHgK08MoIft9vO0jgyYj2me4k4fHJ2yLxjrkdqmOIgsRKtrytW212S2+Q3Sk6KpK3Mn+rPQPHXhe98QeE5NDswhu3itEAZtqZhmgd/mwf4Y2xxycetctGpGnWVSXwpy/FNfqdFSDnTcFvZfg0cp4r+GupatpWjy6bLHb6xoMUWzcf3bsiRZUPg4IkiBQldjAkNgHI2p14wnUU03TqN+urf6MynSlKMHF2nBL9P8AI5bxn4H8d+PLGJdSawiMEgK2kLFQx2sDNJId43AcKikjDE/Kcit6VbD0JPk5tV8T/JIyqU6tVLm5VbovzOp8ZeDPEKeJ4fFXh4Wt06QCAw3RwIyA4LL04IbIKurht3BUmsaVWn7J0KvMtb3j1NalOftFVp2elrMhsPBHiefxfYeJtZktJY4IZUkW33IsAaC4jSOMON8g3yhmdjnLMOiih1qSoyo01JNtWv11Tu+2wlTqe0jUnbRPbpo/v3GTeCvE3gvV7zU/B5tbm01RvMmtbolPLlLM25SCmVBZtuHB2vtZG2q1NVaVaEYYi6lDRNdUHs50pOVGzUt0+jN7TfCfiKTRNXj1q7W61DWLedYrdW/0a2aSGSNUjYjIBLKHwNgCgjccscpVKanTdONowau+rs09S1CfJNTd5STsui0MxfhXNqngq28NX7rb31ozSxyId6JL5krLkjBKMkhVscgncASuDf1hQrutBXi9GttLL9UT7FukqctGtfnqYupeGPH/AIstF8P6vJY21hlBPdxEtLOkZB+7nksQGxsiDMPmIGQdI1MPSftaak5a2i9k3/XmQ4Vpr2c+VR6tbv8Ar5HReLfh3dXc3h2LSAn2TQJ4zJ5jhX8qN7Ygjj53KwsWxjLfWsqVdRVV1PiqJ2sur5v8zSdJt01DaD/DT/I0fi34P1DxlY2ltpgjL294k7+Y+wbFR1ODg5OWHFRhqsaMpOd7ONlbvdFV6bqJKPR3PV1GAB7VwnULQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQBm3Gs2Fm5inubeKRcZR5Y0YZGRlWYEZHI46VahJ6pO3kmS5JaNpfMh/wCEi0v/AJ/LX/v/ABf/ABdPkn/K/uYuaPdfejWR1kUMhDKRkEHIIPQgjgg1ntoWUrrVbKxby7m4hgcjIWSVEOD3wzA44PNUoyesU36JktqOjaXzK3/CRaX/AM/lr/3/AIv/AIuq5J/yv7mLmj3X3o1I5UmQSRsrowyGUgqR6gjgj3qLW0ehfoVrTUrS+JFrNFOU+8I5EcrnpnaTjPvTcXHdNeqsJNPZou1Iyvc3kFknmXMiQpnG6R1RcnoMsQM+1NJvSKb9BNpb6D4LiK4jEsLrJG3IdGDKQODhgSDz6GhprR6ML31RxHg/4g6f4zub60schtPl2ZJBE0ZyBNHj+AurDvgbGJ+cAdNWhKioyl9pfc+zMadWNRyUej+/zO8rlNwoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKACgAoAKAPjLxN4at/F3xMm0m8aSOCfaWaIqH+SzVwAWVgMlQDlTxmvoadR0sKpxtdd/OVjx5wVSu4PZ9vQ9Lk/Zw8PFSEuL9WxwTJCQD6keQMj2yPqK4/r1TtH7n/AJnT9Vh0cvw/yOO+D91feF/Fl54RM7XNlH54x/CrwldsqqSfLLL8rqDgkjOSoNdGKUalGNe1pafc+nn5GNBunUdK91r+HUxfippMevfEK20ydmSK7+xQuyY3BXOGK5BAOCcZBGexrTDSdPDOa3XM/uIrR5qyi9nZHpx/Zx8OYwJ78f8AbWH/AOR64/r1TtH7n/mdP1WHeX3r/I8/8Ex3fw58d/8ACKwXD3djcfI6HgfvLfz0kMYJVZIzgOw6puPQgDqq2xGH9u1yyX6O1r9n+ZhTvRq+yTvF/wCVynqMbfBfxul3HldJvyzbRnH2eVsSJjnJtpMOo6lVTON5qo/7ZQ5ftx/NbP5r9SX/ALNVuvhf5P8AyPsiORZVEkZDI4DKwOQQRkEEcEEcgjrXz22jPYPkf4tarP8AEHxNa+D9LYmO2k2SEcr5zDdK7DIyLaIEeobzQOor3sNFYelLET3a09Oi+b/Q8ms3VqKjHp+fX7l+p6J8Udet/ht4Xi0TTMJPcxfZIAOGSILiec4H3jnGeCZJN4ztIrkw8HiKrqT2T5n69F/XRHRWkqNNQju9F6dX/Xc+etAj1b4Ralpmt3yGO21CIs6AnLQMQJI3XgiRFaOZV7MUzyGUetPkxUZ0o7xf49GvLdfecEebDyjN7P8AL/Pqfe1tcR3kSXEDB4pUV0YdGVwGVh7EEEV8u04uz0a0PcTvqtiakM+Yvh18U9W1XxVNomrTCW2la5itx5cabJImLKNyIpbMaMvzE8lT16+zXw8IUVUpqzVm9W9H8+55tKtKVRwk9NbaLoeifGPxrc+CtGWbTmEd7czrFExVX2qAXkba4ZTwoTkHlweorkwtJVp2n8KV309Dor1HSjeO7dkZ3hzxJrmveBv7WjubePVn8zbcXAjihG25KfMNoiUmMFEJXbvK7u5q506dOv7NxfIraK7eq+/cmE5ypcya5u7slv8AceoaDNcnTLeXUZYZrjyEaaaEjyWbblmQj5dvfcMKeoABwOKaXM1BNK7snudMb8qcmr21a2JLDX9N1RzFZXVvcyJyyQzRyMPqEYkUOEoayi0vNNApRlpFp+jLDapZpK9u08KzRIZHjMiB0QAEuy5yqgEEsQBgg55qeV2vZ2eiduo7paXVxIdVs57c3sU8L2o3EzLIhiG0kN+8B2/KQQeeCCDQ4yT5Wmn2tr9wXVrpq3foRafrmn6sWWwube6KfeEMschXtyEY4/GnKEofFFr1TQKUZfC0/RnivxD8SeJo/FVl4c8OXUVqb218webHGyb1NwzMWaKRx8kOAAMZxxyTXo0KdL2Uq1WLfLK2ja00811ZxVZzVSNOm0rrql5+XkbXh/SPiDb6hBJrGo2M9gr5njjjUOyYPCkWqEHOP41+tZzlh3FqnCSl0bei/wDJmXGNZNc8ly9f6sdP4ZudZm1bU11G6s7iyikAtYbcqZoVJbibaAynaMMJNxLq20hRzjUUFCHJGSlbVvZ+n/A6GsHLmlzNNdEt16nSSeItLhgF095apbliolM8QjLDkqHLbcgHkZyKx9nO/Kou/azuac0Ur3Vu90aNrdw3sSz20iTROMq8bB0YezKSD+BqGnF2as+z0KTT1Wxlv4n0iOf7K17aLPnb5RuIg+7pjbv3ZzxjGa09nO3Nyyt3s7E88U7cyv2ujSur63sQpuZY4A7BFMjqgZj0VdxGWPYDmoSb+FN+hTaju7FN9f02K5Fi93bLdEhRAZoxLk9B5e7dk5GBjJzVckrcyi+XvZ2+8nminy3V+19SS81qw01xFd3MFu5G4LLLHGxUkjIDMDjIIz0yDSUJS1im15JjclHRtL52G2euaffyeTaXNvPJgnZFNG7YHU7VYnA7nFDhKOsotLzTQKUXomn6MivvEel6XJ5N5eWttJ/clnjjbnp8rMDz9Kapzkrxi2vJNicox0bS9WkaiTxvGJlZWjK7g4IKlcZ3BhxjHOc4xUWtp1K8zLs/EelahL9ntLy1nlH/ACzinid/++VYn9Kt05xV5RaXdpolSi9E1fyaNmsywoAKACgD4p8Y6dqmq/Eie10OYWl+5TypmdowmLNC5LIrsAUDDhTnOMV9HSlCGGTqK8dbrf7XyPGmpOu1B2fR7dDt3+HvxMKkf23CeO11dA/gfsgwffI+tc3t8L/z7f8A4DH/AOSN/ZV/5197/wAjm/hZJL4A8XS6Lr8A+3348tLveXbLnzBhicPHOy8tjzPMADfxAbYi1eiqlJ+7HXl220+TX3WMqP7qo4TXvPr/AF3KPxatby+8fwW2myCC8lFmkEpYqI5GOEcsoZgFOCSFJ9AelVhnGOHbmrxXNdeQqybrJR0elvU7Q/D74mY/5DkH/gVc/wDyJXN7bC/8+n/4Cv8A5I29lX/nX3v/ACOK8JpefDPxnFF4oiW6udR2ol35jSspnfy/ORmxuy2Ul3qJAuSvHD9NTlxNBug7KP2bW21t+qtoYwvQqpVFdvrfv1/zPoD4ueCv+Ez0R0gUG9s8z23qxA/eRA4z+9QYA4BkCZOAa8rDVfY1Ff4Xo/0fy/K5316ftIabrVf5fM8c8FfGOPRfCE9tdODqenDybNH5MqyZEJxnJEByJBwBGqDOWr0KuF5qycV7ktZeVt/v6edzjp1+Wm0/ijovnt9xvfATwqbS3uPFuqf6273iGSQ8iIEtPMzN08xxjcT91GOcPWWMqXaoQ2W6Xfovl+peGhZOrLd7enV/M43T1b4zeOWupATpWn4IB6G3hf8Adoe264kJdl67C4B+QGumX+x0OVfHL83v9yMl/tFW/wBlfkv82fQnxQ8Gr4y0Ka0jUG6gHnWp6ESIPuA9hIuY/TJUn7orycPV9jUUn8L0fo/8tzvrU/aQaW61Xr/wTzz4AeMzqNi/h28Y/atOyYQ3U2+QCvPOYZCV7YRkAHymuvG0uWSrR+GW/r/wV+pz4apdeze629P+AfRFeSegfCaadLZ6dd+KrL/j50XxBIx9DE5iHOO3mbFI6Ydq+m5k5RoS2nSX3q/6XPEtaLqx3jP8NP1PR/Gd7D8Q9bk+zkS6foei3N6SOVNxPbloxkH7y7oTg9GicEda5KSeHpq+kp1FH5J6/r96Oio1Vnp8MIN/Nr/hvuIbL/kkMv0b/wBOC03/AL4v6+wJf7s/6+0ReM7yeXwx4X0KORoLfVRbRzspxlAsKBT6rmXeVPBKKT0opJKrWq2u4czX4/5BUb9nSgtFK1/w/wAz1Zvg1oFtcWd3pgl02eylD+ZbytvlAB+RzIXHJAJIGSu5SMNxxfWqjUoztJNbNbfdY6vYQTTjeLT6Pc8s1jwxb+LfiXdadevKlsbWOSVYnKGVUhgxGzDnYzFS2OTt4IOCO2NR0sLGcbX5mlfpdvU5ZQVSu4va3TrotC74+0C1Gt6H4GtA1no0rPPJFHI+HZnckEuWJPyMEJJ2tKSBnFTRm/Z1cTLWotE2tv6v+A6kVzwoLSG9v6/rUr/FLwpp/wANv7P8Q+G0Njcw3SxNGjuUlUqzfMGZichSjjOHVyGGeaeHqSxHPRre8nG+2wVoKjy1KejvYs/Em11G9+IGlQ6NMlnfPYt5U0i7lTH2xnyu185jDr908n8aVBxjh5uorx5tUv8At39R1VJ1oqDs7aP7z17wbpPinTZpW8RX9vqELoBGsUXlsjhuTkRxgqVyDnJyBjHOeCrKlJL2MXF9bu9197OqnGpFv2kk15KxwPwt/wCRl8V/9fcX/oy8rqxH8Kh/hf5RMKP8Sr6r9Tjvgp8PNF8T6LJfatE124uJIUR5HEcahIySiIy4di3zMc9FxjBzvi686U1Gm7Kyeyu99zLD0ozjzSV9WvQu/Cw2Nl4W1y31KaW30+C7mjaRHZZEQxon7srzvYhQAAQ7EKVIJBnEczq0nBJycU7dN3v5Do2VOak2ops4XXNH0y48PTXWh6BdxWsKK66teTiOUjeP3giyRKrcr+7+UBsgLgV1QlJVFGpVjd/Yirrba/T5mEox5G4U2l/M3Z+tup1XxElk1DwR4daZ2MkstqGfPzZMDruz13d89c81hQtGvWtslLT5mtXWlTv5fkT/ABj+H2i+EdBhvtLhaK8ju4lNwZJGlk3JIWLlmILFlDZAGCPlwMilha86tRxm/d5XpZWW2w69KNOClBa3WvU9V+JOn+GILD+3fEtst09vEsUI3ukkjMSViQK6gksSxODtXcx4BrhoSq83sqLtd3emi8zqqqmlz1Feysv8jkvg38P10OKXxPqUa2k96jmGBWZUtbV8PzuJYMwAI3OSkYG472bG+Krc7VGDuo7vvL+vxMqFLkvUlo3suyOGh0vw/rAux4f0S+8QkvMZNRu7gwx7jk/upGYb9ucgFRK3Vs5BrqcqkOX2tSNPa0Iq7+a/pGFoSv7ODnv7zdvuf9MveCtM1TxV8NrvTNPcm4W7dIkLY3RK0ErwhicKG3PjkAk7TgMairKFLExnJacqb9dVcqmpToOMd76emjsZFhc+GdHFla+J9AvNGubZ4gLxVkCSSIQzPIxKF0dgd4CzEKSFIwCNGqs+Z0KsZp393S6T7dvwITpx5VUpuLVtf6/4J9iowcBlIKkAgjkEHoQfSvnz1xaACgAoA+L/ABd4hPg/4jz6y0D3KQbMop2lg9mseQ21hxuz05xjI619FSh7XDKne1/0lc8ecvZ13O17f5Hbt+0jDj5dKuCewMygfn5Rx+Rrm+oP+dfd/wAE2+tL+R/f/wAAw/C1jrHxN8XweKr20ewsLPYyFt2D5OTFGjMqGVjI252VQoGRwdoOlRww1F0Iy5pP9d35abEQUq1RVWrRX6bepkfFjUH0Dx9b6qYXmS1W0m2DK7xGSSA20gZwRnBwa0w0efDune1+ZelyKz5KylbazOzP7SMHbSrj/v8AL/8AGq5/qD/nX3f8E2+tL+V/f/wDlbca18YvE9lqxsnsNOsHiJdtxURxSeaw8xlj82WQ/KAi4XIyMAsd3yYOlKnzc0pX+9q22tkvMyXNiKkZ8toq34O/zZ9h18+eufHPjj4QTz+MIYLCMrp+rSeczoAFgCkNdD0GAd8YOAS6ov3TX0FHFJUW5P3oK3r/AC/5P0ueRUoP2iUfhlr6dz6Q8VeFZtU0FtA0eZNPRo44A5VmCwJgNGoVgfmUBCSfulu5zXkU6ihU9rUXNq38+/6nozg5Q9nB26fIofDX4fxfD7T2tN63FzPIZJpgmzdjhEAJJ2oucZP3mY8Zqq9Z15c1rJKyX5k0qXsY23fVnotch0Hh8vwjnsvFQ8UaNdpaI0vmy27Rlt3mZFwoIYALKCxGR8rNkdBXpfWU6XsKkb6WTv22+44vYONT2sHbW7Vvv+89wrzTtPKvDvw0Gl6XqukXsyXEesTzy5VCvliZAq8MTlkYBgRjkDGK7p1+acKkVZwSXrb/ADOWNLljKDd+Zt+lyh4J+FP/AAiWjajpjXCTXWqRyRGcIVVEaFo4xtLEnazux5Gc47ZqquJ9rOE0rKDTtfzuyadH2cZRvrLr8ieD4aTQ+DH8IfaUMr5/0jY2wZuRP9zdnoNv3uvNJ4he39vbTtfysNUWqXsb/P53LOtfDCHXvDlnoM85iudMjiEF1Gv3ZI02FthYEo/ddwOQpBytKGIdOpKqlpJu8fJu45UVKCpt2cbWfmjEi+G/iLVLi1PiPWjd2dhKkqQwQiF5HThS8qFGzjgsd7YLAFWYtWjr04KXsadpSVrt3tfsv+GI9lOTXtJ3S1slb8TpbXwHLb+L5vFZnQxTW4gEGw7gdka7t+cEfu84x3rF1k6KoW1Tvf7/APM0VO1R1b6Wtb7iXx/8P18Zrb3FvcPYajp7l7W5QbtpJUkMuVJGVBUhgVPPzAlSqNb2N01zRlo0OrS9pZp2ktmclB8LNW1rULa98X6oNUhsDuht44ViRm4ILldg5Kgt8hZwApYDit3iIQi44eHI5btu/wBxkqMpNOrLmS2VrHWap4Gl1DxZY+KVnVI7C3eFoChLOWW4XcHzgAeeDgg/dPrWEayjRlQtrJ3v93+Rq6d6kat9la33/wCZ6NXIdB514S8Dy+GtU1fU3mWVdZmWVEVCpiCtO2GJJDZ80cgDofWuurWVSFOCVuRW9dv8jnhT5JTlf4n92/8AmP8Ahp4Kk8BaW2mTTLcs07zb0UoMOqLtwSTkbOue9GIqqvPnStolb7wpU/ZR5W763OV0/wCETQaFqmg3N0G/tW5+0JLHGR5RDI6BlLfOA8Y3YK5XIBB5raWJ/eQqxj8CtZvfdP8AMyVC0JQb+J39DMm+FfiXUtKOiahrgaziiWOKGK1VQwTHliaQFZHRAo+XLZIBJ450WIpQn7SFL3r3bcu+9lsT7GbjySnpbRJfmbmvfC+fWNB0vQ1uUjfSXhdpDGxWTykKkKoYFc5yMk4rKGIUKk6nL8ael9rmkqLlCML/AA2/A6L4leCpPHmlDTIZltWWdJt7qXGEVxjAIOTv657Vlh6qoT52r6NW2Lq0/ax5U7a3OW+IXwx1Pxnf215b38VvDYovlQyweaglDZaQqx2NuwgIdWGFwRjitqGIhRi4uLblu07adu/3GdWjKo01JJLZWvqaem+E/FbyNDrmsx32nzwzQzQJZwwuyyxNGCsiIrKVLBuuDjBqJVKKV6VNxkmmnzN7O+zZShU2nO8bNNWS3RzOifCrxHolq2jW+ueRpTM52xWqCcq5ywWRiWjLdyrnGTgc4raeIpTftHSvPzk7aeXX7jKNGcVyKdo+S1/4BseH/hfe6H4bl0CDUpLW4e6Nyl3bIVK8RgIylgzKSmW2umeBnGQc54iM6qquCa5bcr+f+fYuNFwg6alZ3vdGZqfwz8TeKIo9P8Qa1HcadHIjukVoiSy7OmXG3acEjOWAJ3FWIFXHEUqTc6VNqVrK8m0rkujOdo1J3j5KzPdIYlgRYoxtRFCqPQKMAfgBXmvXVndtoSUgCgAoATAoANo9KAF6UAGBQAm0egoAXpQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQB//Z",
    disclaimer: "{center}Verifique que los datos impresos en este{br}{center} recibo sean correctos.{br}{center}Se recomienda sacar una fotocopia.{br}{center}Cualquier consulta, puede acercarse{br}{center} a cualquier agencia de{br}{center} Financiera Confianza.",
    reprintText: "¿El comprobante se imprimió correctamente?",
    reprintOk: "No, volver a imprimir <i class='icon ion-refresh'></i>",
    reprintCancel: "Si <i class='icon ion-checkmark'></i>",
    printingPopup: null,
    reprinting: false
  };
  let result = {
    disclaimer: constant.disclaimer,
    tryPrinterConnect: tryPrinterConnect,
    connectForTicket: tryPrintTicket,
    printLast: tryPrintLastTicket,
    printBox: tryPrintBox,
    printErrorTicket: tryPrintErrorTicket,
  };

  /* -------------------------FUNCIONES AUXILIARES------------------------- */

  /**
   * Intenta la conexion con el listado de dispositivos guardados en constant.printers
   * @returns {Promise}
   */
  function tryBluetoothPairing(){
    return new Promise(function (resolve, reject) {
      showLoader();
      try {
        DatecsPrinter.listBluetoothDevices((data) => {
          function validatePrinter(printer, data, num) {
            if (data[num].name == constant.printers[printer]) {
              DatecsPrinter.connect(data[num].address, (ok) => {
                hideLoader();
                constant.connected = data[num].name;
                resolve();
              }, (err) => {
                if (num + 1 < data.length) {
                  num++;
                  validatePrinter(printer, data, num);
                } else {
                  num = 0;
                  if (printer + 1 < constant.printers.length) {
                    printer++;
                    validatePrinter(printer, data, num);
                  } else {
                    hideLoader();
                    reject();
                  }
                }
              });
            } else {
              if (num + 1 < data.length) {
                num++;
                validatePrinter(printer, data, num);
              } else {
                num = 0;
                if (printer + 1 < constant.printers.length) {
                  printer++;
                  validatePrinter(printer, data, num);
                } else {
                  hideLoader();
                  reject();
                }
              }
            }
          }
          validatePrinter(0, data, 0);
        }, (err) => {
          hideLoader();
          console.log('getlistBluetoothDevices error', err);
          reject();
        });
      } catch (e) {//intentional
        hideLoader();
        reject();
      }
    });
  }


  /**
   * Imprime el texto que envias
   * @param text (String)
   */
  function printSimpleText(text){
    DatecsPrinter.printText(text, 'ISO-8859-1', function () {
      hidePrinting();
    })
  }

  /**
   * Imprime x lineas que le envies dentro del array 'lines'
   * @param lines
   * @param i
   * @param printedArray (Array) Array de control que contiene lo que esta impreso.
   * @param ticketCopyNumber (int) Numero de copia que esta imprimiendo
   * @returns {Promise}
   */
  function printLine(lines, i, printedArray, ticketCopyNumber) {
    return new Promise(function (resolve, reject) {
      DatecsPrinter.printText(lines[i].text, 'ISO-8859-1', function (ok) {
        console.log(ok);
        hidePrinting();
        if (i + 1 < lines.length) {
          i++;
          printLine(lines, i);
        } else {
          isPrintFinished(lines, printedArray, ticketCopyNumber).then(function(){
            resolve(true);
          }, function(err){
            reject(err);
          })
        }
      }, function (error) {
        console.log('printText error', error);
        reject(error);
      });
    });
  }

  /**
   * Bucle recursivo para controlar la impresión satisfactoria con la impresora
   * @param lines
   * @param printedArray (Array) Array de control que contiene lo que esta impreso.
   * @param ticketCopyNumber (int) Numero de copia que esta imprimiendo
   * @returns {Promise}
   */
  function isPrintFinished(lines, printedArray, ticketCopyNumber){
    return new Promise(function (resolve, reject) {
      DatecsPrinter.getStatus(function(success) {
        console.log('Status -> ', success);
        if (success == 0) {
          console.log('Buffer vacio (Determinamos que acabó de imprimir)');
          if (ticketCopyNumber == 1) {
            printedArray.push('texto copia ' + ticketCopyNumber);
          } else {
            printedArray.push('texto copia ' + ticketCopyNumber);
          }
          hidePrinting();
          resolve(true);
        }else if (((success != 0) && localStorage.getItem('printerHasPaper') == '0')) {
          reject('success != 0 y sin papel -> '+ success);
        } else {
          resolve(isPrintFinished(lines, printedArray, ticketCopyNumber));
        }
      },function (err) {
        console.log('getStatus error ',err);
        reject(err);
      });
    });
  }

  /**
   *  Metodo que imprime el ticket principal a usar con el logo.
   * @param lines
   */
  function printTicket(lines){
    showPrinting();
    var printedArray = [];
    switch (constant.connected) {
      case constant.printers[0]:
        setTimeout(function () {
          $window.DatecsPrinter.printImage( //PRINTING LOGO
            constant.logoB64, //base64
            constant.logoW,
            constant.logoH,
            1,
            function () {
              let ticketCopyNumber = 1;
              printedArray.push('Logo copia ' + ticketCopyNumber);
              var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{br}{center}****Copia Para Corresponsal****{br}"}]
              for (let i = 0; i < lines.length; i++) {
                exit[0].text += lines[i].text;
              }
              printLine(exit, 0, printedArray, ticketCopyNumber).then(function(){
                printOKLog('Copia corresponsal');
                if (printedArray.length == 2) {
                  var alertPopup = $ionicPopup.alert({
                    title: "Información",
                    template: "Corte su copia y pulse Aceptar para imprimir la copia del cliente",
                    okText: "Aceptar",
                  });
                  alertPopup.then(() => {
                    $window.DatecsPrinter.printImage(
                      constant.logoB64, //base64
                      constant.logoW,
                      constant.logoH,
                      1,
                      function () {
                        ticketCopyNumber++;
                        printedArray.push('Logo copia ' + ticketCopyNumber);
                        var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{center}*****Copia Para Cliente*****{br}"}]
                        for (let i = 0; i < lines.length; i++) {
                          exit[0].text += lines[i].text;
                        }
                        printLine(exit, 0, printedArray, ticketCopyNumber).then(function () {
                          localStorage.setItem("bm-last-ticket", JSON.stringify(lines));
                          printOKLog('Copia cliente');
                          if (printedArray.length == 4) {
                            var alertPopup = $ionicPopup.alert({
                              title: 'Información',
                              template: 'Impresión realizada satisfactoriamente',
                            });
                            alertPopup.then((e) => {
                              reversionService.clearReversionData();
                              doNavigate('menu.homeCustomer');
                            });
                          }
                        }, function (err) {
                          hidePrinting();
                          errorLog(err, lines);
                          askPrintAgain(lines, 2);
                        });
                      }, function (error) {
                        hidePrinting();
                        errorLog(error, lines);
                        askPrintAgain(lines, 2);
                      });
                  });
                }
              }, function (err){
                hidePrinting();
                errorLog(err, lines);
                askPrintAgain(lines, 1);
              });
            },function (error) {
              hidePrinting();
              errorLog(error, lines);
              askPrintAgain(lines, 1);
            }
          );
        }, 500);
        break;
    }
  }

  function printOnlyClientTicket(lines){
    showPrinting();
    var printedArray = [];
    switch (constant.connected) {
      case constant.printers[0]:
        setTimeout(function () {
          $window.DatecsPrinter.printImage( //PRINTING LOGO
            constant.logoB64, //base64
            constant.logoW,
            constant.logoH,
            1,
            function () {
              let ticketCopyNumber = 1;
              printedArray.push('Logo copia cliente ' + ticketCopyNumber);
              var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{center}*****Copia Para Cliente*****{br}"}]
              for (let i = 0; i < lines.length; i++) {
                exit[0].text += lines[i].text;
              }
              printLine(exit, 0, printedArray, ticketCopyNumber).then(function(){
                if (printedArray.length == 2) {
                  localStorage.setItem("bm-last-ticket", JSON.stringify(lines));
                  printOKLog('Copia cliente');
                  if (printedArray.length == 2) {
                    var alertPopup = $ionicPopup.alert({
                      title: 'Perfecto',
                      template: 'Se ha impreso todo correctamente',
                    });
                    alertPopup.then((e) => {
                      reversionService.clearReversionData();
                      doNavigate('menu.homeCustomer');
                    });
                  }
                }
              }, function (err){
                hidePrinting();
                errorLog(err, lines);
                askPrintAgain(lines, 2);
              });
            },function (error) {
              hidePrinting();
              errorLog(error, lines);
              askPrintAgain(lines, 2);
            }
          );
        }, 500);
        break;
    }
  }

  function askPrintAgain(lines, ticketCopyNumber){
    let receiver = (ticketCopyNumber == 1) ? 'corresponsal' : 'cliente';
    var alertPopup = $ionicPopup.confirm({
      template: 'Ha ocurrido un error mientras se imprimía el recibo del '+ receiver +'. ¿Desea imprimirlo de nuevo?',
      okText: 'Si',
      cancelText: 'No',
    });
    alertPopup.then((e) => {
      if (!!e) {
        if(ticketCopyNumber == 1){
          tryPrintTicket(lines);
        } else {
          tryPrintOnlyClientTicket(lines);
        }
      } else {
        errorLog('Se ha producido un error con la impresora y el usuario no ha querido reimprimir el recibo', lines);
        reversionService.doReversion();
      }
    });
  }


  /**
   * Metodo que imprime el último ticket con el logo.
   * @param lines
   */
  function printLastTicket(lines){
    showPrinting();
    var printedArray = [];
    switch (constant.connected) {
      case constant.printers[0]:
        setTimeout(function () {
          $window.DatecsPrinter.printImage(
            constant.logoB64, //base64
            constant.logoW,
            constant.logoH,
            1,
            function () {
              let ticketCopyNumber = 1;
              printedArray.push('Logo copia ' + ticketCopyNumber);
              var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{br}{center}****Copia Para Corresponsal****{br}"}]
              for (let i = 0; i < lines.length; i++) {
                exit[0].text += lines[i].text;
              }
              printLine(exit, 0, printedArray, ticketCopyNumber).then(function(){
                printOKLog('Copia corresponsal - última transacción');
                var alertPopup = $ionicPopup.alert({
                  title: "Información",
                  template: "Corte su copia y pulse Aceptar para imprimir la copia del cliente",
                  okText: "Aceptar",
                });
                alertPopup.then(() => {
                  $window.DatecsPrinter.printImage(
                    constant.logoB64, //base64
                    constant.logoW,
                    constant.logoH,
                    1,
                    function () {
                      ticketCopyNumber++;
                      printedArray.push('Logo copia ' + ticketCopyNumber);
                      var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{center}*****Copia Para Cliente*****{br}"}]
                      for (let i = 0; i < lines.length; i++) {
                        exit[0].text += lines[i].text;
                      }
                      printLine(exit, 0, printedArray, ticketCopyNumber).then(function(){
                          printOKLog('Copia cliente - última transacción');
                        }, function(err){
                          hidePrinting();
                          errorLog(err, lines);
                          askPrintAgainLastTicket(lines);
                        }
                      );
                    },
                    function (error) {
                      hidePrinting();
                      errorLog(error, lines);
                      askPrintAgainLastTicket(lines);
                    }
                  );
                });
              }, function(err){
                hidePrinting();
                errorLog(err, lines);
                askPrintAgainLastTicket(lines);
              });
            },function (error) {
              hidePrinting();
              errorLog(error, lines);
              askPrintAgainLastTicket(lines);
            }
          );
        }, 500);
        break;
    }
  }

  function askPrintAgainLastTicket(lines){
    var alertPopup = $ionicPopup.confirm({
      template: 'Ha ocurrido un error mientras se imprimía el recibo. ¿Desea imprimirlo de nuevo?',
      okText: 'Si',
      cancelText: 'No',
    });
    alertPopup.then((e) => {
      if (!!e) {
        tryPrintLastTicket();
      } else {
        errorLog('Se ha producido un error con la impresora y el usuario no ha querido reimprimir el recibo del ultimo ticket emitido', lines);
        doNavigate('menu.homeCustomer');
      }
    });
  }

  /**
   * Método que imprime el cuadre en el ticket.
   * @param lines
   */
  function printBoxTicket(lines){
    showPrinting();
    switch (constant.connected) {
      case constant.printers[0]:
        setTimeout(function () {
          $window.DatecsPrinter.printImage(
            constant.logoB64, //base64
            constant.logoW,
            constant.logoH,
            1,
            function () {
              var exit = [{text: "{br}{center} FINANCIERA CONFIANZA S.A.A. {br}{br}{center}****Copia Para Corresponsal****{br}"}]
              for (let i = 0; i < lines.length; i++) {
                exit[0].text += lines[i].text;
              }
              DatecsPrinter.printText(exit[0].text, 'ISO-8859-1', function () {
                printOKLog('Impresión cuadre');
                hidePrinting();
              }, function (error) {
                hidePrinting();
                console.log(error)
                printerErrorNoTest("Se ha producido un error con la impresora. Por favor, verifique que se encuentra encendida y con papel.", lines);
              });
              hidePrinting();
            },
            function (error) {
              hidePrinting();
              console.log(error)
              printerErrorNoTest("Se ha producido un error con la impresora. Por favor, verifique que se encuentra encendida y con papel.", lines);
            }
          );
        }, 500);
        break;
    }
  }

  /**
   * Genera las lineas de un ticket con error
   * @param title (string)
   * @param message (string)
   * @returns {Array}
   */
  function generateErrorTicket(title, message){
    var ticketLines = [];
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    var t = new Date();
    var day = t.getDate() + "-" + (t.getMonth() - (-1)) + "-" + t.getFullYear() + "\t{right}" + t.getHours() + ":" + t.getMinutes() + ":" + t.getSeconds();
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: "CORRESPONSAL{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: config.cabecera.codCorresponsal + "{br}"});
    ticketLines.push({text: "{center}"});
    ticketLines.push({text: config.cabecera.nombre + "{br}"});
    ticketLines.push({text: "{br}"});
    ticketLines.push({text: "{left}"});
    ticketLines.push({text: "Tipo de transacción:{br}"});
    ticketLines.push({text: title + "{br}{br}"});
    ticketLines.push({text: "{center}*****************************{br}"});
    ticketLines.push({text: "{center}{b}*****************************{/b}{br}"});
    ticketLines.push({text: "{center}*****************************{br}"});
    ticketLines.push({text: "{center}{b}*** TRANSACCIóN RECHAZADA ***{/b}{br}"});
    ticketLines.push({text: "{center}*****************************{br}"});
    ticketLines.push({text: "{center}{b}*****************************{/b}{br}"});
    ticketLines.push({text: "{center}*****************************{br}{br}"});
    ticketLines.push({text: day});
    ticketLines.push({text: "{br}{br}"});
    ticketLines.push({text: message});
    ticketLines.push({text: "{br}{br}"});
    ticketLines.push({text: "{center}{s}" + constant.disclaimer + "{/s}"});
    ticketLines.push({text: "{br}{br}{br}{br}{br}{br}{br}"});
    return ticketLines;
  }

  /**
   * Genera las lineas de un ticket de cuadre
   * @param boxData
   * @returns {Array}
   */
  function generateBoxTicket(boxData){
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    var lines = [];
    var t = new Date();
    var day = $filter('date')(t, 'dd/MM/yyyy h:mm a');
    lines.push({text: "{center}"});
    lines.push({text: "CORRESPONSAL{br}"});
    lines.push({text: "{center}"});
    lines.push({text: config.cabecera.codCorresponsal});
    lines.push({text: "{br}{br}"});
    lines.push({text: "Cuadre diario impreso a:"});
    lines.push({text: "{br}"});
    lines.push({text: day});
    lines.push({text: "{br}CUADRE DIARIO del día:"});
    lines.push({text: "{br}"});
    lines.push({text: $filter('date')(boxData.date, 'dd/MM/yyyy')});
    lines.push({text: "{br}{br}"});
    lines.push({text: "Saldo inicial: S/ " + $filter('number')(boxData.ini, 2)});
    lines.push({text: "{br}"});
    for (var i = 0; i < boxData.lines.length; i++) {
      lines.push({text: "{br}" + boxData.lines[i].numTx + " " + boxData.lines[i].nombre + ":  {br}" + (!!boxData.lines[i].simbolo ? boxData.lines[i].simbolo : '') + "S/ " + $filter('number')(boxData.lines[i].valor, 2)});
      lines.push({text: "{br}"});
    }
    lines.push({text: "{br}-------------------------------"});
    lines.push({text: "{br}{br}{b}Cupo utilizado: " + boxData.quota + "{/b}{br}"});
    lines.push({text: "{br}-------------------------------"});
    for (var i = 0; i < boxData.revs.length; i++) {
      lines.push({text: "{br}" + boxData.revs[i].numTx + " " + boxData.revs[i].nombre + ":  {br}" + (!!boxData.revs[i].simbolo ? boxData.revs[i].simbolo : '') + "S/ " + $filter('number')(boxData.revs[i].valor, 2)});
      lines.push({text: "{br}"});
    }
    lines.push({text: "{br}Saldo neto efectivo: S/ " + $filter('number')(boxData.end, 2)});
    lines.push({text: "{br}{br}"});
    lines.push({text: "{center}{s}" + constant.disclaimer + "{/s}"});
    lines.push({text: "{br}{br}{br}{br}{br}{br}{br}"});

    return lines;
  }


  /* ------------------------- FUNCIONES PRINCIPALES -------------------------*/
  /**
   * Conecta con la impresora siempre y cuando no exista una conexion previa.
   * Si no consigue conectarse se convierte en bucle con la opción de salir.
   */
  function tryPrinterConnect(){
    if (!$ionicPlatform.is('browser')) {
      if (!parseInt(localStorage.getItem('connectedPrinter'))) {
        tryBluetoothPairing().then(
          function (resolve) {
            printSimpleText('{center}{br}');
          }, function (reject) {
            var alertPopup = $ionicPopup.confirm({
              template: 'No ha sido posible conectar la impresora',
              okText: 'Volver a intentar',
              cancelText: 'Salir',
            });
            alertPopup.then((e) => {
              if (!!e) {
                tryPrinterConnect();
              } else {
                errorLog('No es posible conectar con ninguna impresora. Asegúrese de que está encendida y operativa antes de continuar.', "No se puede conectar con ninguna impresora");
                logOut();
              }
            });
          }
        );
      } else {
        printSimpleText('{center}{br}');
      }
    }
  }

  /**
   * Intentamos la conexion (si no la tiene) e imprimimos.
   * @param lines (Texto a imprimir)
   */
  function tryPrintTicket(lines){
    try {
      if(!parseInt(localStorage.getItem('connectedPrinter'))) {
        tryBluetoothPairing().then(
          function(resolve) {
            printTicket(lines);
          }, function(reject){
            printerError("No es posible conectar con ninguna impresora", lines);
            reversionService.doReversion();
          }
        );
      } else {
        printTicket(lines);
      }
    } catch(err) {
      printerError("No es posible conectar con ninguna impresora", lines);
      reversionService.doReversion();
    }
  }

  function tryPrintOnlyClientTicket(lines){
    try {
      if(!parseInt(localStorage.getItem('connectedPrinter'))) {
        tryBluetoothPairing().then(
          function(resolve) {
            printOnlyClientTicket(lines);
          }, function(reject){
            printerError("No es posible conectar con ninguna impresora", lines);
            reversionService.doReversion();
          }
        );
      } else {
        printOnlyClientTicket(lines);
      }
    } catch(err) {
      printerError("No es posible conectar con ninguna impresora", lines);
      reversionService.doReversion();
    }
  }

  /**
   * Intenta imprimir la ultima transaccion que tenemos guardado en localstorage
   * @returns {boolean}
   */
  function tryPrintLastTicket() {
    var lastTx = JSON.parse(localStorage.getItem("bm-last-ticket"));
    if (!lastTx) {
      var alertPopup = $ionicPopup.alert({
        title: "Información",
        template: "No tiene ningún ticket para imprimir.",
        okText: "Aceptar",
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    } else {
      var alertPopup = $ionicPopup.alert({
        title: "Información",
        template: "Va a realizar la reimpresión de su último recibo.",
        okText: "Aceptar",
      });
      alertPopup.then(() => {
        if(!parseInt(localStorage.getItem('connectedPrinter'))) {
          tryBluetoothPairing().then(
            function(resolve) {
              if (lastTx[0].text.indexOf('++R') == -1) {
                lastTx.unshift({text: "{center}++REIMPRESIÓN++{br}"});
              }
              constant.reprinting = true;
              printLastTicket(lastTx);
            }, function(reject){
              printerError("No es posible conectar con ninguna impresora", lastTx);
            }
          );
        } else {
          if (lastTx[0].text.indexOf('++R') == -1) {
            lastTx.unshift({text: "{center}++REIMPRESIÓN++{br}"});
          }
          constant.reprinting = true;
          printLastTicket(lastTx);
        }
        return false;
      });
      return false;
    }
  }

  /**
   * Funcion principal para imprimir el cuadre.
   * @param boxData
   */
  function tryPrintBox(boxData) {
    if(!parseInt(localStorage.getItem('connectedPrinter'))) {
      tryBluetoothPairing().then(
        function(resolve) {
          printBoxTicket(generateBoxTicket(boxData));
        }, function(reject){
          printerError("No es posible conectar con ninguna impresora", "Impresión del cuadre diario");
        }
      );
    } else {
      printBoxTicket(generateBoxTicket(boxData));
    }
  }

  /**
   * Imprime un ticket con error
   * @param title (string)
   * @param message (string)
   */
  function tryPrintErrorTicket(title, message) {
    tryPrintTicket(generateErrorTicket(title, message));
  }

  /* -------------------------METRICAS------------------------- */

  function printOKLog(msg) {
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    $rootScope.$emit('metrics-custom', {
      event: 'evento: impresión satisfactoria',
      tag: 'Impresión',
      data: [{
        name: "msg",
        value: JSON.stringify(msg)
      },
        {
          name: "datos",
          value: JSON.stringify({
            fecha: $filter('date')((new Date()).getTime(), 'yyyy/MM/dd hh:mm:ss'),
            corresponsal: config.cabecera.codCorresponsal
          })
        }]
    });
  }

  function errorLog(msg, ticket) {
    var config = JSON.parse(localStorage.getItem("bm-configuracion"));
    $rootScope.$emit('metrics-custom', {
      event: 'evento: Error de impresión',
      tag: 'Impresión',
      data: [{
        name: "msg",
        value: JSON.stringify(msg)
      },
        {
          name: "ticket",
          value: JSON.stringify(ticket)
        },
        {
          name: "datos",
          value: JSON.stringify({
            fecha: $filter('date')((new Date()).getTime(), 'yyyy/MM/dd hh:mm:ss'),
            corresponsal: config.cabecera.codCorresponsal
          })
        }]
    });
  }

  function printerError(msg, lines) {
    hideLoader();
    errorLog(msg, lines);
    var alertPopup = $ionicPopup.alert({
      title: "Información",
      template: msg,
      okText: "Aceptar",
    });
    alertPopup.then(() => {
      doNavigate('menu.homeCustomer');
    });
  }

  function printerErrorNoTest(msg, lines) {
    hideLoader();
    errorLog(msg, lines);
    var alertPopup = $ionicPopup.alert({
      title: "Información",
      template: msg,
      okText: "Aceptar",
    });
    alertPopup.then(() => {
    });
  }

  /** -------------------------FUNCIONES EXTRAS------------------------- */

  function showPrinting() {
    constant.printingPopup = $ionicPopup.confirm({
      cssClass: 'popup-big popup-printing',
      template: '<img src="./public/img/imprimiendo.gif"/><br/><b>Imprimiendo Comprobante</b>',
    });
  }

  function hidePrinting() {
    if(!!constant.printingPopup) {
      constant.printingPopup.close();
    }
  }

  function showLoader() {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
  }

  function hideLoader() {
    $ionicLoading.hide();
  }

  function logOut(){
    authFactory.logout()
      .then(() => {
        $ionicLoading.hide();
      })
      .catch(() => {
        $ionicLoading.hide();
      });
    localStorage.removeItem('ngStorage-accessToken');
    localStorage.removeItem('bm-configuracion');
    doNavigate('login');
  }

  function doNavigate(path){
    $state.go(path);
  }

  return result;
}
export default printerService;

/*
 address:"00:01:90:C0:FE:1E"
 class:7936
 id:"00:01:90:C0:FE:1E"
 name:"DPP-250"              
 */