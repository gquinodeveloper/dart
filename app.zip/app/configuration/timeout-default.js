/* eslint-disable */


defaultTimeOut.$inect = ['$httpProvider'];

function defaultTimeOut($httpProvider) {
  $httpProvider.defaults.timeout = 1000 * 10;
}


export default defaultTimeOut;