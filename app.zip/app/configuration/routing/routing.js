routing.$inject = ['$urlRouterProvider'];

function routing($urlRouterProvider) {

  $urlRouterProvider.otherwise('/login');

}

export default routing;