//uiRouterEvents.$inject = ['$rootScope', '$state'];
//
//function uiRouterEvents($rootScope, $state) {
//  /*
//    UI-ROUTER events
//
//    $stateChangeStart     event, toState, toParams, fromState, fromParams, options
//    $stateNotFound        event, unfoundState, fromState, fromParams
//    $stateChangeSuccess   event, toState, toParams, fromState, fromParams
//    $stateChangeError     event, toState, toParams, fromState, fromParams, error
//    $viewContentLoading   event, viewConfig
//    $viewContentLoaded    event
//   */
//
//  // let stateChangeSuccessHandler = $rootScope.$on('$stateChangeSuccess',
//  //   function(event, toState, toParams, fromState) {
//  //     $rootScope.$emit('metrics-pagina-vista', toState.url, fromState.url);
//  //   });
//
//  // let stateChangeStartHandler = $rootScope.$on('$stateChangeStart',
//  //   function(event, toState, toParams, fromState){
//  //     $rootScope.$emit('metrics-navegacion-hacia', toState.url, fromState.url);
//  //   });
//
//  // let stateChangeErrorHandler = $rootScope.$on('$stateChangeError',
//  //   function(event, toState, toParams, fromState, fromParams, error){
//  //     $rootScope.$emit('metrics-error-navegacion', toState.url, fromState.url, error);
//  //   });
//
//  // let stateNotFoundHandler = $rootScope.$on('$stateNotFound',
//  //   function(event, unfoundState, fromState){
//  //     $rootScope.$emit('metrics-error-pagina-no-encontrada', unfoundState.to, fromState.url);
//  //   });
//
//  let deregisterationStateChangeError = $rootScope.$on('$stateChangeError',
//    function (event) {
//      event.preventDefault();
//      $state.go('tour');
//    });
//
//  $rootScope.$on('$destroy', function () {
//    deregisterationStateChangeError();
//  });
//
//  $rootScope.$on('$destroy', function() {
//    // stateChangeSuccessHandler();
//    // stateChangeStartHandler();
//    // stateChangeErrorHandler();
//    // stateNotFoundHandler();
//    deregisterationStateChangeError();
//  });
//
//
//}
//
//export default uiRouterEvents;
