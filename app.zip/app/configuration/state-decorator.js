/** @module ptiApp/auth/stateDecorator
 * @description ## *config: stateDecorator*  <br>
 * Decora **$state** para esté disponible en el resolve de las rutas de ui-router el parametro
 * **next y toParams**. Para poder conocer hacia que ruta se dirige la transición.<br>
 * {@link http://stackoverflow.com/questions/22985988/angular-ui-router-get-state-info-of-tostate-in-resolve}
 * @requires $provide
 */

/* eslint-disable */

stateDecorator.$inject = ['$provide'];

function stateDecorator($provide) {

  $provide.decorator('$state', function ($delegate, $rootScope) {
    $rootScope.$on('$stateChangeStart', function (event, state, params) {
      $delegate.next     = state;
      $delegate.toParams = params;
    });

    return $delegate;
  });
}

export default stateDecorator;