WithdrawWayController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope','$rootScope', 'printerService', '$filter', 'cyptojsService'];

/**
 * @class corresponsales.customer_WithdrawWayController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @returns {undefined}
 */
function WithdrawWayController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope, printerService, $filter, cyptojsService) {
  let withdrawWay = this;
  menuActive.active = 1;
  withdrawWay.data = {
    homeData: {},
    document: {
      label: "DNI",
      value: "21"
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
    documentNumber: '',
    accountNumber: '',
    popUp: null
  };

  withdrawWay.texts = {
    title: "Retirar dinero",
    info: "Información",
    ok: "Aceptar",
    numberPlaceholder: "Número de documento",
    accountPlaceholder: "Número de cuenta",
    getAccounts: "Consultar cuentas >",
    getAccount: "Consultar cuenta >",
    usingDocument: "Acceder ingresando DOI:",
    usingAccount: "O introducir número de cuenta:",
    switchOn: "Nº de cuenta",
    switchOff: "Documento",
    otp: "Introduzca el OTP que ha recibido el cliente en su celular",
    err001: "Complete el formulario para continuar.",
    err002: "Cliente sin operaciones que permitan hacer un retiro.",
    err003: "OTP incorrecta. La OTP debe ser numérica.",
    err004: "OTP incorrecta. La longitud del OTP es de 6 caracteres.",
    err005: "OTP incorrecta.",
    err006: "No existe ese número de cuenta. Revise los datos introducidos.",
    err007: "El número de cuenta debe contener 12 dígitos."
  };

  /**
   * @memberOf corresponsales.customer_WithdrawWayController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  withdrawWay.initLoad = () => {
    $scope.$emit("titleChange", withdrawWay.texts.title);
  };
  withdrawWay.initLoad();

  /**
   * @memberOf corresponsales.customer_WithdrawWayController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  withdrawWay.doNavigate = (path) => {
    $state.go(path);
  };

  withdrawWay.validateOtp = (eOtp) => {
    if ((eOtp + "").length != 6) {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP longitud incorrecta',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP con una longitud incorrecta (!=6) en consulta de cuentas de retiros."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: withdrawWay.texts.info,
        template: withdrawWay.texts.err004,
        okText: withdrawWay.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP is NaN',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP isNaN en consulta de cuentas de retiros."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: withdrawWay.texts.info,
        template: withdrawWay.texts.err003,
        okText: withdrawWay.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else {
      return true;
    }
  };

  /**
   * @memberOf corresponsales.customer_WithdrawWayController
   * @name getAccounts
   * @description función que realiza la buscqueda en servidor de todas las cuentas de un usuario seleccionado mediante tipo de documento y número
   * @returns {undefined} la función emite el cambio de título
   */
  withdrawWay.getAccounts = () => {
    if (!!withdrawWay.data.popup) {
      withdrawWay.data.popup.close();
      withdrawWay.data.popup = null;
      return false;
    }
    if (!withdrawWay.data.document.value || !withdrawWay.data.documentNumber) {
      var alertPopup = $ionicPopup.alert({
        title: withdrawWay.texts.info,
        template: withdrawWay.texts.err001,
        okText: withdrawWay.texts.ok,
      });
      withdrawWay.data.popup = alertPopup;
      alertPopup.then(() => {
        withdrawWay.data.popup = null;
      });
    } else {
      if ( ( withdrawWay.data.document.value == '21' || withdrawWay.data.document.value == '25' ) && (withdrawWay.data.documentNumber.length < withdrawWay.docTypeLimits(withdrawWay.data.document.value))){
        var alertPopup = $ionicPopup.alert({
          title: withdrawWay.texts.info,
          template: 'Es necesario introducir '+ withdrawWay.docTypeLimits(withdrawWay.data.document.value) +' dígitos',
          okText: withdrawWay.texts.ok,
        });
        withdrawWay.data.popup = alertPopup;
        alertPopup.then(() => {
          withdrawWay.data.popup = null;
        });
        return false;
      }
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "86361b9cf75b7182";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.otpCuentas.get.call({
        tipoDoc: withdrawWay.data.document.value + "",
        numDoc: withdrawWay.data.documentNumber + "",
        udid: udid,
      }).then((data) => {
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.prompt({
          title: withdrawWay.texts.otp,
          okText: withdrawWay.texts.continue,
          cancelText: withdrawWay.texts.cancel,
          inputType: 'text',
          inputPlaceholder: 'OTP'
        });
        withdrawWay.data.popup = alertPopup;
        alertPopup.then((eOtp) => {
          withdrawWay.data.popup = null;
          if (!!eOtp) {
            $ionicLoading.show({
              template: '<ion-spinner icon="ripple"></ion-spinner>',
              hideOnStateChange: true
            });
            if(withdrawWay.validateOtp(eOtp)) {
              swagger.api.corresponsales.cuentas.get.call({
                tipoOp: '4',
                tipoDoc: withdrawWay.data.document.value,
                numDoc: withdrawWay.data.documentNumber + "",
                udid: udid,
                otpEncriptado: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(data.data.message)),
                numTx: data.data.message
              }).then((data) => {
                $ionicLoading.hide();
                if (data.data.cuentas.length == 0) {
                  var alertPopup = $ionicPopup.alert({
                    title: withdrawWay.texts.info,
                    template: withdrawWay.texts.err002,
                    okText: withdrawWay.texts.ok,
                  });
                  withdrawWay.data.popup = alertPopup;
                  alertPopup.then(() => {
                    withdrawWay.data.popup = null;
                    printerService.printErrorTicket("Retiro", withdrawWay.texts.err002);
                  });
                } else {
                  data.data.tipoDoc = withdrawWay.data.document;
                  data.data.numDoc = withdrawWay.data.documentNumber;
                  localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
                  withdrawWay.doNavigate('menu.withdrawAccounts');
                }
              }).catch((err) => {
                $ionicLoading.hide();
                $rootScope.$emit('metrics-custom', {
                  event: 'Error en respuesta de servicio',
                  tag: 'Cuentas',
                  data: [{
                    name: "msg",
                    value: JSON.stringify(err)
                  }]
                });
                var alertPopup = $ionicPopup.alert({
                  title: withdrawWay.texts.info,
                  template: err.data.message,
                  okText: withdrawWay.texts.ok,
                });
                withdrawWay.data.popup = alertPopup;
                alertPopup.then(() => {
                  withdrawWay.data.popup = null;
                  // printerService.printErrorTicket("Retiro", err.data.message);
                });
              });
            }
          }
        });
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error generando OTP cuentas retiros',
          tag: 'Cuentas',
          data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: withdrawWay.texts.info,
          template: (!!err.data.message ? err.data.message : "ERROR GENERANDO OTP" ),
          okText: withdrawWay.texts.ok,
        });
        withdrawWay.data.popup = alertPopup;
        alertPopup.then(() => {
          withdrawWay.data.popup = null;
        });
      });
    }
  };

  withdrawWay.getAccount = () => {
    if (!!withdrawWay.data.accountNumber) {
      if (withdrawWay.data.accountNumber.length < 12){
        var alertPopup = $ionicPopup.alert({
          title: withdrawWay.texts.info,
          template: withdrawWay.texts.err007,
          okText: withdrawWay.texts.ok,
        });
        withdrawWay.data.popup = alertPopup;
        alertPopup.then(() => {
          withdrawWay.data.popup = null;
        });
        return false;
      }
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "86361b9cf75b7182";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.cuentas.get.call({
        tipoOp: '4',
        numProd: withdrawWay.data.accountNumber + "",
        udid: udid
      }).then((data) => {
        $ionicLoading.hide();
        if (data.data.cuentas.length == 0) {
          var alertPopup = $ionicPopup.alert({
            title: withdrawWay.texts.info,
            template: withdrawWay.texts.err006,
            okText: withdrawWay.texts.ok,
          });
          withdrawWay.data.popup = alertPopup;
          alertPopup.then(() => {
            withdrawWay.data.popup = null;
          });
        } else {
          let valueTipoDoc = data.data.tipoDoc;
          data.data.tipoDoc = $filter('filter')(withdrawWay.data.documents, {'value': valueTipoDoc});
          data.data.searchAccByAcc = true;
          localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
          withdrawWay.doNavigate('menu.withdrawAccounts');
        }
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error en respuesta de servicio',
          tag: 'Cuentas',
          data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: withdrawWay.texts.info,
          template: err.data.message,
          okText: withdrawWay.texts.ok,
        });
        withdrawWay.data.popup = alertPopup;
        alertPopup.then(() => {
          withdrawWay.data.popup = null;
          // printerService.printErrorTicket("Retiro", err.data.message);
        });
      });
    } else {
      var alertPopup = $ionicPopup.alert({
        title: withdrawWay.texts.info,
        template: withdrawWay.texts.err001,
        okText: withdrawWay.texts.ok,
      });
      withdrawWay.data.popup = alertPopup;
      alertPopup.then(() => {
        withdrawWay.data.popup = null;
      });
    }
  };

  withdrawWay.docTypeLimits = (docType) => {
    switch (docType){
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  withdrawWay.limitFieldsTo = (newVal,oldVal,limit) => {
    if(newVal.length > limit){
      withdrawWay.data.documentNumber = oldVal;
    } else {
      withdrawWay.data.documentNumber = newVal;
    }
  };

  $scope.$watch("withdrawWay.data.documentNumber", function(newVal, oldVal) {
    withdrawWay.limitFieldsTo(newVal,oldVal,withdrawWay.docTypeLimits(withdrawWay.data.document.value));
  });

  $scope.$watch("withdrawWay.data.document.value", function(newVal, oldVal) {
    withdrawWay.data.documentNumber = '';
  });

}

export default WithdrawWayController;
