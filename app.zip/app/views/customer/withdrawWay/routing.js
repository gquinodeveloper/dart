routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.withdrawWay', {
            url: '/withdrawWay',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/withdrawWay/template.html',
                controllerAs: 'withdrawWay',
                controller: "WithdrawWayController"
              }
            }
          });
}

export default routing;
