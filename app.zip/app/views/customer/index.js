import HomeCustomerController from './homeCustomer/controller';
import HomeCustomerRouting from './homeCustomer/routing';

import DepositWayController from './depositWay/controller';
import DepositWayRouting from './depositWay/routing';
import DepositAccountsController from './depositAccounts/controller';
import DepositAccountsRouting from './depositAccounts/routing';
import DepositOperateController from './depositOperate/controller';
import DepositOperateRouting from './depositOperate/routing';

import PayWayController from './payWay/controller';
import PayWayRouting from './payWay/routing';
import PayAccountsController from './payAccounts/controller';
import PayAccountsRouting from './payAccounts/routing';
import PayOperateController from './payOperate/controller';
import PayOperateRouting from './payOperate/routing';

import WithdrawWayController from './withdrawWay/controller';
import WithdrawWayRouting from './withdrawWay/routing';
import WithdrawAccountsController from './withdrawAccounts/controller';
import WithdrawAccountsRouting from './withdrawAccounts/routing';
import WithdrawOperateController from './withdrawOperate/controller';
import WithdrawOperateRouting from './withdrawOperate/routing';

import RegisterController from './register/controller';
import RegisterRouting from './register/routing';

import CreditRequestController from './creditRequest/controller';
import CreditRequestRouting from './creditRequest/routing';

export default angular.module('CustomerModule', [
  'ui.router',
  'ionic'
])

        .controller('HomeCustomerController', HomeCustomerController)
        .config(HomeCustomerRouting)

        .controller('DepositWayController', DepositWayController)
        .config(DepositWayRouting)
        .controller('DepositAccountsController', DepositAccountsController)
        .config(DepositAccountsRouting)
        .controller('DepositOperateController', DepositOperateController)
        .config(DepositOperateRouting)

        .controller('WithdrawWayController', WithdrawWayController)
        .config(WithdrawWayRouting)
        .controller('WithdrawAccountsController', WithdrawAccountsController)
        .config(WithdrawAccountsRouting)
        .controller('WithdrawOperateController', WithdrawOperateController)
        .config(WithdrawOperateRouting)

        .controller('PayWayController', PayWayController)
        .config(PayWayRouting)
        .controller('PayAccountsController', PayAccountsController)
        .config(PayAccountsRouting)
        .controller('PayOperateController', PayOperateController)
        .config(PayOperateRouting)

        .controller('RegisterController', RegisterController)
        .config(RegisterRouting)

        .controller('CreditRequestController', CreditRequestController)
        .config(CreditRequestRouting)

        .name;
