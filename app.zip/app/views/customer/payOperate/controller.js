PayOperateController.$inject = ['menuActive', 'swagger', '$state', '$ionicPopup', '$scope', '$ionicLoading', '$filter', '$rootScope', 'reversionService', 'txFailureService', 'cyptojsService', '$http'];

/**
 * @class corresponsales.Customer_PayOperateController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param {Object} cyptojsService - Servicio propio con funciones de encriptación
 * @param {function} $http - Función que facilita la comunicación con los servidores HTTP a través del navegador
 * @returns {undefined}
 */
function PayOperateController(menuActive, swagger, $state, $ionicPopup, $scope, $ionicLoading, $filter, $rootScope, reversionService, txFailureService, cyptojsService, $http) {
  let payOperate = this;
  menuActive.active = 1;
  payOperate.data = {
    transactionData: {},
    popUp: null,
    ammount: '',
    payTotal: true,
    totalAmmount: 0,
    minAmmount: 0,
    chargeOffType: {
      label: "Próximas cuotas",
      value: "3"
    },
    chargeOffTypes: [
      {
        label: "Próximas cuotas",
        value: "3"
      },
      {
        label: "Reducción de cuota",
        value: "1"
      },
      {
        label: "Reducción de plazo",
        value: "2"
      },
    ],
    disablePayButton: false,
    errLabel: false,
    depositante: {
      nombre: '',
      apellido: '',
      document: {
        label: "DNI",
        value: "21"
      },
      numerodocumento: '',
      celular: '',
      correo: ''
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
  };

  payOperate.texts = {
    title: "Pago de cuota",
    ticketOperation: "Pago de obligación en efectivo",
    name: "Titular:",
    account: "Nº de crédito:",
    ammount: "Cantidad a ingresar:",
    toPay: "Realizar pago",
    payFee: "Parcial",
    payTotal: "Total",
    fullPayment: "Obligación de pago: ",
    cost: "Costo transacción:",
    doOperate: "Enviar comprobante >",
    howTo: "¿Cómo desea hacer su amortización anticipada?",
    chrono: "Su cronograma ha cambiado. Acuda a su oficina o llame al callcenter para consultar los cambios.",
    info: "Información",
    ok: "Aceptar",
    cancel: "Cancelar >",
    continue: "Continuar >",
    roundAmmount: "La parte decimal debe ser múltiplo de 10",
    period: "Cuota:",
    finishDate: "Fecha vencimiento:",
    datosdepositante: "Introducir datos del usuario:",
    nombresPlaceholder: "Nombres y apellidos",
    numberPlaceholder: "Número de documento",
    celularPlaceholder: "Celular",
    correoPlaceholder: "Correo electrónico",
    otp: "Introduzca el OTP que ha recibido el usuario en su celular",
    err001: "Revise la cantidad introducida.",
    err002: "La cantidad introducida no alcanza el pago mínimo para esta obligación.",
    err003: "La cantidad introducida es mayor que el total de la obligación.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde.", //Este mensaje es utilizado por las reversiones. debe ser el msmo en cada transaccion y validarse para llamar a clearData en la impresora
    err005: "Ingrese nombres y apellidos",
    err006: "Ingrese número de documento",
    err007: "Ingrese número de documento válido",
    err008: "Ingrese número de celular",
    err009: "Ingrese numéro de celular válido",
    err010: "Ingrese correo electrónico válido", 
    err011: "OTP incorrecta. La OTP debe ser numérica.",
    err012: "OTP incorrecta. La longitud del OTP es de 6 caracteres.",
    err013: "Ingrese nombres y apellidos válidos"
  };

  /**
   * @memberOf corresponsales.customer_PayOperateController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  payOperate.initLoad = () => {
    $scope.$emit("titleChange", payOperate.texts.title);
    //printerService.tryPrinterConnect();
    payOperate.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    payOperate.data.totalAmmount = payOperate.data.transactionData.selected.tot;
    payOperate.data.minAmmount = payOperate.data.transactionData.selected.min;
    payOperate.data.period = payOperate.data.transactionData.selected.cuota;
    payOperate.data.periodDate = payOperate.data.transactionData.selected.fec;

    let firebaseConexion = require('../../../configuration/default-config.json').firebase.config;
    console.log('config firebase');

    var config = firebaseConexion;

    if (!firebase.apps.length) {
      // Initialize Firebase
      firebase.initializeApp(config);
    }
  };

  payOperate.initLoad();

  payOperate.doPayment = () =>{

    payOperate.data.disablePayButton = true;    

    if(!payOperate.data.payTotal) {
      if (!payOperate.validateAmmount()) {
        payOperate.data.disablePayButton = false;
        return false;
      }
    }

    if(!payOperate.validateDepositante()) {
      payOperate.data.disablePayButton = false;
      return false;
    }

    if (!!payOperate.data.popup) {
      payOperate.data.popup.close();
      payOperate.data.popup = null;
      payOperate.data.disablePayButton = false;
      return false;
    }

    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }

    let datosBody = {
      datosBody: {
        tipoDoc: payOperate.data.depositante.document.value,
        numDoc: payOperate.data.depositante.numerodocumento,
        telefono: payOperate.data.depositante.celular,
        udid: udid,
      }
    };
    swagger.api.corresponsales.datosClausula.post.call(datosBody).then((res) => {
      if(res.data.codMensaje == "0") {
        //Sin autorización de uso de datos
        swagger.api.corresponsales.otpAutorizacion.get.call({      
          tipoDoc: payOperate.data.depositante.document.value,
          numDoc: payOperate.data.depositante.numerodocumento,    
          numTelefono: payOperate.data.depositante.celular,
          udid: udid,
        }).then((data) => {
          $ionicLoading.hide();
          var alertPopup = $ionicPopup.prompt({
            title: payOperate.texts.otp,
            okText: payOperate.texts.continue,
            cancelText: payOperate.texts.cancel,
            inputType: 'text',
            inputPlaceholder: 'OTP'
          });
          payOperate.data.popup = alertPopup;
          alertPopup.then((eOtp) => {
            payOperate.data.popup = null;
            if (!!eOtp) {
              $ionicLoading.show({
                template: '<ion-spinner icon="ripple"></ion-spinner>',
                hideOnStateChange: true
              });
              if(payOperate.validateOtp(eOtp)) {
                let datosBodyReg = {
                  datosBody: {
                    tipoDoc: payOperate.data.depositante.document.value,
                    numDoc: payOperate.data.depositante.numerodocumento,
                    telefono: payOperate.data.depositante.celular,
                    otpEncriptado: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(data.data.message)),
                    numTx: data.data.message,
                    udid: udid,
                  }
                };
                console.log('datosBodyReg :', datosBodyReg);
                swagger.api.corresponsales.registroClausula.post.call(datosBodyReg).then((dataReg) => {
                  $ionicLoading.hide();
                  console.log('Rpta Reg Clausula', dataReg);
                  (payOperate.data.payTotal) ? payOperate.doFullPayment(udid) : payOperate.doPartialPayment(udid);
                }).catch((err) => {
                  payOperate.data.disablePayButton = false;
                  $ionicLoading.hide();
                  $scope.$emit('metrics-custom', {
                    event: 'Error en respuesta de servicio',
                    tag: 'Autorización - identificacion usuario',
                    data: [{
                      name: "msg",
                      value: JSON.stringify(err)
                    }]
                  });
                  var alertPopup = $ionicPopup.alert({
                    title: payOperate.texts.info,
                    template: err.data.message,
                    okText: payOperate.texts.ok,
                  });
                  payOperate.data.popup = alertPopup;
                  alertPopup.then(() => {
                    payOperate.data.popup = null;
                  });
                });
              }             
            } else {
              payOperate.data.disablePayButton = false;
            }
          });
        }).catch((err) => {
          payOperate.data.disablePayButton = false;
          $ionicLoading.hide();
          $scope.$emit('metrics-custom', {
            event: 'Error generando OTP autorización de datos',
            tag: 'Autorización',
            data: [{
              name: "msg",
              value: JSON.stringify(err)
            }]
          });
          var alertPopup = $ionicPopup.alert({
            title: payOperate.texts.info,
            template: (!!err.data.message ? err.data.message : "ERROR GENERANDO OTP" ),
            okText: payOperate.texts.ok,
          });
          payOperate.data.popup = alertPopup;
          alertPopup.then(() => {
            payOperate.data.popup = null;
          });
        });
      } else {
        //Ya registrado
        (payOperate.data.payTotal) ? payOperate.doFullPayment(udid) : payOperate.doPartialPayment(udid);
      }

    }).catch((err) => {
      payOperate.data.disablePayButton = false;
      $ionicLoading.hide();
      console.log('Err :', err);
    });
  };

  payOperate.validateOtp = (eOtp) => {
    if ((eOtp + "").length != 6) {
      $ionicLoading.hide();
      payOperate.data.disablePayButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP longitud incorrecta',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP con una longitud incorrecta (!=6) en registro de claúsula."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: payOperate.texts.err012,
        okText: payOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
      $ionicLoading.hide();
      payOperate.data.disablePayButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP is NaN',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP isNaN en registro de claúsula."
        }]
      });
      let alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: payOperate.texts.err011,
        okText: payOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else {
      return true;
    }
  };

  payOperate.doFullPayment = (udid) => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    
    swagger.api.corresponsales.costo.get.call({
      monto: payOperate.data.transactionData.selected.tot * 1,
      id: payOperate.data.transactionData.selected.id,
      tipoOp: "2",
      udid: udid
    }).then((data) => {
      payOperate.data.ammount = payOperate.data.transactionData.selected.tot * 1;
      $ionicLoading.hide();
      localStorage.setItem("bm-tx-id", data.data.idTx);
      var template = '<b>Vas a pagar:</b>' +
        '<label class="primary-label">S/ ' + $filter('number')(payOperate.data.ammount, 2) + '</label>' +
        '<b>en la siguiente obligación:</b>' +
        '<span>Titular</span>' +
        '<label class="primary-label">' + payOperate.data.transactionData.titular + '</label>' +
        '<span>' + (!!payOperate.data.transactionData.tipoDoc.label ? payOperate.data.transactionData.tipoDoc.label : '') + '</span>' +
        '<label class="primary-label">' + (!!payOperate.data.transactionData.numDoc ? payOperate.data.transactionData.numDoc : '') + '</label>' +
        '<span>' + payOperate.texts.account + '</span>' +
        '<label class="primary-label">' + payOperate.data.transactionData.selected.num + '</label>' +
        '<span>' + payOperate.texts.cost + '</span>' +
        '<label class="primary-label">S/ ' + (!!data.data.costo ? data.data.costo : '0.00') + '</label>' +
        '<b>¿Desea continuar con la operación?</b>';
      var alertPopup = $ionicPopup.confirm({
        cssClass: 'popup-big',
        template: template,
        okText: payOperate.texts.continue,
        cancelText: payOperate.texts.cancel,
      });
      payOperate.data.popup = alertPopup;
      alertPopup.then((e) => {
        payOperate.data.disablePayButton = false;
        payOperate.data.popup = null;
        if (!!e) {
          $ionicLoading.show({
            template: '<ion-spinner icon="ripple"></ion-spinner>',
            hideOnStateChange: true
          });
          let reversionData = {
            udid: udid,
            tipoOp: "2",
            monto: payOperate.data.totalAmmount,
            tipoDoc: payOperate.data.transactionData.tipoDoc.value,
            numDoc: payOperate.data.transactionData.numDoc + "",
            tipoObligacion: "3",
            obligacion: payOperate.data.transactionData.selected,
            idTx: localStorage.getItem("bm-tx-id")
          };
          reversionService.setReversionData(reversionData);

          swagger.api.corresponsales.pago.post.call({
            pagoBody: {
              tipoDoc: payOperate.data.transactionData.tipoDoc.value + "",
              numDoc: payOperate.data.transactionData.numDoc,
              udid: udid,
              monto: payOperate.data.totalAmmount,
              tipo: "3",
              obligacion: payOperate.data.transactionData.selected,
              idTx: localStorage.getItem("bm-tx-id"),
              cuotaObl: payOperate.data.period,
              fechaObl: payOperate.data.periodDate,
              nroDoc: payOperate.data.depositante.numerodocumento + "",
              correo: payOperate.data.depositante.correo + ""
            }
          }).then((tx) => {
            $ionicLoading.hide();
            let reversionData = reversionService.clearReversionData();
            reversionData.operacion = {
              codOperacion: tx.data.codOperacion,
              codAutorizacion: tx.data.codAutorizacion
            };
            txFailureService.txFailureLauncher(reversionData);
            payOperate.saveFirebase(tx.data.filename, tx.data.pdf, tx.data.tran, tx.data.fecha, udid);
            $state.go('menu.operations', {normalizeConfiguration: true});
          }).catch((err) => {
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'Error en respuesta de servicio',
              tag: 'Error transacción pago',
              data: [{
                name: "err",
                value: JSON.stringify(err)
              },
                {
                  name: "tx",
                  value: JSON.stringify({
                    pagoBody: {
                      tipoDoc: payOperate.data.transactionData.tipoDoc.value + "",
                      numDoc: payOperate.data.transactionData.numDoc,
                      udid: udid,
                      monto: payOperate.data.totalAmmount,
                      tipo: "3",
                      obligacion: payOperate.data.transactionData.selected,
                      idTx: localStorage.getItem("bm-tx-id")
                    }
                  })
                }]
            });
            txFailureService.txFailureLauncher(reversionData);
            let alertPopup = $ionicPopup.alert({
              title: payOperate.texts.info,
              template: err.data.message,
              okText: payOperate.texts.ok,
            });
            payOperate.data.popup = alertPopup;
            alertPopup.then(() => {
              $state.go('menu.homeCustomer');
              return false;
            });
          });
        }
      });
    }).catch((err) => {
      $ionicLoading.hide();
      payOperate.data.disablePayButton = false;
      if (!err.data) {
        var alertPopup = $ionicPopup.alert({
          title: payOperate.texts.info,
          template: payOperate.texts.err004,
          okText: payOperate.texts.ok,
        });
        alertPopup.then(() => {
          //printerService.printErrorTicket(payOperate.texts.ticketOperation, payOperate.texts.err004);
          $state.go('menu.homeCustomer');
          return false;
        });
        return false;
      }
      //printerService.printErrorTicket(payOperate.texts.ticketOperation, err.data.message);
      var alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: payOperate.texts.err004,
        okText: payOperate.texts.ok,
      });
      alertPopup.then(() => {
        $state.go('menu.homeCustomer');
        return false;
      });
    });
  };

  payOperate.validateAmmount = () => {
    let err = "";
    if (isNaN(payOperate.data.ammount)) {
      err = payOperate.texts.err001;
    } else {
      if (payOperate.data.ammount * 1 < 1) {
        err = payOperate.texts.err002;
      } else if (payOperate.data.ammount * 1 > payOperate.data.totalAmmount * 1) {
        err = payOperate.texts.err003;
      }
    }
    if (err == "") {
      return true;
    } else {
      if (!!payOperate.data.popup) {
        payOperate.data.popup.close();
        payOperate.data.popup = null;
        return false;
      }
      var alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: err,
        okText: payOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    }
  };

  payOperate.validateDepositante = () => {
    let regxMail = /[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}@[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.[a-zA-Z0-9][a-zA-Z0-9\-]{0,25}/g;
    let regxNombre = /^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/g;
    if (payOperate.data.depositante.nombre.trim() == "") {
      payOperate.alertError(payOperate.texts.err005);
      return false;
    } else if (!regxNombre.test(payOperate.data.depositante.nombre.trim())) {
      payOperate.alertError(payOperate.texts.err013);
      return false;
    } else if (payOperate.data.depositante.numerodocumento.trim() == "") {
      payOperate.alertError(payOperate.texts.err006);
      return false;
    } else if ((payOperate.data.depositante.document.value == '21' || payOperate.data.depositante.document.value == '25' ||
    payOperate.data.depositante.document.value == '5' || payOperate.data.depositante.document.value == '2') &&
      (payOperate.data.depositante.numerodocumento.length < payOperate.docTypeLimits(payOperate.data.depositante.document.value))) {
        payOperate.alertError(payOperate.texts.err007);
        return false;
    } else if (payOperate.data.depositante.celular.trim() == "") {
      payOperate.alertError(payOperate.texts.err008);
      return false;
    } else if (isNaN(payOperate.data.depositante.celular)) {
      payOperate.alertError(payOperate.texts.err009);
      return false;
    } else if (payOperate.data.depositante.celular.length != 9) {
      payOperate.alertError(payOperate.texts.err009);
      return false;
    } else if (payOperate.data.depositante.celular.substring(0, 1) != "9"){
      payOperate.alertError(payOperate.texts.err009);
      return false;
    } else if (!payOperate.data.depositante.correo.trim() == "" && !regxMail.test(payOperate.data.depositante.correo)) {
      payOperate.alertError(payOperate.texts.err010);
      return false;
    } else {
      return true;
    }
  };

  payOperate.doPartialPayment = (udid) => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    swagger.api.corresponsales.costo.get.call({
      monto: payOperate.data.ammount,
      id: payOperate.data.transactionData.selected.id,
      tipoOp: "2",
      udid: udid
    }).then((data) => {
      $ionicLoading.hide();
      localStorage.setItem("bm-tx-id", data.data.idTx);
      var template = '<b>Vas a pagar:</b>' +
        '<label class="primary-label">S/ ' + $filter('number')(payOperate.data.ammount, 2) + '</label>' +
        '<b>en la siguiente obligación:</b>' +
        '<span>Titular</span>' +
        '<label class="primary-label">' + payOperate.data.transactionData.titular + '</label>' +
        '<span>' + (!!payOperate.data.transactionData.tipoDoc.label ? payOperate.data.transactionData.tipoDoc.label : '') + '</span>' +
        '<label class="primary-label">' + (!!payOperate.data.transactionData.numDoc ? payOperate.data.transactionData.numDoc : '') + '</label>' +
        '<span>' + payOperate.texts.account + '</span>' +
        '<label class="primary-label">' + payOperate.data.transactionData.selected.num + '</label>' +
        '<span>' + payOperate.texts.cost + '</span>' +
        '<label class="primary-label">S/ ' + (!!data.data.costo ? data.data.costo : '0.00') + '</label>' +
        '<b>¿Desea continuar con la operación?</b>';
      var alertPopup = $ionicPopup.confirm({
        cssClass: 'popup-big',
        template: template,
        okText: payOperate.texts.continue,
        cancelText: payOperate.texts.cancel,
      });
      payOperate.data.popup = alertPopup;
      alertPopup.then((e) => {
        payOperate.data.popup = null;
        payOperate.data.disablePayButton = false;
        if (!!e) {
          $ionicLoading.show({
            template: '<ion-spinner icon="ripple"></ion-spinner>',
            hideOnStateChange: true
          });
          var type = 3;

          if (payOperate.data.ammount * 1 > payOperate.data.minAmmount) {
            type = payOperate.data.chargeOffType.value;
          }

          let reversionData = {
            udid: udid,
            tipoOp: "2",
            monto: payOperate.data.ammount,
            tipoDoc: payOperate.data.transactionData.tipoDoc.value,
            numDoc: payOperate.data.transactionData.numDoc + "",
            tipoObligacion: type,
            obligacion: payOperate.data.transactionData.selected,
            idTx: localStorage.getItem("bm-tx-id")
          };
          reversionService.setReversionData(reversionData);

          swagger.api.corresponsales.pago.post.call({
            pagoBody: {
              tipoDoc: payOperate.data.transactionData.tipoDoc.value + "",
              numDoc: payOperate.data.transactionData.numDoc,
              udid: udid,
              monto: payOperate.data.ammount,
              tipo: type + "",
              obligacion: payOperate.data.transactionData.selected,
              idTx: localStorage.getItem("bm-tx-id"),
              cuotaObl: payOperate.data.period,
              fechaObl: payOperate.data.periodDate,
              nroDoc: payOperate.data.depositante.numerodocumento + "",
              correo: payOperate.data.depositante.correo + ""
            }
          }).then((tx) => {
            $ionicLoading.hide();
            let reversionData = reversionService.clearReversionData();
            reversionData.operacion = {
              codOperacion: tx.data.codOperacion,
              codAutorizacion: tx.data.codAutorizacion
            };
            txFailureService.txFailureLauncher(reversionData);
            payOperate.saveFirebase(tx.data.filename, tx.data.pdf, tx.data.tran, tx.data.fecha, udid);
            $state.go('menu.operations', {normalizeConfiguration: true});
          }).catch((err) => {
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'evento: Error en pago',
              tag: 'Error transacción',
              data: [{
                name: "err",
                value: JSON.stringify(err)
              },
                {
                  name: "tx",
                  value: JSON.stringify({
                    pagoBody: {
                      tipoDoc: payOperate.data.transactionData.tipoDoc.value + "",
                      numDoc: payOperate.data.transactionData.numDoc,
                      udid: udid,
                      monto: payOperate.data.ammount,
                      tipo: type + "",
                      obligacion: payOperate.data.transactionData.selected,
                      idTx: localStorage.getItem("bm-tx-id")
                    }
                  })
                }]
            });
            txFailureService.txFailureLauncher(reversionData);
            let alertPopup = $ionicPopup.alert({
              title: payOperate.texts.info,
              template: err.data.message,
              okText: payOperate.texts.ok,
            });
            payOperate.data.popup = alertPopup;
            alertPopup.then(() => {
              $state.go('menu.homeCustomer');
              return false;
            });
          });
        }
      });
    }).catch((err) => {
      $ionicLoading.hide();
      payOperate.data.disablePayButton = false;
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Costo',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      if (!err.data) {
        var alertPopup = $ionicPopup.alert({
          title: payOperate.texts.info,
          template: payOperate.texts.err004,
          okText: payOperate.texts.ok,
        });
        alertPopup.then(() => {
          //printerService.printErrorTicket(payOperate.texts.ticketOperation, payOperate.texts.err004);
          $state.go('menu.homeCustomer');
          return false;
        });
        return false;
      }
      //printerService.printErrorTicket(payOperate.texts.ticketOperation, err.data.message);
      var alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: payOperate.texts.err004,
        okText: payOperate.texts.ok,
      });
      alertPopup.then(() => {
        $state.go('menu.homeCustomer');
        return false;
      });
    });
  };

  payOperate.alertError = (texterror) => {
    payOperate.data.disablePayButton = false;
      var alertPopup = $ionicPopup.alert({
        title: payOperate.texts.info,
        template: texterror,
        okText: payOperate.texts.ok,
      });
      payOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        payOperate.data.popup = null;
      });
  };

  payOperate.docTypeLimits = (docType) => {
    switch (docType) {
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  payOperate.limitFieldsTo = (newVal, oldVal, limit) => {
    if (newVal.length > limit) {
      payOperate.data.depositante.numerodocumento = oldVal;
    } else {
      payOperate.data.depositante.numerodocumento = newVal;
    }
  };

  payOperate.saveFirebase = (filename, pdf, tran, fecha, udid) => {
    //Guardar voucher
    console.log('firebase save');

    var storage = firebase.storage();        
    var storageRef = storage.ref();
    var metadata = {
      contentType: 'application/pdf',
    };
    var storageRefVouchers = storageRef.child('vouchers').child(filename);

    var file = pdf;
    var uploadTask = storageRefVouchers.putString(file, 'base64', metadata);

    uploadTask.on('state_changed', function (snapshot) {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      console.log('Upload is ' + progress + '% done');
      switch (snapshot.state) {
        case firebase.storage.TaskState.PAUSED:
          console.log('Upload is paused');
          break;
        case firebase.storage.TaskState.RUNNING:
          console.log('Upload is running');
          break;
      }
    }, function (error) {
      var errorMessage = error.message;
      console.log(errorMessage);
    }, function () {
      uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
        console.log('File available at', downloadURL);

        let firebaseDL = require('../../../configuration/default-config.json').firebase.shortLink;
        let body = {
          "dynamicLinkInfo" : {
            "domainUriPrefix" : firebaseDL.linkFb,
            "link" : downloadURL
          }
        };
        
          $http({
            method: firebaseDL.method,
            url: firebaseDL.url,
            data: body                 
          }).then(firebaseResp => {
            console.log('success =>', firebaseResp);                        

            let datosBody = {
              datosBody : {
                fecha : fecha,
                telefono : payOperate.data.depositante.celular,
                numTx : tran,
                link : firebaseResp.data.shortLink + "",
                udid : udid
              }
            };

            console.log('datos sms =>', datosBody);

            swagger.api.corresponsales.envioVoucher.post.call(datosBody).then((respSms) => {
              console.log('Rstp Envio Voucher', respSms);
            }).catch((err) => {
              console.log('Error Envio Voucher', err);
            });

          }).catch((err) => {
            console.log('err =>', err);
          });
        });
    });
  };

  $scope.$watch('payOperate.data.payTotal', function(){
    if(payOperate.data.payTotal){
      payOperate.data.ammount = payOperate.data.totalAmmount;
    } else {
      payOperate.data.ammount = 0;
    }
  });

  $scope.$watch('payOperate.data.ammount', function(num){
    let number = num.toFixed(2) + "";
    let parts = number.split(".");
    if(parts.length > 1){
      (parts[1] % 10 == 0) ? payOperate.data.errLabel = false : payOperate.data.errLabel = true;
    }
  });

  $scope.$watch("payOperate.data.depositante.numerodocumento", function (newVal, oldVal) {
    payOperate.limitFieldsTo(newVal, oldVal, payOperate.docTypeLimits(payOperate.data.depositante.document.value));
  });
}

export default PayOperateController;
