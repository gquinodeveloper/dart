routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.payOperate', {
            url: '/payOperate',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/payOperate/template.html',
                controllerAs: 'payOperate',
                controller: "PayOperateController"
              }
            }
          });
}

export default routing;
