import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/customer/payOperate/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('PayOperateController', {'$scope': this.$scope, 'menuActive': {active:1},
        'reversionService' : {
          setReversionData: function({}){return true;},
          clearReversionData: function(){return true;},
          doReversion: function(){return true;}
        },    
        'txFailureService': {
          txFailureLauncher:function({}){return true;}
        },
        'swagger': {
          api: {
            corresponsales: {
              costo: {
                get: {
                  call: function () {return $q.when()}
                }
              }
            }
          }
        },
        'printerService':{
          printErrorTicket: function(type, text){
            return true;
          },
          connectForTicket: function([]){
            return true;
          },
          testPrinter: function(){return true;}
        }
      });
    };
}));
  
  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Customer_payOperate Controller', function () {
    it('initLoad defined', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var PayOperateController = this.createController();
      PayOperateController.initLoad();
    });
    it('doFullPayment defined', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.doFullPayment).toBeDefined();      
    });
    it('doFullPayment run', function () {
      var PayOperateController = this.createController();
      PayOperateController.doFullPayment();    
    });
    it('validateAmmount defined', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.validateAmmount).toBeDefined();      
    });
    it('validateAmmount run no ammount', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.validateAmmount()).toBeFalsy();    
    });
    it('validateAmmount run NaN ammount', function () {
      var PayOperateController = this.createController();
      PayOperateController.data.ammount = "----";
      expect(PayOperateController.validateAmmount()).toBeFalsy();    
    });
    it('validateAmmount run numeric ammount', function () {
      var PayOperateController = this.createController();
      PayOperateController.data.ammount = 5;
      expect(PayOperateController.validateAmmount()).toBeTruthy();    
    });
    it('validateAmmount run numeric ammount', function () {
      var PayOperateController = this.createController();
      PayOperateController.data.popUp = {
        close: function(){return true;}
      };
      PayOperateController.validateAmmount();
    })
    it('doPartialPayment defined', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.doPartialPayment).toBeDefined();      
    });
    it('doPartialPayment run no ammount', function () {
      var PayOperateController = this.createController();
      expect(PayOperateController.doPartialPayment()).toBeFalsy();    
    });
    it('doPartialPayment run numeric ammount and opened popup', function () {
      var PayOperateController = this.createController();
      PayOperateController.data.ammount = 5;
      PayOperateController.data.popUp = {
        close: function(){return true;}
      };
      expect(PayOperateController.doPartialPayment()).toBeFalsy();    
    });
    it('doPartialPayment run', function () {
      var PayOperateController = this.createController();
      PayOperateController.data.ammount = 5;
      PayOperateController.doPartialPayment();
    });
  });
});