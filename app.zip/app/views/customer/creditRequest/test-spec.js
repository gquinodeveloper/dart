import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/customer/creditRequest/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {

    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      var controller = $controller('CreditRequestController', {'$scope': this.$scope, 'menuActive': {active: 1},
        swagger: {
          api: {
            corresponsales: {
              solicitudCredito: {
                post: {
                  call: (obj) => {
                    return $q.when();
                  }
                }
              }
            }
          }
        },
        fileService: {
          scanDirectory: (path, cb) => {
            return null;
          },
          readFile: (path, cb) => {
            return null;
          }
        }
      });
      controller.slider = {
        slideNext: () => {}
      };
      return controller;
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Customer_CreditRequest Controller', function () {
    it('initLoad defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.initLoad();
    });
    it('getSelectedCreditType defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.getSelectedCreditType).toBeDefined();
    });
    it('getSelectedCreditType run', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.getSelectedCreditType();
    });
    it('goToStep2 defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.goToStep2).toBeDefined();
    });
    it('goToStep2 run invalid', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.goToStep2()).toBeFalsy();
    });
    it('goToStep2 run valid', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.customer.firstName = "Pedro";
      CreditRequestController.data.customer.firstSurname = "Gomez";
      CreditRequestController.data.customer.documentType =       {
        label: "DNI",
        value: "21"
      };
      CreditRequestController.data.customer.creditType = "Test";
      CreditRequestController.data.customer.document = "543534534D";
      CreditRequestController.data.customer.requestedAmount = 1234.43;
      CreditRequestController.data.customer.feeValue = 1.00;
      expect(CreditRequestController.goToStep2()).toBeTruthy();
    });
    it('goToStep3 defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.goToStep3).toBeDefined();
    });
    it('goToStep3 run invalid', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.goToStep3()).toBeFalsy();
    });
    it('goToStep3 run valid', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.customer.bucketCash = 100.32;
      CreditRequestController.data.customer.doYouLoan = 1455.00;
      CreditRequestController.data.customer.commodityCash = 100.00;
      CreditRequestController.data.customer.companyValues = 133.00;
      CreditRequestController.data.customer.providerDebts = 100.00;
      CreditRequestController.data.customer.monthlySales = 423.94;
      CreditRequestController.data.customer.extraCash = "Ingresos adicionales";
      CreditRequestController.data.customer.monthlySpends = 5554.00;
      CreditRequestController.data.customer.monthlyPayments = 1234.01;
      expect(CreditRequestController.goToStep3()).toBeTruthy();
    });
    it('lastStep defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.lastStep).toBeDefined();
    });
    it('lastStep run invalid', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.creditTypes[0].selected = true;
      expect(CreditRequestController.lastStep()).toBeFalsy();
    });
    it('lastStep run email invalid', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.customer.address = "Calle del pino 123";
      CreditRequestController.data.customer.city = "Madrid";
      CreditRequestController.data.customer.phoneNumber = "12345678";
      CreditRequestController.data.customer.emailAddress = "sarasa";
      CreditRequestController.data.creditTypes[0].selected = true;
      expect(CreditRequestController.lastStep()).toBeFalsy();
    });
    it('lastStep run valid', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.customer.address = "Calle del pino 123";
      CreditRequestController.data.customer.city = "Madrid";
      CreditRequestController.data.customer.phoneNumber = "12345678";
      CreditRequestController.data.customer.emailAddress = "sarasa@sarasa.com";
      CreditRequestController.data.creditTypes[0].selected = true;
      expect(CreditRequestController.lastStep()).toBeTruthy();
    });
    it('sendForm defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.sendForm).toBeDefined();
    });
    it('sendForm run', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.data.creditTypes[0].selected = true;
      CreditRequestController.sendForm();
    });
    it('showFormInvalidPopup defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.showFormInvalidPopup).toBeDefined();
    });
    it('showFormInvalidPopup run', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.showFormInvalidPopup();
    });
    it('scanOcr defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.scanOcr).toBeDefined();
    });
    it('scanOcr run', function () {
      var CreditRequestController = this.createController();
      CreditRequestController.scanOcr();
    });
    it('getLastOcrPicture defined', function () {
      var CreditRequestController = this.createController();
      expect(CreditRequestController.getLastOcrPicture).toBeDefined();
    });
  });
});
