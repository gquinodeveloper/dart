CreditRequestController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$timeout', 'fileService', '$window'];

/**
 * @class corresponsales.customer_HomeCustomerController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil creditRequest
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @returns {undefined}
 */
function CreditRequestController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $timeout, fileService, $window) {
  let creditRequest = this;

  menuActive.active = 1;
  creditRequest.slider = null;
  creditRequest.data = {
    formData: {},
    slideOptions: {
      loop: false,
      effect: 'slide',
      speed: 500,
      paginationClickable: false
    },
    corresponsal: "",
    corresponsalId: "",
    doYouLoanOk: false,
    extraCashOk: false,
    customer: {
      firstName: "",
      secondName: "",
      firstSurname: "",
      secondSurname: "",
      documentType: {
        label: "DNI",
        value: "21"
      },
      document: "",
      companyType: "",
      companyAge: "",
      phone: "",
      activity: "",
      creditType: "",
      requestedAmount: "",
      feeValue: "",
      bucketCash: "",
      doYouLoan: "",
      commodityCash: "",
      companyValues: "",
      providerDebts: "",
      monthlySales: "",
      extraCash: "",
      monthlySpends: "",
      monthlyPayments: "",
      familyNumber: {
        label: "0",
        value: "0"
      },
      personsInCharge: {
        label: "0",
        value: "0"
      },
      address: "",
      city: "",
      country: {
        label: "Colombia",
        value: "Colombia"
      },
      phoneNumber: "",
      emailAddress: "",
      imageBase64: ""
    },
    creditTypes: [
      {
        value: "Compra de materias primas /surtido",
        selected: false
      },
      {
        value: "Compra de Maquinaria/ activo fijo",
        selected: false
      },
      {
        value: "Mejoras Locativas Vivienda- Negocio",
        selected: false
      },
      {
        value: "Compra de Materia prima y activo fijo",
        selected: false
      },
      {
        value: "Otro",
        selected: false,
        other: true
      }
    ],
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
    familyNumber: [
      {
        label: "0",
        value: "0"
      },
      {
        label: "1",
        value: "1"
      },
      {
        label: "2",
        value: "2"
      },
      {
        label: "3",
        value: "3"
      },
      {
        label: "4",
        value: "4"
      },
      {
        label: "5",
        value: "5"
      },
      {
        label: "6",
        value: "6"
      },
      {
        label: "7",
        value: "7"
      },
      {
        label: "8",
        value: "8"
      },
      {
        label: "9",
        value: "9"
      },
      {
        label: "10",
        value: "10"
      },
    ],
    personsInCharge: [
      {
        label: "0",
        value: "0"
      },
      {
        label: "1",
        value: "1"
      },
      {
        label: "2",
        value: "2"
      },
      {
        label: "3",
        value: "3"
      },
      {
        label: "4",
        value: "4"
      },
      {
        label: "5",
        value: "5"
      },
      {
        label: "6",
        value: "6"
      },
      {
        label: "7",
        value: "7"
      },
      {
        label: "8",
        value: "8"
      },
      {
        label: "9",
        value: "9"
      },
      {
        label: "10",
        value: "10"
      },
    ],
    countries: [
      {
        label: "Chile",
        value: "Chile"
      },
      {
        label: "Colombia",
        value: "Colombia"
      },
      {
        label: "República dominicana",
        value: "República dominicana"
      },
      {
        label: "Panamá",
        value: "Panamá"
      },
      {
        label: "Perú",
        value: "Perú"
      },
    ],
  };


  creditRequest.texts = {
    title: "Solicitud de crédito",
    legend: "Los campos marcados con el símbolo * son obligatorios",
    personalData: "Datos del interesado",
    tellUsInvest: "Cuéntanos cómo deseas invertir el dinero",
    whyNewCredit: "¿Para qué necesita el nuevo crédito?",
    howMuchMoney: "¿Cuánto necesita?",
    companyType: "¿Qué tipo de negocio tiene? *",
    companyAge: " ¿Cuánto tiempo lleva con el negocio? *",
    requestedAmount: "Monto",
    feeValue: "Valor de la cuota que puede cancelar",
    wantToKnowActivity: "Pregúntale sobre su actividad",
    bucketCash: "¿Cuánto dinero en efectivo tiene en el momento en caja?",
    doYouLoan: "¿Fía? En caso afirmativo. ¿Cuánto dinero le deben del negocio?",
    commodityCash: "¿Cuánto dinero tiene en mercancía/surtido/insumos?",
    companyValues: "¿En cuánto tiene valorado la maquinaria/muebles y enseres/terreno/local?",
    providerDebts: "¿Cuánto le debe a los proveedores?",
    monthlySales: "¿Cuánto vende mensualmente?",
    extraCash: "Si tiene ingresos adicionales, cuéntanos de dónde provienen y de qué cantidad se trata",
    monthlySpends: "¿Cuál es el valor de sus gastos mensuales del negocio?",
    monthlyPayments: "¿Cuánto paga mensualmente de cuotas a entidades financieras? Incluye lo que paga con nosotros",
    weWantKnowYou: "Queremos conocerte mejor",
    familyNumber: "¿Cuántas personas conforman su núcleo familiar?",
    personsInCharge: "¿Cuántas personas tiene a su cargo?",
    companyAddress: "Datos del negocio",
    address: "Dirección",
    city: "Ciudad",
    country: "Pais",
    phoneNumber: "Número de teléfono",
    emailAddress: "Correo electrónico",
    another: "Otro",
    otherData: "Otros datos",
    contactData: "Datos de contacto",
    firstName: "Primer nombre *",
    secondName: "Segundo nombre",
    firstSurname: "Primer apellido *",
    secondSurname: "Segundo apellido",
    documentType: "Tipo de documento",
    document: "Número de documento",
    phone: "Teléfono principal *",
    activity: "Actividad",
    interested: "Interesado en...",
    switchOn: "Si",
    switchOff: "No",
    credit: "Créditos",
    cards: "Tarjetas",
    insurance: "Seguros",
    observations: "Observaciones",
    refer: "Referente",
    register: "Dar de alta >",
    info: "Información",
    other: "Otro",
    ok: "Aceptar",
    next: "Siguiente >",
    prev: "< Anterior",
    send: "Enviar",
    success: "Se ha realizado la solicitud de crédito satisfactoriamente.",
    invalidEmail: "Ingrese una dirección de correo electrónico válida",
    scanDocument: "Escanear documento",
    valid001: "- El campo \"%FIELD%\" supera el largo permitido.",
    valid002: "- El campo \"%FIELD%\" es inválido.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde." 
  };

  creditRequest.creditTypeSelect = (key) => {
    if (creditRequest.data.creditTypes.length > 0) {
      for (var x in creditRequest.data.creditTypes) {
        if (key != x && creditRequest.data.creditTypes[x].selected) {
          creditRequest.data.creditTypes[x].selected = false;
        }
      }
      if (creditRequest.data.creditTypes[key].other) {
        creditRequest.data.customer.creditType = "";
      } else {
        creditRequest.data.customer.creditType = creditRequest.data.creditTypes[key].value;
      }
    }
  };

  creditRequest.getSelectedCreditType = () => {
    if (creditRequest.data.creditTypes.length > 0) {
      for (var x in creditRequest.data.creditTypes) {
        if (creditRequest.data.creditTypes[x].selected) {
          return creditRequest.data.creditTypes[x];
        }
      }
    }
  };

  creditRequest.initLoad = () => {
    $scope.$emit("titleChange", creditRequest.texts.title);
  };
  creditRequest.initLoad();

  creditRequest.goToStep2 = () => {
    let valid = false,
            requiredFields = [
              creditRequest.data.customer.firstName.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.firstSurname.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.documentType,
              creditRequest.data.customer.document.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.companyType.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.companyAge.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.requestedAmount,
              creditRequest.data.customer.feeValue,
              creditRequest.data.customer.creditType.trim().replace(/[\W_]+/g, "")
            ];

    valid = requiredFields.indexOf("") == -1;

    if (!valid) {
      this.showFormInvalidPopup();
      return false;
    }

    let message = [];

    if (creditRequest.data.customer.secondName.trim() != "") {
      if (creditRequest.data.customer.secondName.trim().replace(/[\W_]+/g, "") == "") {
        valid = false;
        message.push(creditRequest.texts.valid002.replace("%FIELD%", creditRequest.texts.secondName));
      }
    }

    if (creditRequest.data.customer.secondSurname.trim() != "") {
      if (creditRequest.data.customer.secondSurname.trim().replace(/[\W_]+/g, "") == "") {
        valid = false;
        message.push(creditRequest.texts.valid002.replace("%FIELD%", creditRequest.texts.secondSurname));
      }
    }

    if (creditRequest.data.customer.companyType.trim() != "") {
      if (creditRequest.data.customer.companyType.trim().replace(/[\W_]+/g, "") == "") {
        valid = false;
        message.push(creditRequest.texts.valid002.replace("%FIELD%", creditRequest.texts.companyType));
      }
    }

    if (creditRequest.data.customer.companyAge.trim() != "") {
      if (creditRequest.data.customer.companyAge.trim().replace(/[\W_]+/g, "") == "") {
        valid = false;
        message.push(creditRequest.texts.valid002.replace("%FIELD%", creditRequest.texts.companyAge));
      }
    }

    if ((creditRequest.data.customer.requestedAmount + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.requestedAmount));
    }

    if ((creditRequest.data.customer.feeValue + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.feeValue));
    }

    if (valid) {
      creditRequest.slider.slideNext();
      document.getElementsByClassName('overflow-scroll')[0].scrollTo(0, 0);
      return true;
    } else {
      this.showFormInvalidPopup(message.join("<br />"));
      return false;
    }

  };

  creditRequest.goToStep3 = () => {
    let valid = false,
            requiredFields = [
              creditRequest.data.customer.bucketCash,
              creditRequest.data.customer.commodityCash,
              creditRequest.data.customer.companyValues,
              creditRequest.data.customer.providerDebts,
              creditRequest.data.customer.monthlySales,
              creditRequest.data.customer.monthlySpends,
              creditRequest.data.customer.monthlyPayments
            ];
    valid = requiredFields.indexOf("") == -1;
    if (!!creditRequest.data.extraCashOk && !creditRequest.data.customer.extraCash) {
      valid = false;
    }
    if (!!creditRequest.data.doYouLoanOk && !creditRequest.data.customer.doYouLoan) {
      valid = false;
    }
    if (!valid) {
      this.showFormInvalidPopup();
      return false;
    }

    if (!creditRequest.data.extraCashOk) {
      creditRequest.data.customer.extraCash = "";
    }
    if (!creditRequest.data.doYouLoanOk) {
      creditRequest.data.customer.doYouLoan = "";
    }

    let message = [];

    if ((creditRequest.data.customer.bucketCash + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.bucketCash));
    }

    if ((creditRequest.data.customer.doYouLoan + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.doYouLoan));
    }

    if ((creditRequest.data.customer.commodityCash + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.commodityCash));
    }

    if ((creditRequest.data.customer.companyValues + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.companyValues));
    }

    if ((creditRequest.data.customer.providerDebts + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.providerDebts));
    }

    if ((creditRequest.data.customer.monthlySales + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.monthlySales));
    }

    if ((creditRequest.data.customer.monthlySpends + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.monthlySpends));
    }

    if ((creditRequest.data.customer.monthlyPayments + "").length > 10) {
      valid = false;
      message.push(creditRequest.texts.valid001.replace("%FIELD%", creditRequest.texts.monthlyPayments));
    }

    if (valid) {
      creditRequest.slider.slideNext();
      document.getElementsByClassName('overflow-scroll')[0].scrollTo(0, 0);
      return true;
    } else {
      this.showFormInvalidPopup(message.join("<br />"));
      return false;
    }
  };

  creditRequest.lastStep = () => {
    let valid = false,
            requiredFields = [
              creditRequest.data.customer.address.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.city.trim().replace(/[\W_]+/g, ""),
              creditRequest.data.customer.phoneNumber.trim().replace(/[\W_]+/g, "")/*,
               creditRequest.data.customer.emailAddress.trim().replace(/[\W_]+/g,"")*/
            ],
            re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    valid = requiredFields.indexOf("") == -1;

    if (valid) {
      creditRequest.sendForm();
      return true;
    } else {
      this.showFormInvalidPopup();
    }
    return false;
  };

  creditRequest.sendForm = () => {
    $ionicLoading.hide();
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });

    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid; // eslint-disable-line
      }
    } catch (e) {
      //intentional
    }

    var customer = creditRequest.data.customer,
            solicitudCreditoDTO = {
              "udid": udid + "", // + "" for cast to string
              "firstName": customer.firstName + "",
              "secondName": customer.secondName + "",
              "firstSurname": customer.firstSurname + "",
              "secondSurname": customer.secondSurname + "",
              "documentType": customer.documentType.value + "",
              "document": customer.document + "",
              "companyType": customer.companyType + "",
              "companyAge": customer.companyAge + "",
              "whyNewCredit": creditRequest.getSelectedCreditType().value + "",
              "requestedAmount": customer.requestedAmount + "",
              "feeValue": customer.feeValue + "",
              "bucketCash": customer.bucketCash + "",
              "doYouLoan": customer.doYouLoan + "",
              "commodityCash": customer.commodityCash + "",
              "companyValues": customer.companyValues + "",
              "providerDebts": customer.providerDebts + "",
              "monthlySales": customer.monthlySales + "",
              "extraCash": customer.extraCash + "",
              "monthlySpends": customer.monthlySpends + "",
              "monthlyPayments": customer.monthlyPayments + "",
              "familyNumber": customer.familyNumber.value + "",
              "personsInCharge": customer.personsInCharge.value + "",
              "address": customer.address + "",
              "city": customer.city + "",
              "country": customer.country.value + "",
              "phoneNumber": customer.phoneNumber + "",
              "emailAddress": customer.emailAddress + "",
              /*"imageBase64": customer.imageBase64*/
            };
    swagger.api.corresponsales.solicitudCredito.post.call({
      SolicitudCreditoDTO: solicitudCreditoDTO
    }).then((response) => {
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: creditRequest.texts.info,
        template: creditRequest.texts.success,
        okText: creditRequest.texts.ok,
      });
      creditRequest.data.popup = alertPopup;
      alertPopup.then(() => {
        $state.go("menu.homeCustomer");
      });
    }).catch((err) => {
      $ionicLoading.hide();
      if(!err.data || !err.data.message){
        err={
          data: {
            message:creditRequest.texts.err004
          }
        };
      }
      var alertPopup = $ionicPopup.alert({
        title: creditRequest.texts.info,
        template: err.data.message,
        okText: creditRequest.texts.ok,
      });
      creditRequest.data.popup = alertPopup;
      alertPopup.then(() => {
        creditRequest.data.popup = null;
      });
      $scope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'SolicitudCredito',
        data: [{
            name: "err",
            value: JSON.stringify(err)
          },
          {
            name: "solicitud",
            value: JSON.stringify({
              solicitudBody: solicitudCreditoDTO
            })
          }]
      });
    });
  };

  this.showFormInvalidPopup = (message) => {
    var alertPopup = $ionicPopup.alert({
      title: creditRequest.texts.info,
      template: message ? message : creditRequest.texts.legend,
      okText: creditRequest.texts.ok,
    });
    creditRequest.data.popup = alertPopup;
    alertPopup.then(() => {
      creditRequest.data.popup = null;
    });
  };

  creditRequest.scanOcr = () => {
    if (window.OcrSdkPlugin) {
      window.OcrSdkPlugin.scanOcr((msg) => {
        let jsonMsg = JSON.parse(msg),
                customer = creditRequest.data.customer;
        if (jsonMsg.Nombre) {
          customer.firstName = jsonMsg.Nombre;
        }
        if (jsonMsg.Apellidos) {
          customer.firstSurname = jsonMsg.Apellidos;
        }
        if (jsonMsg.DocID) {
          customer.document = jsonMsg.DocID;
        }
        //Get last image from the OCR
        creditRequest.getLastOcrPicture((base64) => {
          console.log(base64);
          creditRequest.data.customer.imageBase64 = base64.replace("data:image/jpeg;base64,", "");
        });
      });
    }
  };

  creditRequest.takePicture = () => {
    if (navigator.camera) {
      navigator.camera.getPicture(() => {
      }, () => {
      });
    }
  };

  creditRequest.getLastOcrPicture = (callback) => {
    fileService.scanDirectory(cordova.file.externalRootDirectory + '/Pictures',
            (entries) => {
      var filteredFiles = [],
              counter = 0;
      for (var x in entries) {
        var entry = entries[x];
        entry.file((file) => {
          var fileName = file.name.replace(".jpg", "");
          if (fileName.length == 13 && fileName == parseInt(file.name)) {
            filteredFiles.push(file);
          }
          if (entries.length == ++counter) {
            var lastFile = null;
            if (filteredFiles.length > 0) {
              if (filteredFiles.length == 1) {
                lastFile = filteredFiles[0];
              } else {
                var orderedFiles = filteredFiles.sort((a, b) => {
                  return a.lastModifiedDate > b.lastModifiedDate;
                }); //order by lastModifiedDate desc
                for (var i in orderedFiles) {
                  if (orderedFiles[i].size > 1000) {
                    lastFile = orderedFiles[i];
                  }
                }
              }
              if (lastFile !== null) {
                fileService.readFile(lastFile.localURL, (base64Result) => {
                  callback.call(this, base64Result);
                });
              }
            }
          }
        }, (error) => {
          console.log(error);
        });
      }
    },
            (error) => {
      console.log(error);
    }
    );
  };

  creditRequest.showScanOcr = !!window.OcrSdkPlugin;
  creditRequest.showTakePicture = !!navigator.camera;

  $scope.$on("$ionicSlides.sliderInitialized", function (event, data) {
    creditRequest.slider = data.slider;
    creditRequest.data.scrollBottom = (!!data.slider.slides.find('.content-revertion')[0])
            ? (data.slider.slides.find('.content-revertion')[0].scrollHeight > data.slider.slides.find('.content-revertion')[0].offsetHeight ? true : false)
            : 'false';
  });

}

export default CreditRequestController;
