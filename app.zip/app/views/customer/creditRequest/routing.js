routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.creditRequest', {
            url: '/creditRequest',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/creditRequest/template.html',
                controllerAs: 'creditRequest',
                controller: "CreditRequestController"
              }
            }
          });
}

export default routing;
