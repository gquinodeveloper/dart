routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.payWay', {
            url: '/payWay',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/payWay/template.html',
                controllerAs: 'payWay',
                controller: "PayWayController"
              }
            }
          });
}

export default routing;
