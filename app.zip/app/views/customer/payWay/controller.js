PayWayController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$rootScope', 'printerService'];

/**
 * @class corresponsales.customer_DepositWayController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @returns {undefined}
 */
function PayWayController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope, printerService) {
  let payWay = this;
  menuActive.active = 1;
  payWay.data = {
    homeData: {},
    document: {
      label: "DNI",
      value: "21"
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
    documentNumber: '',
    accountNumber: '',
    popUp: null
  };

  payWay.texts = {
    title: "Pago de cuota",
    info: "Información",
    ok: "Aceptar",
    numberPlaceholder: "Número de documento",
    accountPlaceholder: "Número de crédito",
    getAccounts: "Consultar créditos >",
    getAccount: "Consultar crédito >",
    usingDocument: "Acceder ingresando DOI:",
    usingAccount: "O introducir número de crédito:",
    switchOn: "Crédito",
    switchOff: "Documento",
    err001: "Complete el formulario para continuar.",
    err002: "Cliente sin operaciones que permitan realizar un pago.",
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  payWay.initLoad = () => {
    $scope.$emit("titleChange", payWay.texts.title);
  };
  payWay.initLoad();

  /**
   * @memberOf corresponsales.customer_PayWayController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion 
   * @description función que centraliza las navegaciones de la vista
   */
  payWay.doNavigate = (path) => {
    $state.go(path);
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name getAccounts
   * @description función que realiza la buscqueda en servidor de todas las cuentas de un usuario seleccionado mediante tipo de documento y número
   * @returns {undefined} la función emite el cambio de título
   */
  payWay.getAccounts = () => {
    if (!!payWay.data.popup) {
      payWay.data.popup.close();
      payWay.data.popup = null;
      return false;
    }
    if (!payWay.data.document.value || !payWay.data.documentNumber) {
      var alertPopup = $ionicPopup.alert({
        title: payWay.texts.info,
        template: payWay.texts.err001,
        okText: payWay.texts.ok,
      });
      payWay.data.popup = alertPopup;
      alertPopup.then(() => {
        payWay.data.popup = null;
      });
    } else {
      if ( ( payWay.data.document.value == '21' || payWay.data.document.value == '25' ) && (payWay.data.documentNumber.length < payWay.docTypeLimits(payWay.data.document.value))){
        var alertPopup = $ionicPopup.alert({
          title: payWay.texts.info,
          template: 'Es necesario introducir '+ payWay.docTypeLimits(payWay.data.document.value) +' dígitos',
          okText: payWay.texts.ok,
        });
        payWay.data.popup = alertPopup;
        alertPopup.then(() => {
          payWay.data.popup = null;
        });
        return false;
      }
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      
      var udid = "86361b9cf75b7182";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.obligaciones.get.call({
        tipoOp: '2',
        tipoDoc: payWay.data.document.value,
        numDoc: payWay.data.documentNumber+"",
        udid:udid
      }).then((data) => {
        $ionicLoading.hide();
        if (data.data.obligaciones.length == 0) {
          var alertPopup = $ionicPopup.alert({
            title: payWay.texts.info,
            template: payWay.texts.err002,
            okText: payWay.texts.ok,
          });
          payWay.data.popup = alertPopup;
          alertPopup.then(() => {
            payWay.data.popup = null;
            //printerService.printErrorTicket("Obligaciones", payWay.texts.err002);
          });
        } else {
          data.data.tipoDoc = payWay.data.document;
          data.data.numDoc = payWay.data.documentNumber+"";
          localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
          payWay.doNavigate('menu.payAccounts');
        }
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
            event: 'Error en respuesta de servicio',
            tag: 'Pagos - identificacion usuario documento',
            data: [{
              name: "msg",
              value: JSON.stringify(err)
            }]
        });
        var alertPopup = $ionicPopup.alert({
          title: payWay.texts.info,
          template: err.data.message,
          okText: payWay.texts.ok,
        });
        payWay.data.popup = alertPopup;
        alertPopup.then(() => {
          payWay.data.popup = null;
          // printerService.printErrorTicket("Deposito", err.data.message);
        });
      });
    }
  };
  
  payWay.getAccountsByAccount = () => {
    if (!!payWay.data.popup) {
      payWay.data.popup.close();
      payWay.data.popup = null;
      return false;
    }
    if (!payWay.data.accountNumber) {
      var alertPopup = $ionicPopup.alert({
        title: payWay.texts.info,
        template: payWay.texts.err001,
        okText: payWay.texts.ok,
      });
      payWay.data.popup = alertPopup;
      alertPopup.then(() => {
        payWay.data.popup = null;
      });
    } else {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      
      var udid = "86361b9cf75b7182";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
            
      swagger.api.corresponsales.obligaciones.get.call({
        tipoOp: '2',
        numPro: payWay.data.accountNumber,
        udid:udid
      }).then((data) => {
        $ionicLoading.hide();
        if (data.data.obligaciones.length == 0) {
          var alertPopup = $ionicPopup.alert({
            title: payWay.texts.info,
            template: payWay.texts.err002,
            okText: payWay.texts.ok,
          });
          payWay.data.popup = alertPopup;
          alertPopup.then(() => {
            payWay.data.popup = null;
            //printerService.printErrorTicket("Deposito", payWay.texts.err002);
          });
        } else {
          data.data.tipoDoc = payWay.data.document;
          data.data.numDoc = payWay.data.documentNumber;
          localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
          payWay.doNavigate('menu.payAccounts');
        }
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
            event: 'Error en respuesta de servicio',
            tag: 'Pagos - identificacion usuario cuenta',
            data: [{
              name: "msg",
              value: JSON.stringify(err)
            }]
        });
        var alertPopup = $ionicPopup.alert({
          title: payWay.texts.info,
          template: err.data.message,
          okText: payWay.texts.ok,
        });
        payWay.data.popup = alertPopup;
        alertPopup.then(() => {
          payWay.data.popup = null;
          // printerService.printErrorTicket("Deposito", err.data.message);
        });
      });
    }
  };

  payWay.docTypeLimits = (docType) => {
    switch (docType){
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  payWay.limitFieldsTo = (newVal,oldVal,limit) => {
    if(newVal.length > limit){
      payWay.data.documentNumber = oldVal;
    } else {
      payWay.data.documentNumber = newVal;
    }
  };

  $scope.$watch("payWay.data.documentNumber", function(newVal, oldVal) {
    payWay.limitFieldsTo(newVal,oldVal,payWay.docTypeLimits(payWay.data.document.value));
  });

  $scope.$watch("payWay.data.document.value", function(newVal, oldVal) {
    payWay.data.documentNumber = '';
  });
}

export default PayWayController;