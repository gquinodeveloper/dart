DepositOperateController.$inject = ['menuActive', 'swagger', '$state', '$ionicPopup', '$scope', '$filter', '$ionicLoading', 'reversionService', 'txFailureService', 'cyptojsService', '$http'];

/**
 * @class corresponsales.Customer_DepositOperateController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {Object} cyptojsService - Servicio propio con funciones de encriptación
 * @param {function} $http - Función que facilita la comunicación con los servidores HTTP a través del navegador
 * @returns {undefined}
 */
function DepositOperateController(menuActive, swagger, $state, $ionicPopup, $scope, $filter, $ionicLoading, reversionService, txFailureService, cyptojsService, $http) {
  let depositOperate = this;
  menuActive.active = 1;
  depositOperate.data = {
    transactionData: {},
    popUp: null,
    ammount: '',
    disableDepositButton: false,
    errLabel: false,
    depositante: {
      nombre: '',
      apellido: '',
      document: {
        label: "DNI",
        value: "21"
      },
      numerodocumento: '',
      celular: '',
      correo: ''
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
  };

  depositOperate.texts = {
    title: "Hacer un depósito",
    name: "Titular:",
    account: "Nº de cuenta:",
    ammount: "Cantidad a abonar:",
    cost: "Costo transacción:",
    doOperate: "Enviar comprobante >",
    info: "Información",
    ok: "Aceptar",
    cancel: "Cancelar >",
    continue: "Continuar >",
    roundAmmount: "La parte decimal debe ser múltiplo de 10",
    datosdepositante: "Introducir datos del depositante:",
    nombresPlaceholder: "Nombres y apellidos",
    numberPlaceholder: "Número de documento",
    celularPlaceholder: "Celular",
    correoPlaceholder: "Correo electrónico",
    otp: "Introduzca el OTP que ha recibido el depositante en su celular",
    err001: "Revise la cantidad introducida.",
    err002: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde.",
    err003: "Ingrese nombres y apellidos",
    err004: "Ingrese número de documento",
    err005: "Ingrese número de documento válido",
    err006: "Ingrese número de celular",
    err007: "Ingrese numéro de celular válido",
    err008: "Ingrese correo electrónico válido", 
    err009: "OTP incorrecta. La OTP debe ser numérica.",
    err010: "OTP incorrecta. La longitud del OTP es de 6 caracteres.",
    err011: "Ingrese nombres y apellidos válidos"
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  depositOperate.initLoad = () => {
    $scope.$emit("titleChange", depositOperate.texts.title);
    //printerService.tryPrinterConnect();
    depositOperate.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    if(!!depositOperate.data.transactionData.searchAccByAcc){
      depositOperate.data.transactionData.tipoDoc = depositOperate.data.transactionData.tipoDoc[0];
    }

    let firebaseConexion = require('../../../configuration/default-config.json').firebase.config;
    console.log('config firebase');

    var config = firebaseConexion;

    if (!firebase.apps.length) {
      // Initialize Firebase
      firebase.initializeApp(config);
    }
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  depositOperate.doNavigate = (path) => {
    $state.go(path);
  };

  depositOperate.ammountValidate = () => {
    if (depositOperate.data.ammount == undefined) {
      return false;
    }
    try {
      depositOperate.data.ammount * 1;
    } catch (e) {
      return false;
    }
    if (depositOperate.data.ammount <= 0) {
      return false;
    }
    return true;
  };

  depositOperate.alertError = (texterror) => {
    depositOperate.data.disableDepositButton = false;
      var alertPopup = $ionicPopup.alert({
        title: depositOperate.texts.info,
        template: texterror,
        okText: depositOperate.texts.ok,
      });
      depositOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        depositOperate.data.popup = null;
      });
  };

  depositOperate.docTypeLimits = (docType) => {
    switch (docType) {
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  depositOperate.limitFieldsTo = (newVal, oldVal, limit) => {
    if (newVal.length > limit) {
      depositOperate.data.depositante.numerodocumento = oldVal;
    } else {
      depositOperate.data.depositante.numerodocumento = newVal;
    }
  };
  depositOperate.doOperate = () => {
    let regxMail = /[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}@[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.[a-zA-Z0-9][a-zA-Z0-9\-]{0,25}/g;
    let regxNombre = /^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/g;
    depositOperate.data.disableDepositButton = true;
    if (!!depositOperate.data.popup) {
      depositOperate.data.popup.close();
      depositOperate.data.popup = null;
      depositOperate.data.disableDepositButton = false;
      return false;
    }
    if (!depositOperate.ammountValidate()) {
      depositOperate.alertError(depositOperate.texts.err001);
    } else if (depositOperate.data.depositante.nombre.trim() == "") {
      depositOperate.alertError(depositOperate.texts.err003);
    } else if (!regxNombre.test(depositOperate.data.depositante.nombre.trim())) {
      depositOperate.alertError(depositOperate.texts.err011);
    } else if (depositOperate.data.depositante.numerodocumento.trim() == "") {
      depositOperate.alertError(depositOperate.texts.err004);
    } else if ((depositOperate.data.depositante.document.value == '21' || depositOperate.data.depositante.document.value == '25' ||
      depositOperate.data.depositante.document.value == '5' || depositOperate.data.depositante.document.value == '2') &&
      (depositOperate.data.depositante.numerodocumento.length < depositOperate.docTypeLimits(depositOperate.data.depositante.document.value))) {
        depositOperate.alertError(depositOperate.texts.err005);
    } else if (depositOperate.data.depositante.celular.trim() == "") {
      depositOperate.alertError(depositOperate.texts.err006);
    } else if (isNaN(depositOperate.data.depositante.celular)) {
      depositOperate.alertError(depositOperate.texts.err007);
    } else if (depositOperate.data.depositante.celular.length != 9) {
      depositOperate.alertError(depositOperate.texts.err007);
    } else if (depositOperate.data.depositante.celular.substring(0, 1) != "9"){
      depositOperate.alertError(depositOperate.texts.err007);
    } else if (!depositOperate.data.depositante.correo.trim() == "" && !regxMail.test(depositOperate.data.depositante.correo)) {
      depositOperate.alertError(depositOperate.texts.err008);
    } else {
      var udid = "86361b9cf75b7182";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }

      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });

      let datosBody = {
        datosBody: {
          tipoDoc: depositOperate.data.depositante.document.value,
          numDoc: depositOperate.data.depositante.numerodocumento,
          telefono: depositOperate.data.depositante.celular,
          udid: udid,
        }
      };

      console.log('datosBody :', datosBody);

      swagger.api.corresponsales.datosClausula.post.call(datosBody).then((res) => {
        if(res.data.codMensaje == "0") {
          //Sin autorización de uso de datos
          swagger.api.corresponsales.otpAutorizacion.get.call({      
            tipoDoc: depositOperate.data.depositante.document.value,
            numDoc: depositOperate.data.depositante.numerodocumento,    
            numTelefono: depositOperate.data.depositante.celular,
            udid: udid,
          }).then((data) => {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.prompt({
              title: depositOperate.texts.otp,
              okText: depositOperate.texts.continue,
              cancelText: depositOperate.texts.cancel,
              inputType: 'text',
              inputPlaceholder: 'OTP'
            });
            depositOperate.data.popup = alertPopup;
            alertPopup.then((eOtp) => {
              depositOperate.data.popup = null;
              if (!!eOtp) {
                $ionicLoading.show({
                  template: '<ion-spinner icon="ripple"></ion-spinner>',
                  hideOnStateChange: true
                });
                if(depositOperate.validateOtp(eOtp)) {
                  let datosBodyReg = {
                    datosBody: {
                      tipoDoc: depositOperate.data.depositante.document.value,
                      numDoc: depositOperate.data.depositante.numerodocumento,
                      telefono: depositOperate.data.depositante.celular,
                      otpEncriptado: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(data.data.message)),
                      numTx: data.data.message,
                      udid: udid,
                    }
                  };
                  console.log('datosBodyReg :', datosBodyReg);
                  swagger.api.corresponsales.registroClausula.post.call(datosBodyReg).then((dataReg) => {
                    $ionicLoading.hide();
                    console.log('Rpta Reg Clausula', dataReg);
                    depositOperate.confirmDeposito(udid);
                  }).catch((err) => {
                    depositOperate.data.disableDepositButton = false;
                    $ionicLoading.hide();
                    $scope.$emit('metrics-custom', {
                      event: 'Error en respuesta de servicio',
                      tag: 'Autorización - identificacion usuario',
                      data: [{
                        name: "msg",
                        value: JSON.stringify(err)
                      }]
                    });
                    var alertPopup = $ionicPopup.alert({
                      title: depositOperate.texts.info,
                      template: err.data.message,
                      okText: depositOperate.texts.ok,
                    });
                    depositOperate.data.popup = alertPopup;
                    alertPopup.then(() => {
                      depositOperate.data.popup = null;
                    });
                  });
                }             
              } else {
                depositOperate.data.disableDepositButton = false;                
              }
            });
          }).catch((err) => {
            depositOperate.data.disableDepositButton = false;
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'Error generando OTP autorización de datos',
              tag: 'Autorización',
              data: [{
                name: "msg",
                value: JSON.stringify(err)
              }]
            });
            var alertPopup = $ionicPopup.alert({
              title: depositOperate.texts.info,
              template: (!!err.data.message ? err.data.message : "ERROR GENERANDO OTP" ),
              okText: depositOperate.texts.ok,
            });
            depositOperate.data.popup = alertPopup;
            alertPopup.then(() => {
              depositOperate.data.popup = null;
            });
          });
        } else {
          //Ya registrado
          depositOperate.confirmDeposito(udid);
        }

      }).catch((err) => {
        depositOperate.data.disableDepositButton = false;
        $ionicLoading.hide();
        console.log('Err :', err);
      });
    }
  };

  depositOperate.confirmDeposito = (udid) => {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      swagger.api.corresponsales.costo.get.call({
        monto: depositOperate.data.ammount,
        id: depositOperate.data.transactionData.selected.id,
        tipoOp: "1",
        udid: udid
      }).then((data) => {
        $ionicLoading.hide();
        localStorage.setItem("bm-tx-id", data.data.idTx);
        var template = '<b>Vas a depositar:</b>' +
          '<label class="primary-label">S/ ' + $filter('number')(depositOperate.data.ammount, 2) + '</label>' +
          '<b>en la siguiente cuenta:</b>' +
          '<span>Titular</span>' +
          '<label class="primary-label">' + depositOperate.data.transactionData.titular + '</label>' +
          '<span ng-if="'+ !depositOperate.data.transactionData.searchAccByAcc +'">' + depositOperate.data.transactionData.tipoDoc.label + '</span>' +
          '<label class="primary-label" ng-if="'+ !depositOperate.data.transactionData.searchAccByAcc +'">' + depositOperate.data.transactionData.numDoc + '</label>' +
          '<span>' + depositOperate.texts.account + '</span>' +
          '<label class="primary-label">' + depositOperate.data.transactionData.selected.num + '</label>' +
          '<span>' + depositOperate.texts.cost + '</span>' +
          '<label class="primary-label">S/ ' + (!!data.data.costo ? data.data.costo : '0.00') + '</label>' +
          '<b>¿Desea continuar con la operación?</b>';
        var alertPopup = $ionicPopup.confirm({
          cssClass: 'popup-big',
          template: template,
          okText: depositOperate.texts.continue,
          cancelText: depositOperate.texts.cancel,
        });
        depositOperate.data.popup = alertPopup;
        alertPopup.then(
          (e) => {
            depositOperate.data.disableDepositButton = false;
            depositOperate.data.popup = null;
            if (!!e) {
              $ionicLoading.show({
                template: '<ion-spinner icon="ripple"></ion-spinner>',
                hideOnStateChange: true
              });
              let reversionData = {
                udid: udid,
                tipoOp: "1",
                monto: depositOperate.data.ammount,
                cuenta: {
                  id: depositOperate.data.transactionData.selected.id
                },
                idTx: localStorage.getItem("bm-tx-id"),
                tipoDoc: depositOperate.data.transactionData.tipoDoc.value,
                numDoc: depositOperate.data.transactionData.numDoc + ""
              };
              reversionService.setReversionData(reversionData);
              let depositoBody = {
                depositoBody: {
                  cuenta: depositOperate.data.transactionData.selected,
                  monto: depositOperate.data.ammount,
                  udid: udid,
                  idTx: localStorage.getItem("bm-tx-id"),
                  tipoDoc: depositOperate.data.transactionData.tipoDoc.value,
                  numDoc: depositOperate.data.transactionData.numDoc + "",
                  nroDoc: depositOperate.data.depositante.numerodocumento + "",
                  correo: depositOperate.data.depositante.correo + ""
                }
              };
              swagger.api.corresponsales.deposito.post.call(depositoBody).then((tx) => {
                $ionicLoading.hide();
                let reversionData = reversionService.clearReversionData();
                reversionData.operacion = {
                  codOperacion: tx.data.codOperacion,
                  codAutorizacion: tx.data.codAutorizacion
                };
                txFailureService.txFailureLauncher(reversionData);
                depositOperate.saveFirebase(tx.data.filename, tx.data.pdf, tx.data.tran, tx.data.fecha, udid);
                $state.go('menu.operations', {normalizeConfiguration: true});
              }).catch((err) => {
                $ionicLoading.hide();
                $scope.$emit('metrics-custom', {
                  event: 'Error en respuesta de servicio',
                  tag: 'Error deposito',
                  data: [{
                    name: "err",
                    value: JSON.stringify(err)
                  },
                    {
                      name: "tx",
                      value: JSON.stringify({
                        depositoBody: {
                          tipoDoc: depositOperate.data.transactionData.tipoDoc.label,
                          numDoc: depositOperate.data.transactionData.numDoc + "",
                          cuenta: depositOperate.data.transactionData.selected,
                          monto: depositOperate.data.ammount,
                          udid: udid,
                          idTx: localStorage.getItem("bm-tx-id")
                        }
                      })
                    }]
                });
                txFailureService.txFailureLauncher(reversionData);
                let alertPopup = $ionicPopup.alert({
                  title: depositOperate.texts.info,
                  template: err.data.message,
                  okText: depositOperate.texts.ok,
                });
                depositOperate.data.popup = alertPopup;
                alertPopup.then(() => {
                  $state.go('menu.homeCustomer');
                  return false;
                });
              });
            }
          }
        );
      }).catch((err) => {
        depositOperate.data.disableDepositButton = false;
        $ionicLoading.hide();
        let value = !err.data ? depositOperate.texts.err002 : JSON.stringify(err);
        $scope.$emit('metrics-custom', {
          event: 'Error en respuesta de servicio',
          tag: 'Deposito - identificacion usuario',
          data: [{
            name: "msg",
            value: value
          }]
        });
        if (!err.data) {
          //printerService.printErrorTicket("Deposito", depositOperate.texts.err004);
          var alertPopup = $ionicPopup.alert({
            title: depositOperate.texts.info,
            template: depositOperate.texts.err002,
            okText: depositOperate.texts.ok,
          });
          alertPopup.then(() => {
            $state.go('menu.homeCustomer');
            return false;
          });
          return false;
        }
        //printerService.printErrorTicket("Deposito", err.data.message);
        var alertPopup = $ionicPopup.alert({
          title: depositOperate.texts.info,
          template: err.data.message,
          okText: depositOperate.texts.ok,
        });
        alertPopup.then(() => {
          $state.go('menu.homeCustomer');
          return false;
        });
      });
  };
  
  depositOperate.validateOtp = (eOtp) => {
    if ((eOtp + "").length != 6) {
      $ionicLoading.hide();
      depositOperate.data.disableDepositButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP longitud incorrecta',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP con una longitud incorrecta (!=6) en registro de claúsula."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: depositOperate.texts.info,
        template: depositOperate.texts.err010,
        okText: depositOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
      $ionicLoading.hide();
      depositOperate.data.disableDepositButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP is NaN',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP isNaN en registro de claúsula."
        }]
      });
      let alertPopup = $ionicPopup.alert({
        title: depositOperate.texts.info,
        template: depositOperate.texts.err009,
        okText: depositOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else {
      return true;
    }
  };

  depositOperate.saveFirebase = (filename, pdf, tran, fecha, udid) => {
    //Guardar voucher
    console.log('firebase save');

    var storage = firebase.storage();        
    var storageRef = storage.ref();
    var metadata = {
      contentType: 'application/pdf',
    };
    var storageRefVouchers = storageRef.child('vouchers').child(filename);

    var file = pdf;
    var uploadTask = storageRefVouchers.putString(file, 'base64', metadata);

    uploadTask.on('state_changed', function (snapshot) {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      console.log('Upload is ' + progress + '% done');
      switch (snapshot.state) {
        case firebase.storage.TaskState.PAUSED:
          console.log('Upload is paused');
          break;
        case firebase.storage.TaskState.RUNNING:
          console.log('Upload is running');
          break;
      }
    }, function (error) {
      var errorMessage = error.message;
      console.log(errorMessage);
    }, function () {
      uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
        console.log('File available at', downloadURL);

        let firebaseDL = require('../../../configuration/default-config.json').firebase.shortLink;
        let body = {
          "dynamicLinkInfo" : {
            "domainUriPrefix" : firebaseDL.linkFb,
            "link" : downloadURL
          }
        };
        
          $http({
            method: firebaseDL.method,
            url: firebaseDL.url,
            data: body                 
          }).then(firebaseResp => {
            console.log('success =>', firebaseResp);                        

            let datosBody = {
              datosBody : {
                fecha : fecha,
                telefono : depositOperate.data.depositante.celular,
                numTx : tran,
                link : firebaseResp.data.shortLink + "",
                udid : udid
              }
            };

            console.log('datos sms =>', datosBody);

            swagger.api.corresponsales.envioVoucher.post.call(datosBody).then((respSms) => {
              console.log('Rstp Envio Voucher', respSms);
            }).catch((err) => {
              console.log('Error Envio Voucher', err);
            });

          }).catch((err) => {
            console.log('err =>', err);
          });
        });
    });
  };

  $scope.$watch("depositOperate.data.depositante.numerodocumento", function (newVal, oldVal) {
    depositOperate.limitFieldsTo(newVal, oldVal, depositOperate.docTypeLimits(depositOperate.data.depositante.document.value));
  });

  $scope.$watch('depositOperate.data.ammount', function(num){
    if(!!num) {
      let number = num.toFixed(2) + "";
      let parts = number.split(".");
      if (parts.length > 1) {
        (parts[1] % 10 == 0) ? depositOperate.data.errLabel = false : depositOperate.data.errLabel = true;
      }
    }
  });

  depositOperate.initLoad();
}

export default DepositOperateController;