routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.depositOperate', {
            url: '/depositOperate',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/depositOperate/template.html',
                controllerAs: 'depositOperate',
                controller: "DepositOperateController"
              }
            }
          });
}

export default routing;
