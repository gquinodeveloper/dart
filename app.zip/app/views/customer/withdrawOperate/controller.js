WithdrawOperateController.$inject = ['menuActive', 'swagger', '$state', '$ionicPopup', '$scope', '$filter', '$ionicLoading', 'reversionService', 'dukptService', 'txFailureService', 'cyptojsService', '$http'];

/**
 * @class corresponsales.Customer_WithdrawOperateController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {function} $http - Función que facilita la comunicación con los servidores HTTP a través del navegador
 * @returns {undefined}
 */
function WithdrawOperateController(menuActive, swagger, $state, $ionicPopup, $scope, $filter, $ionicLoading, reversionService, dukptService, txFailureService, cyptojsService, $http) {
  let withdrawOperate = this;
  menuActive.active = 1;
  withdrawOperate.data = {
    transactionData: {},
    popUp: null,
    ammount: '',
    otp: "",
    disableWithdrawButton: false,
    errLabel: false,
    depositante: {
      nombre: '',
      apellido: '',
      document: {
        label: "DNI",
        value: "21"
      },
      numerodocumento: '',
      celular: '',
      correo: ''
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
  };

  withdrawOperate.texts = {
    title: "Retirar dinero",
    name: "Titular:",
    account: "Nº de cuenta:",
    ammount: "Cantidad a retirar:",
    cost: "Costo transacción:",
    doOperate: "Enviar comprobante >",
    info: "Información",
    ok: "Aceptar",
    cancel: "Cancelar >",
    continue: "Continuar >",
    otp: "Introduzca el OTP que ha recibido el cliente en su celular",
    roundAmmount: "La parte decimal debe ser múltiplo de 10",
    datosdepositante: "Introducir datos del titular de la cuenta:",
    nombresPlaceholder: "Nombres y apellidos",
    numberPlaceholder: "Número de documento",
    celularPlaceholder: "Celular",
    correoPlaceholder: "Correo electrónico",
    err001: "Revise la cantidad introducida.",
    err002: "OTP incorrecta. La OTP debe ser numérica.",
    err003: "OTP incorrecta. La longitud del OTP es de 6 caracteres.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde.",
    err005: "Ingrese nombres y apellidos",
    err006: "Ingrese número de documento",
    err007: "Ingrese número de documento válido",
    err008: "Ingrese número de celular",
    err009: "Ingrese numéro de celular válido",
    err010: "Ingrese correo electrónico válido",
    err011: "Ingrese nombres y apellidos válidos"
  };

  /**
   * @memberOf corresponsales.customer_WithdrawOperateController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  withdrawOperate.initLoad = () => {
    $scope.$emit("titleChange", withdrawOperate.texts.title);    
    dukptService.setSeed("");
    withdrawOperate.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    if(!!withdrawOperate.data.transactionData.searchAccByAcc){
      withdrawOperate.data.transactionData.tipoDoc = withdrawOperate.data.transactionData.tipoDoc[0];
    }

    let firebaseConexion = require('../../../configuration/default-config.json').firebase.config;
    console.log('config firebase');

    var config = firebaseConexion;

    if (!firebase.apps.length) {
      // Initialize Firebase
      firebase.initializeApp(config);
    }
  };

  /**
   * @memberOf corresponsales.customer_WithdrawOperateController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  withdrawOperate.doNavigate = (path) => {
    $state.go(path);
  };

  withdrawOperate.ammountValidate = () => {
    if (withdrawOperate.data.ammount == undefined) {
      return false;
    }
    try {
      withdrawOperate.data.ammount * 1;
    } catch (e) {
      return false;
    }
    if (withdrawOperate.data.ammount <= 0) {
      return false;
    }
    return true;
  };

  withdrawOperate.doTx = (data) => {
    var template = '<b>Vas a retirar:</b>' +
      '<label class="primary-label">S/ ' + $filter('number')(withdrawOperate.data.ammount, 2) + '</label>' +
      '<b>de la siguiente cuenta:</b>' +
      '<span>Titular</span>' +
      '<label class="primary-label">' + withdrawOperate.data.transactionData.titular + '</label>' +
      '<span ng-if="'+ !withdrawOperate.data.transactionData.searchAccByAcc +'">' + withdrawOperate.data.transactionData.tipoDoc.label + '</span>' +
      '<label class="primary-label" ng-if="'+ !withdrawOperate.data.transactionData.searchAccByAcc +'">' + withdrawOperate.data.transactionData.numDoc + '</label>' +
      '<span>' + withdrawOperate.texts.account + '</span>' +
      '<label class="primary-label">' + withdrawOperate.data.transactionData.selected.num + '</label>' +
      '<span>' + withdrawOperate.texts.cost + '</span>' +
      '<label class="primary-label">S/ ' + (!!data.data.costo ? data.data.costo : '0.00') + '</label>' +
      '<b>¿Desea continuar con la operación?</b>';
    if ((JSON.parse(localStorage.getItem("bm-configuracion")).homeCorresponsal.cupoUtilizado * 1) - withdrawOperate.data.ammount < 0) {
      template += '<label class="primary-label">Valide si cuenta con los recursos para realizar la transacción usando sus fondos propios.</label>';
    }
    var alertPopup = $ionicPopup.confirm({
      cssClass: 'popup-big',
      template: template,
      okText: withdrawOperate.texts.continue,
      cancelText: withdrawOperate.texts.cancel,
    });
    withdrawOperate.data.popup = alertPopup;
    alertPopup.then((e) => {
      withdrawOperate.data.disableWithdrawButton = false;
      withdrawOperate.data.popup = null;
      if (!!e) {
        $ionicLoading.show({
          template: '<ion-spinner icon="ripple"></ion-spinner>',
          hideOnStateChange: true
        });
        var udid = "86361b9cf75b7182";
        try {
          if (device != undefined) {// eslint-disable-line
            udid = device.uuid;// eslint-disable-line
          }
        } catch (e) {
          //intentional
        }
        swagger.api.corresponsales.otpRetiro.get.call({
          tipoDoc: withdrawOperate.data.transactionData.tipoDoc.value + "",
          numDoc: withdrawOperate.data.transactionData.numDoc + "",
          monto: withdrawOperate.data.ammount,
          udid: udid,
        }).then((data) => {
          $ionicLoading.hide();
          var alertPopup = $ionicPopup.prompt({
            title: withdrawOperate.texts.otp,
            okText: withdrawOperate.texts.continue,
            cancelText: withdrawOperate.texts.cancel,
            inputType: 'text',
            inputPlaceholder: 'OTP'
          });
          withdrawOperate.data.popup = alertPopup;
          alertPopup.then((eOtp) => {
            withdrawOperate.data.popup = null;
            if (!!eOtp) {
              $ionicLoading.show({
                template: '<ion-spinner icon="ripple"></ion-spinner>',
                hideOnStateChange: true
              });
              if ((eOtp + "").length != 6) {
                $ionicLoading.hide();
                $scope.$emit('metrics-custom', {
                  event: 'evento: Error OTP longitud incorrecta',
                  tag: 'Error OTP',
                  data: [{
                    name: "err",
                    value: "Se ha introducido una OTP con una longitud incorrecta (!=6)."
                  }]
                });
                var alertPopup = $ionicPopup.alert({
                  title: withdrawOperate.texts.info,
                  template: withdrawOperate.texts.err003,
                  okText: withdrawOperate.texts.ok,
                });
                alertPopup.then(() => {
                  return false;
                });
                return false;
              }
              if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
                $ionicLoading.hide();
                $scope.$emit('metrics-custom', {
                  event: 'evento: Error OTP is NaN',
                  tag: 'Error OTP',
                  data: [{
                    name: "err",
                    value: "Se ha introducido una OTP isNaN."
                  }]
                });
                var alertPopup = $ionicPopup.alert({
                  title: withdrawOperate.texts.info,
                  template: withdrawOperate.texts.err002,
                  okText: withdrawOperate.texts.ok,
                });
                alertPopup.then(() => {
                  return false;
                });
                return false;
              }
              let reversionData = {
                udid: udid,
                tipoOp: "4",
                monto: withdrawOperate.data.ammount,
                cuenta: {
                  id: withdrawOperate.data.transactionData.selected.id
                },
                idTx: localStorage.getItem("bm-tx-id"),
                tipoDoc: withdrawOperate.data.transactionData.tipoDoc.value,
                numDoc: withdrawOperate.data.transactionData.numDoc + ""
              };
              reversionService.setReversionData(reversionData);
              let semilla = Math.random().toString(36).slice(-5);
              let retiroBody = {
                retiroBody: {
                  cuenta: withdrawOperate.data.transactionData.selected,
                  monto: withdrawOperate.data.ammount,
                  udid: udid,
                  otp: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(localStorage.getItem("bm-tx-id"))),
                  idTx: localStorage.getItem("bm-tx-id"),
                  semilla: semilla,
                  tipoDoc: withdrawOperate.data.transactionData.tipoDoc.value,
                  numDoc: withdrawOperate.data.transactionData.numDoc + "",
                  nroDoc: withdrawOperate.data.depositante.numerodocumento + "",
                  correo: withdrawOperate.data.depositante.correo + ""
                }
              };
              swagger.api.corresponsales.retiro.post.call(retiroBody).then((tx) => {
                $ionicLoading.hide();
                let reversionData = reversionService.clearReversionData();
                reversionData.operacion = {
                  codOperacion: tx.data.codOperacion,
                  codAutorizacion: tx.data.codAutorizacion
                };
                txFailureService.txFailureLauncher(reversionData);
                withdrawOperate.saveFirebase(tx.data.filename, tx.data.pdf, tx.data.tran, tx.data.fecha, udid);
                $state.go('menu.operations', {normalizeConfiguration: true});
              }).catch((err) => {
                $ionicLoading.hide();
                $scope.$emit('metrics-custom', {
                  event: 'evento: Error en retiro',
                  tag: 'Error transacción',
                  data: [{
                    name: "err",
                    value: JSON.stringify(err)
                  },
                    {
                      name: "tx",
                      value: JSON.stringify({
                        retiroBody: {
                          tipoDoc: withdrawOperate.data.transactionData.tipoDoc.label,
                          numDoc: withdrawOperate.data.transactionData.numDoc + "",
                          cuenta: withdrawOperate.data.transactionData.selected,
                          monto: withdrawOperate.data.ammount,
                          udid: udid,
                          otp: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(localStorage.getItem("bm-tx-id"))),
                          idTx: localStorage.getItem("bm-tx-id"),
                          semilla: semilla
                        }
                      })
                    }]
                });
                if (err.data.code == 412){
                  var alertPopup = $ionicPopup.alert({
                    title: withdrawOperate.texts.info,
                    template: err.data.message,
                    okText: withdrawOperate.texts.ok,
                  });
                  withdrawOperate.data.popup = alertPopup;
                  alertPopup.then(() => {
                    withdrawOperate.data.popup = null;
                  });
                } else {
                  txFailureService.txFailureLauncher(reversionData);
                  let alertPopup = $ionicPopup.alert({
                    title: withdrawOperate.texts.info,
                    template: err.data.message,
                    okText: withdrawOperate.texts.ok,
                  });
                  withdrawOperate.data.popup = alertPopup;
                  alertPopup.then(() => {
                    $state.go('menu.homeCustomer');
                    return false;
                  });
                }
              });
            }
          });
        }).catch((err) => {
          $ionicLoading.hide();
          $scope.$emit('metrics-custom', {
            event: 'Error generando OTP en el retiro',
            tag: 'Error transacción',
            data: [{
              name: "err",
              value: JSON.stringify(err)
            }]
          });
          var alertPopup = $ionicPopup.alert({
            title: withdrawOperate.texts.info,
            template: err.data.message,
            okText: withdrawOperate.texts.ok,
          });
          withdrawOperate.data.popup = alertPopup;
          alertPopup.then(() => {
            withdrawOperate.data.popup = null;
          });
        });
      }
    });
  };

  withdrawOperate.doOperate = () => {
    let regxMail = /[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}@[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.[a-zA-Z0-9][a-zA-Z0-9\-]{0,25}/g;
    let regxNombre = /^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/g;
    withdrawOperate.data.disableWithdrawButton = true;
    if (!!withdrawOperate.data.popup) {
      withdrawOperate.data.popup.close();
      withdrawOperate.data.popup = null;
      withdrawOperate.data.disableWithdrawButton = false;
      return false;
    }
    if (!withdrawOperate.ammountValidate()) {
      withdrawOperate.alertError(withdrawOperate.texts.err001);
    } else if (withdrawOperate.data.depositante.nombre.trim() == "") {
      withdrawOperate.alertError(withdrawOperate.texts.err005);
    } else if (!regxNombre.test(withdrawOperate.data.depositante.nombre.trim())) {
      withdrawOperate.alertError(withdrawOperate.texts.err011);
    } else if (withdrawOperate.data.depositante.numerodocumento.trim() == "") {
      withdrawOperate.alertError(withdrawOperate.texts.err006);
    } else if ((withdrawOperate.data.depositante.document.value == '21' || withdrawOperate.data.depositante.document.value == '25' ||
    withdrawOperate.data.depositante.document.value == '5' || withdrawOperate.data.depositante.document.value == '2') &&
      (withdrawOperate.data.depositante.numerodocumento.length < withdrawOperate.docTypeLimits(withdrawOperate.data.depositante.document.value))) {
        withdrawOperate.alertError(withdrawOperate.texts.err007);
    } else if (withdrawOperate.data.depositante.celular.trim() == "") {
      withdrawOperate.alertError(withdrawOperate.texts.err008);
    } else if (isNaN(withdrawOperate.data.depositante.celular)) {
      withdrawOperate.alertError(withdrawOperate.texts.err009);
    } else if (withdrawOperate.data.depositante.celular.length != 9) {
      withdrawOperate.alertError(withdrawOperate.texts.err009);
    } else if (withdrawOperate.data.depositante.celular.substring(0, 1) != "9"){
      withdrawOperate.alertError(withdrawOperate.texts.err009);
    } else if (!withdrawOperate.data.depositante.correo.trim() == "" && !regxMail.test(withdrawOperate.data.depositante.correo)) {
      withdrawOperate.alertError(withdrawOperate.texts.err010);
    } else {
      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }

      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });

      let datosBody = {
        datosBody: {
          tipoDoc: withdrawOperate.data.depositante.document.value,
          numDoc: withdrawOperate.data.depositante.numerodocumento,
          telefono: withdrawOperate.data.depositante.celular,
          udid: udid,
        }
      };
      swagger.api.corresponsales.datosClausula.post.call(datosBody).then((res) => {
        if(res.data.codMensaje == "0") {
          //Sin autorización de uso de datos
          swagger.api.corresponsales.otpAutorizacion.get.call({      
            tipoDoc: withdrawOperate.data.depositante.document.value,
            numDoc: withdrawOperate.data.depositante.numerodocumento,    
            numTelefono: withdrawOperate.data.depositante.celular,
            udid: udid,
          }).then((data) => {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.prompt({
              title: withdrawOperate.texts.otp,
              okText: withdrawOperate.texts.continue,
              cancelText: withdrawOperate.texts.cancel,
              inputType: 'text',
              inputPlaceholder: 'OTP'
            });
            withdrawOperate.data.popup = alertPopup;
            alertPopup.then((eOtp) => {
              withdrawOperate.data.popup = null;
              if (!!eOtp) {
                $ionicLoading.show({
                  template: '<ion-spinner icon="ripple"></ion-spinner>',
                  hideOnStateChange: true
                });
                if(withdrawOperate.validateOtp(eOtp)) {
                  let datosBodyReg = {
                    datosBody: {
                      tipoDoc: withdrawOperate.data.depositante.document.value,
                      numDoc: withdrawOperate.data.depositante.numerodocumento,
                      telefono: withdrawOperate.data.depositante.celular,
                      otpEncriptado: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(data.data.message)),
                      numTx: data.data.message,
                      udid: udid,
                    }
                  };
                  console.log('datosBodyReg :', datosBodyReg);
                  swagger.api.corresponsales.registroClausula.post.call(datosBodyReg).then((dataReg) => {
                    $ionicLoading.hide();
                    console.log('Rpta Reg Clausula', dataReg);
                    withdrawOperate.confirmRetiro(udid);
                  }).catch((err) => {
                    withdrawOperate.data.disableWithdrawButton = false;
                    $ionicLoading.hide();
                    $scope.$emit('metrics-custom', {
                      event: 'Error en respuesta de servicio',
                      tag: 'Autorización - identificacion usuario',
                      data: [{
                        name: "msg",
                        value: JSON.stringify(err)
                      }]
                    });
                    var alertPopup = $ionicPopup.alert({
                      title: withdrawOperate.texts.info,
                      template: err.data.message,
                      okText: withdrawOperate.texts.ok,
                    });
                    withdrawOperate.data.popup = alertPopup;
                    alertPopup.then(() => {
                      withdrawOperate.data.popup = null;
                    });
                  });
                }             
              } else {
                withdrawOperate.data.disableWithdrawButton = false;
              }
            });
          }).catch((err) => {
            withdrawOperate.data.disableWithdrawButton = false;
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'Error generando OTP autorización de datos',
              tag: 'Autorización',
              data: [{
                name: "msg",
                value: JSON.stringify(err)
              }]
            });
            var alertPopup = $ionicPopup.alert({
              title: withdrawOperate.texts.info,
              template: (!!err.data.message ? err.data.message : "ERROR GENERANDO OTP" ),
              okText: withdrawOperate.texts.ok,
            });
            withdrawOperate.data.popup = alertPopup;
            alertPopup.then(() => {
              withdrawOperate.data.popup = null;
            });
          });
        } else {
          //Ya registrado
          withdrawOperate.confirmRetiro(udid);
        }

      }).catch((err) => {
        withdrawOperate.data.disableWithdrawButton = false;
        $ionicLoading.hide();
        console.log('Err :', err);
      });
    }
  };

  withdrawOperate.initLoad();

  withdrawOperate.confirmRetiro = (udid) => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    swagger.api.corresponsales.costo.get.call({
      monto: withdrawOperate.data.ammount,
      id: withdrawOperate.data.transactionData.selected.id,
      tipoOp: "4",
      udid: udid
    }).then((data) => {
      $ionicLoading.hide();
      localStorage.setItem("bm-tx-id", data.data.idTx);
      dukptService.setSeed(data.data.semilla);
      withdrawOperate.doTx(data);
    }).catch((err) => {
      $ionicLoading.hide();
      withdrawOperate.data.disableWithdrawButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error en retiro',
        tag: 'Error transacción',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
          {
            name: "tx",
            value: JSON.stringify({
              costoParams: {
                monto: withdrawOperate.data.ammount,
                id: withdrawOperate.data.transactionData.selected.id,
                tipoOp: "4",
                udid: udid
              }
            })
          }]
      });
      if (!err.data) {        
        let alertPopup = $ionicPopup.alert({
          title: withdrawOperate.texts.info,
          template: withdrawOperate.texts.err004,
          okText: withdrawOperate.texts.ok,
        });
        alertPopup.then(() => {
          $state.go('menu.homeCustomer');
          return false;
        });
        return false;
      }      
      let alertPopup = $ionicPopup.alert({
        title: withdrawOperate.texts.info,
        template: err.data.message,
        okText: withdrawOperate.texts.ok,
      });
      alertPopup.then(() => {
        $state.go('menu.homeCustomer');
        return false;
      });

    });
  };
  withdrawOperate.docTypeSwitchTransform = (docType) => {
    switch (docType) {
      case '1':
        return '1';
        break;
      case '2':
        return '4';
        break;
      case '3':
        return '2';
        break;
      case '4':
        return '6';
        break;
      case '5':
        return '5';
        break;
      case '7':
        return '2';
        break;
      case '9':
        return '3';
        break;
      case '6':
        return '10';
        break;
      case '12':
        return '9';
        break;
    }
  };

  withdrawOperate.alertError = (texterror) => {
    withdrawOperate.data.disableWithdrawButton = false;
      var alertPopup = $ionicPopup.alert({
        title: withdrawOperate.texts.info,
        template: texterror,
        okText: withdrawOperate.texts.ok,
      });
      withdrawOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        withdrawOperate.data.popup = null;
      });
  };

  withdrawOperate.docTypeLimits = (docType) => {
    switch (docType) {
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  withdrawOperate.validateOtp = (eOtp) => {
    if ((eOtp + "").length != 6) {
      $ionicLoading.hide();
      withdrawOperate.data.disableWithdrawButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP longitud incorrecta',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP con una longitud incorrecta (!=6) en registro de claúsula."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: withdrawOperate.texts.info,
        template: withdrawOperate.texts.err003,
        okText: withdrawOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
      $ionicLoading.hide();
      withdrawOperate.data.disableWithdrawButton = false;
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP is NaN',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP isNaN en registro de claúsula."
        }]
      });
      let alertPopup = $ionicPopup.alert({
        title: withdrawOperate.texts.info,
        template: withdrawOperate.texts.err002,
        okText: withdrawOperate.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else {
      return true;
    }
  };

  withdrawOperate.limitFieldsTo = (newVal, oldVal, limit) => {
    if (newVal.length > limit) {
      withdrawOperate.data.depositante.numerodocumento = oldVal;
    } else {
      withdrawOperate.data.depositante.numerodocumento = newVal;
    }
  };

  withdrawOperate.saveFirebase = (filename, pdf, tran, fecha, udid) => {
    //Guardar voucher
    console.log('firebase save');

    var storage = firebase.storage();        
    var storageRef = storage.ref();
    var metadata = {
      contentType: 'application/pdf',
    };
    var storageRefVouchers = storageRef.child('vouchers').child(filename);

    var file = pdf;
    var uploadTask = storageRefVouchers.putString(file, 'base64', metadata);

    uploadTask.on('state_changed', function (snapshot) {
      var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      console.log('Upload is ' + progress + '% done');
      switch (snapshot.state) {
        case firebase.storage.TaskState.PAUSED:
          console.log('Upload is paused');
          break;
        case firebase.storage.TaskState.RUNNING:
          console.log('Upload is running');
          break;
      }
    }, function (error) {
      var errorMessage = error.message;
      console.log(errorMessage);
    }, function () {
      uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
        console.log('File available at', downloadURL);

        let firebaseDL = require('../../../configuration/default-config.json').firebase.shortLink;
        let body = {
          "dynamicLinkInfo" : {
            "domainUriPrefix" : firebaseDL.linkFb,
            "link" : downloadURL
          }
        };
        
          $http({
            method: firebaseDL.method,
            url: firebaseDL.url,
            data: body                 
          }).then(firebaseResp => {
            console.log('success =>', firebaseResp);                        

            let datosBody = {
              datosBody : {
                fecha : fecha,
                telefono : withdrawOperate.data.depositante.celular,
                numTx : tran,
                link : firebaseResp.data.shortLink + "",
                udid : udid
              }
            };

            console.log('datos sms =>', datosBody);

            swagger.api.corresponsales.envioVoucher.post.call(datosBody).then((respSms) => {
              console.log('Rstp Envio Voucher', respSms);
            }).catch((err) => {
              console.log('Error Envio Voucher', err);
            });

          }).catch((err) => {
            console.log('err =>', err);
          });
        });
    });
  };

  withdrawOperate.generatePinBlock = (pin, pan, docType) => {
    var block1 = '0' + (pin + '').length + pin;
    var block2 = pan + "";
    while (block1.length < 16) {
      block1 = block1 + 'F';
    }
    while (block2.length < 10) {
      block2 = '0' + block2;
    }
    block2 = withdrawOperate.docTypeSwitchTransform(docType + "") + "" + block2;
    while (block2.length < 16) {
      block2 = '0' + block2;
    }

    console.log(block1, block2);
    function hexstringToData(hexString) {
      var hex = hexString;
      hex = (hex).replace(/\s/g, '');
      var keyar = hex.match(/../g);
      var s = '';
      for (var i = 0; i < keyar.length; i++) {
        s += String.fromCharCode(Number('0x' + keyar[i]));
      }
      return s;
    }

    function dataToHexstring(data) {
      var hex = '';
      for (var i = 0; i < data.length; i++) {
        var h = data.charCodeAt(i).toString(16);
        if (h.length < 2)
          h = '0' + h;
        hex += h;
      }
      return hex.toUpperCase();
    }
    var data1 = hexstringToData(block1);
    var data2 = hexstringToData(block2);
    var output = '';
    if (data1.length < data2.length) {
      while (data1.length < data2.length) {
        data1 = '\0' + data1;
      }
    }
    if (data1.length > data2.length) {
      while (data1.length > data2.length) {
        data2 = '\0' + data2;
      }
    }
    for (var i = 0; i < data1.length; i++) {
      var result = data1.charCodeAt(i) ^ data2.charCodeAt(i);
      output += String.fromCharCode(result);
    }
    return dataToHexstring(output);
  };

  $scope.$watch('withdrawOperate.data.ammount', function(num){
    if(!!num){
      let number = num.toFixed(2) + "";
      let parts = number.split(".");
      if(parts.length > 1){
        (parts[1] % 10 == 0) ? withdrawOperate.data.errLabel = false : withdrawOperate.data.errLabel = true;
      }
    }
  });

  $scope.$watch("withdrawOperate.data.depositante.numerodocumento", function (newVal, oldVal) {
    withdrawOperate.limitFieldsTo(newVal, oldVal, withdrawOperate.docTypeLimits(withdrawOperate.data.depositante.document.value));
  });
}

export default WithdrawOperateController;
