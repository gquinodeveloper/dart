routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.withdrawOperate', {
            url: '/withdrawOperate',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/withdrawOperate/template.html',
                controllerAs: 'withdrawOperate',
                controller: "WithdrawOperateController"
              }
            }
          });
}

export default routing;
