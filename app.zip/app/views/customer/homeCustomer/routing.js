routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.homeCustomer', {
            url: '/homeCustomer',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/homeCustomer/template.html',
                controllerAs: 'homeCustomer',
                controller: "HomeCustomerController"
              }
            }
          });
}

export default routing;
