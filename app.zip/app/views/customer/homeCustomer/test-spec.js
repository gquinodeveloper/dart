import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';
//import reversionService from '../../../configuration/reversion/reversion-factory.js';

describe('app/views/customer/homeCustomer/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.$rootScope = $injector.get('$rootScope');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('HomeCustomerController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'swagger': {
          api: {
            corresponsales: {
              configuracion: {
                get: {
                  call: function () {
                    return $q.when()
                  }
                }
              },
              reversionOperacion: {
                post: {
                  call: function () {
                    return $q.when()
                  }
                }
              },
            }
          }
        },
        'reversionService' : {
          setReversionData: function({}){return true;},
          clearReversionData: function(){return true;},
          doReversion: function(){return true;}
        }, 
        'dukptService':{
          encryptForKey: function(){
            return "1234";
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('User´s home Controller', function () {
    it('initLoad defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.initLoad).toBeDefined();
    });
    it('initLoad run no persitent tx', function () {
      var HomeCustomerController = this.createController();
      localStorage.removeItem('bm-persistent-tx-data');
      HomeCustomerController.initLoad();
    });
    it('initLoad run with persitent tx', function () {
      var HomeCustomerController = this.createController();
      localStorage.setItem("bm-persistent-tx-data",
        JSON.stringify({
          cuenta: {
            id: 1
          },
          monto: 1
        })
      );
      HomeCustomerController.initLoad();
    });
    it('getItemsAmount defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.getItemsAmount).toBeDefined();
    });
    it('getItemsAmount run no homeData', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.getItemsAmount()).toBe(0);
    });
    it('getItemsAmount run with homeData', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.data.homeData = [{habilitado: true}]
      expect(HomeCustomerController.getItemsAmount()).toBe(1);
    });
    it('getConfiguration defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.getConfiguration).toBeDefined();
    });
    it('getConfiguration run', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.getConfiguration();
    });
    it('doReverseTx defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.doReverseTx).toBeDefined();
    });
    it('doReverseTx run', function () {
      var HomeCustomerController = this.createController();
      localStorage.setItem("bm-persistent-tx-data",
        JSON.stringify({
          cuenta: {
            id: 1
          },
          monto: 1
        })
      );
      HomeCustomerController.doReverseTx();
    });
    it('optionShowed defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.optionShowed).toBeDefined();
    });
    it('optionShowed run', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.optionShowed();
    });
    it('optionShowed run wrong id', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.data.homeData = [{habilitado: true}]
      expect(HomeCustomerController.optionShowed(9)).toBeFalsy();
    });
    it('optionShowed run must be showed', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.data.homeData = [{habilitado: true}]
      expect(HomeCustomerController.optionShowed(0)).toBeTruthy();
    });
    it('doNavigate defined', function () {
      var HomeCustomerController = this.createController();
      expect(HomeCustomerController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var HomeCustomerController = this.createController();
      HomeCustomerController.doNavigate('login');
    });

  });
});
