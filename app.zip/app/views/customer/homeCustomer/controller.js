HomeCustomerController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', 'authFactory', 'reversionService', 'dukptService', 'printerService', '$ionicPlatform'];

/**
 * @class corresponsales.customer_HomeCustomerController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @returns {undefined}
 */
function HomeCustomerController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, authFactory, reversionService, dukptService, printerService, $ionicPlatform) {
  let homeCustomer = this;
  menuActive.active = 1;
  homeCustomer.data = {
    homeData: {},
  };

  homeCustomer.texts = {
    title: "Seleccionar Operación",
    info: "Información",
    ok: "Aceptar",
    optOut: "Retirar dinero",
    optIn: "Hacer un depósito",
    optAcounts: "Consulta cuentas",
    optRegister: "Registro referidos",
    optRegisterx: "",
    optPay: "Pagar cuotas",
    optSendOrder: "Envíar Giro",
    opPayOrder: "Pagar Giro",
    optCreditRequest: "Solicitud de crédito",
    err001: "Se ha producido un error en la conexión. Por favor, vuelva a acceder pasados unos minutos.",
    err002: "Se ha producido un error en el proceso de actualización de su aplicación. Por favor, intentelo de nuevo más adelante.",
    errIPEK: "Se ha producido un error en el proceso de actualización de su aplicación. Por favor, contacte con su oficina."
  };

  homeCustomer.noIpekLogout = (errorNumber, datos) => {
    $scope.$emit('metrics-custom', {
      event: 'evento: Error tras el sembrado no hay IPEK',
      tag: 'Error sembrado',
      data: [{
        name: "err",
        value: "El servicio no devolvio IPEK o este no se corresponde con su digito de control. Error " + errorNumber +". "+ JSON.stringify(datos) + ". " +
        "Datos en localStorage: BDK: "+ (!!localStorage.getItem('bm-key-bdk') ? 'Si' : 'No') + " " +
        "KSN: "+ (!!localStorage.getItem('bm-key-ksn') ? 'Si' : 'No') + " " +
        "IPEK: "+ (!!localStorage.getItem('bm-key-ipek') ? 'Si' : 'No')
      },
        {
          name: "usuario",
          value: localStorage.getItem('persistUser'),
        }]
    });
    localStorage.removeItem('bm-key-ipek');
    var alertPopup = $ionicPopup.alert({
      title: homeCustomer.texts.info,
      template: homeCustomer.texts.errIPEK + '. (ERROR '+ errorNumber + ').',
      okText: homeCustomer.texts.ok,
    });
    homeCustomer.data.popup = alertPopup;
    alertPopup.then(() => {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner><h4>Se está realizando un proceso interno.<br/> Por favor, espere...</h4>',
        hideOnStateChange: true
      });
      authFactory.logout()
        .then(() => {
          $ionicLoading.hide();
        })
        .catch(() => {
          $ionicLoading.hide();
        });
      localStorage.removeItem('ngStorage-accessToken');
      localStorage.removeItem('bm-configuracion');
      homeCustomer.doNavigate('login');
    });
  };

  homeCustomer.getConfiguration = () => {
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.configuracion.get.call({
      udid: "86361b9cf75b7182"//udid
    }).then((data) => {
      $ionicLoading.hide();
      if (!!data.data.bloqueoLlavesTerminal) {
        localStorage.removeItem("bm-key-bdk");
        localStorage.removeItem("bm-key-ipek");
        localStorage.removeItem("bm-key-ksn");
        swagger.api.corresponsales.llavesBorradas.put.call({
          udid: "86361b9cf75b7182"//udid
        }).then((data) => {
          $scope.$emit('metrics-custom', {
            event: 'Borrado de llaves',
            tag: 'Borrado de llaves',
            data: [{
              name: "msg",
              value: 'Queda confirmado en servidor el borrado de las llaves.'
            }]
          });
        }).catch((err) => {
          $scope.$emit('metrics-custom', {
            event: 'Borrado de llaves',
            tag: 'Borrado de llaves',
            data: [{
              name: "err",
              value: JSON.stringify(err)
            }]
          });
        });
        $scope.$emit('metrics-custom', {
          event: 'Borrado de llaves',
          tag: 'Borrado de llaves',
          data: [{
            name: "msg",
            value: 'Borrado de llaves por peticion desde el servidor.'
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: homeCustomer.texts.info,
          template: homeCustomer.texts.errIPEK,
          okText: homeCustomer.texts.ok,
        });
        homeCustomer.data.popup = alertPopup;
        alertPopup.then(() => {
          homeCustomer.data.popup = null;
        });
        return false;
      }
      localStorage.setItem('bm-configuracion', JSON.stringify(data.data));
      homeCustomer.data.homeData = data.data.homeClientes;
      /*if(!$ionicPlatform.is('browser')){
        if(!parseInt(localStorage.getItem('connectedPrinter'))){
          printerService.tryPrinterConnect();
        }
      }*/
      if (!!data.data.mensaje) {
        setTimeout(() => {
          var alertPopup = $ionicPopup.alert({
            template: "<i class='icon ion-alert-circled'></i><br/>" + data.data.mensaje,
            okText: homeCustomer.texts.ok,
          });
          homeCustomer.data.popup = alertPopup;
          alertPopup.then(() => {
            homeCustomer.data.popup = null;
          });
        }, 500);

      }

      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }

      // if (!!data.data.sembradoLlavesTerminal || !localStorage.getItem('bm-key-ipek')) {
      localStorage.setItem('bm-key-bdk', 'E05BD659FEB31995F4C72E4B81298895');
      localStorage.setItem('bm-key-ksn', '672371CCFC43A618FBE05C3D0D5DB2AC');
      localStorage.setItem('bm-key-ipek', '5FBA4AECC3DE7D33');
      if (!!data.data.sembradoLlavesTerminal) {
        $ionicLoading.show({
          template: '<ion-spinner icon="ripple"></ion-spinner>',
          hideOnStateChange: true
        });
        swagger.api.corresponsales.llavesDispositivo.get.call({
          udid:"86361b9cf75b7182"// udid
        }).then((data) => {
          if (!!data.data.bdk) {
            localStorage.setItem('bm-key-bdk', dukptService.encryptForKey(data.data.bdk));
          }
          if (!!data.data.ksn) {
            localStorage.setItem('bm-key-ksn', dukptService.encryptForKey(data.data.ksn));
          }
          if (!!data.data.ipek) {
            if (dukptService.validateIpekCtrl(dukptService.decrypt(data.data.ipek), data.data.ipekCheckDigits)) {
              let plainIpek = dukptService.decrypt(data.data.ipek);
              localStorage.setItem('bm-key-ipek', dukptService.encryptForKey(plainIpek));
            } else {
              let sendDataToMetrics = {
                ksn: (!!data.data.ksn) ? 'Si' : 'No',
                ipek: (!!data.data.ipek) ? 'Si' : 'No',
                ipekCheckDigits: (!!data.data.ipekCheckDigits) ? 'Si' : 'No',
                bdk: (!!data.data.bdk) ? 'Si' : 'No',
              };
              homeCustomer.noIpekLogout('1', sendDataToMetrics);
              $ionicLoading.hide();
              return false;
            }
          }
          if (!localStorage.getItem('bm-key-ipek')) {
            let sendDataToMetrics = {
              ksn: (!!data.data.ksn) ? 'Si' : 'No',
              ipek: (!!data.data.ipek) ? 'Si' : 'No',
              ipekCheckDigits: (!!data.data.ipekCheckDigits) ? 'Si' : 'No',
              bdk: (!!data.data.bdk) ? 'Si' : 'No',
            };
            homeCustomer.noIpekLogout('2', sendDataToMetrics);
            $ionicLoading.hide();
            return false;
          }
          swagger.api.corresponsales.llavesDispositivo.put.call({
            udid: "86361b9cf75b7182"//udid
          }).then((data) => {
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'evento: Sembrado de llaves',
              tag: 'Validación sembrado correcto de llaves'
            });
          }).catch((err) => {
            $ionicLoading.hide();
            $scope.$emit('metrics-custom', {
              event: 'evento: Error en confirmación sembrado de llaves',
              tag: 'Error sembrado',
              data: [{
                name: "err",
                value: JSON.stringify(err)
              }]
            });
            homeCustomer.noIpekLogout('3', (!!err.data ? err.data : 'Se ha encontrado un error no controlado al realizar el put de las llaves del dispositivo.'));
            return false;
          });
        }).catch((err) => {
          $ionicLoading.hide();
          $scope.$emit('metrics-custom', {
            event: 'evento: Error en sembrado de llaves',
            tag: 'Error sembrado',
            data: [{
              name: "err",
              value: JSON.stringify(err)
            }]
          });
          var alertPopup = $ionicPopup.alert({
            title: homeCustomer.texts.info,
            template: homeCustomer.texts.err002,
            okText: homeCustomer.texts.ok,
          });
          homeCustomer.data.popup = alertPopup;
          alertPopup.then(() => {
            homeCustomer.data.popup = null;
            $ionicLoading.show({
              template: '<ion-spinner icon="ripple"></ion-spinner><h4>Se está realizando un proceso interno.<br/> Por favor, espere...</h4>',
              hideOnStateChange: true
            });
            authFactory.logout()
              .then(() => {
                $ionicLoading.hide();
              })
              .catch(() => {
                $ionicLoading.hide();
              });
            localStorage.removeItem('ngStorage-accessToken');
            localStorage.removeItem('bm-configuracion');
            homeCustomer.doNavigate('login');
          });
        });
      }
    }).catch((err) => {
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: homeCustomer.texts.info,
        template: (err.data && err.data.message) ? err.data.message : 'No ha sido posible realizar la conexión.',
        okText: homeCustomer.texts.ok,
      });
      homeCustomer.data.popup = alertPopup;
      alertPopup.then(() => {
        homeCustomer.data.popup = null;
      });
    });
  };

  // homeCustomer.connectPrinter = () => {
  //   if (printerService.connectInLogin()){
  //     //Ha ido bien
  //
  //   } else {
  //     homeCustomer.doLogout();
  //   }
  //
  // };

  homeCustomer.doReverseTx = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner><h4>Se está realizando un proceso interno.<br/> Por favor, espere...</h4>',
      hideOnStateChange: true
    });
    var reverseTxData = JSON.parse(localStorage.getItem("bm-persistent-tx-data"));
    var idTx = localStorage.getItem("bm-tx-id");
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.reversionOperacion.post.call({
      operacionARevertirDTO: {
        udid: "86361b9cf75b7182",//udid,
        id: (reverseTxData.cuenta ? reverseTxData.cuenta.id : reverseTxData.obligacion.id) + "",
        idTx: idTx + "",
        monto: reverseTxData.monto
      }
    }).then(() => {
      $ionicLoading.hide();
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      reversionService.clearReversionData();
      homeCustomer.getConfiguration();
    }).catch((err) => {
      $ionicLoading.hide();
      if (!err.data || err.data.code + "" != "400") {
        var alertPopup = $ionicPopup.alert({
          title: homeCustomer.texts.info,
          template: homeCustomer.texts.err001,
          okText: homeCustomer.texts.ok,
        });
        homeCustomer.data.popup = alertPopup;
        alertPopup.then(() => {
          homeCustomer.data.popup = null;
          authFactory.logout()
            .then(() => {
              //intentional
            })
            .catch(() => {
              //intentional
            });
          localStorage.removeItem('ngStorage-accessToken');
          localStorage.removeItem('bm-configuracion');
          localStorage.removeItem('bm-transaction-data');
          homeCustomer.doNavigate('login');
        });
      } else {
        $ionicLoading.show({
          template: '<ion-spinner icon="ripple"></ion-spinner>',
          hideOnStateChange: true
        });
        reversionService.clearReversionData();
        homeCustomer.getConfiguration();
      }
    });
  };

  homeCustomer.initLoad = () => {
    $scope.$emit("titleChange", homeCustomer.texts.title);
    /*$scope.$emit('metrics-pagina-vista', "");*/
    localStorage.removeItem('bm-transaction-data');
    var reverseTxData = JSON.parse(localStorage.getItem("bm-persistent-tx-data"));
    if (!reverseTxData) {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      homeCustomer.getConfiguration();
    } else {
      homeCustomer.doReverseTx();
    }
  };

  homeCustomer.getItemsAmount = () => {
    var total = 0;
    for (let i = 0; i < homeCustomer.data.homeData.length; i++) {
      if (!!homeCustomer.data.homeData[i].habilitado) {
        total++;
      }
    }
    return total;
  };

  homeCustomer.optionShowed = (id) => {
    if (id >= homeCustomer.data.homeData.length || homeCustomer.data.homeData[id] == undefined) {
      return false;
    }
    return !!homeCustomer.data.homeData[id].habilitado;
  };

  homeCustomer.doLogout = () => {
    homeCustomer.data.popup = null;
    authFactory.logout()
      .then(() => {
        //intentional
      })
      .catch(() => {
        //intentional
      });
    localStorage.removeItem('ngStorage-accessToken');
    localStorage.removeItem('bm-configuracion');
    localStorage.removeItem('bm-transaction-data');
    homeCustomer.doNavigate('login');
  };

  homeCustomer.doNavigate = (path) => {
    $state.go(path);
  };

  homeCustomer.initLoad();
}

export default HomeCustomerController;
