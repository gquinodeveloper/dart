routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.register', {
            url: '/register',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/register/template.html',
                controllerAs: 'register',
                controller: "RegisterController"
              }
            }
          });
}

export default routing;
