RegisterController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$ionicPopup', '$scope', 'printerService', '$state', '$http'];

/**
 * @class corresponsales.customer_RegisterController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function RegisterController(menuActive, swagger, $ionicLoading, $ionicPopup, $scope, printerService, $state, $http) {
  let register = this;
  menuActive.active = 1;
  register.data = {
    popUp: null,
    corresponsal: "",
    corresponsalId: "",
    customer: {
      firstName: "",
      secondName: "",
      firstSurname: "",
      secondSurname: "",
      department: null,
      city: null,
      district: null,
      phoneType: null,
      phone: "",
      activity: "",
      interest: [0, 0, 0, 0, 0],
      observations: ""
    },
    phoneType: [
      {
        label: "Teléfono fijo",
        value: "1"
      },
      {
        label: "Teléfono celular",
        value: "2"
      },
      {
        label: "Fax",
        value: "3"
      },
    ],
    refRelationship: [
      {
        label: "MADRE",
        value: "7"
      },
      {
        label: "PADRE",
        value: "8"
      },
      {
        label: "HIJO(A)",
        value: "9"
      },
      {
        label: "HERMANO(A)",
        value: "10"
      },
      {
        label: "TIO(A)",
        value: "11"
      },
      {
        label: "PRIMO(A)",
        value: "12"
      },
      {
        label: "YERNO",
        value: "13"
      },
      {
        label: "AMIGO(A)",
        value: "14"
      },
      {
        label: "NUERA",
        value: "15"
      },
      {
        label: "ABUELO(A)",
        value: "30"
      },
      {
        label: "ARRENDADOR",
        value: "31"
      },
      {
        label: "COMPANERO(A)",
        value: "32"
      },
      {
        label: "CONCUNADO(A)",
        value: "33"
      },
      {
        label: "CONSUEGRO(A)",
        value: "34"
      },
      {
        label: "CONYUGE",
        value: "35"
      },
      {
        label: "CUÑADO(A)",
        value: "36"
      },
      {
        label: "HERMANO(A) MEDIO(A)",
        value: "37"
      },
      {
        label: "MADRASTRA",
        value: "38"
      },
      {
        label: "NIETO",
        value: "39"
      },
      {
        label: "PADRASTRO",
        value: "40"
      },
      {
        label: "SOBRINO(A)",
        value: "41"
      },
      {
        label: "SUEGRO(A)",
        value: "42"
      },
      {
        label: "TUTOR",
        value: "43"
      },
      {
        label: "VECINO",
        value: "44"
      },
      {
        label: "PROVEEDOR",
        value: "46"
      },
      {
        label: "HIJOS DISCAP",
        value: "55"
      },
      {
        label: "JARDINERO",
        value: "56"
      },
      {
        label: "CONDUCTOR",
        value: "57"
      },
      {
        label: "AYUDANTE DE FINCA",
        value: "58"
      },
      {
        label: "SERVICIO DOMESTICO",
        value: "59"
      }
    ],
    autocompleteGeo: null,
    ubigeoList: [],
  };
  register.texts = {
    title: "Registro de referidos",
    legend: "Los campos marcados con el símbolo * son obligatorios",
    personalData: "Datos Referido",
    otherData: "Otros datos",
    contactData: "Datos de contacto",
    firstName: "Primer nombre",
    secondName: "Segundo nombre",
    firstSurname: "Primer apellido",
    secondSurname: "Segundo apellido",
    phoneType: "Tipo de teléfono comercial",
    phone: "Teléfono comercial",
    activity: "Actividad",
    interested: "Interesado en...",
    switchOn: "On",
    switchOff: "Off",
    interestCredit: "Créditos",
    interestCDT: "CDT",
    interestSaving: "Ahorro",
    interestInsurance: "Seguros",
    interestOthers: "Otros",
    observations: "¿Cual?",
    refer: "Referente",
    continue: "Continuar > ",
    register: "Dar de alta >",
    modify: "Modificar",
    info: "Información",
    ok: "Aceptar",
    success: "Se ha realizado el registro de referidos satisfactoriamente.",
    names: "Nombre/s",
    lastnames: "Apellido/s",
    dataConfirm: "Confirmación de datos",
    department: "Departamento",
    city: "Ciudad",
    town: "Barrio/Vereda",
    ubigeo: "Departamento, Ciudad o Barrio/Vereda",
    relationship: "Vinculo Referido-Referente",
  };
  register.deptList = [];
  register.provincesFinalList = [];
  register.districtsFinalList = [];
  $scope.cityAuxList = null;
  $scope.districtAuxList = null;
  $http({
    method: 'GET',
    url: './public/json/ciudades/ubigeo.json'
  }).then(function (response){
    register.data.ubigeoList = response.data.ubigeo;
  },function (error){
    console.error('Error getting JSON',error);
  });
  /**
   * @memberOf corresponsales.customer_RegisterController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  register.initLoad = () => {
    $scope.$emit("titleChange", register.texts.title);
    var conf = JSON.parse(localStorage.getItem('bm-configuracion'));
    register.data.corresponsal = conf.cabecera.nombre;
    register.data.corresponsalId = conf.cabecera.codCorresponsal;
  };
  register.initLoad();
  /**
   * @memberOf corresponsales.customer_RegisterController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  register.doNavigate = (path) => {
    $state.go(path);
  };

  register.getInterestsAsText = () => {
    if (!register.data) {
      return "";
    }

    var interests = [
        {
          text: register.texts.interestCredit,
          selected: register.data.customer.interest[0]
        },
        {
          text: register.texts.interestCDT,
          selected: register.data.customer.interest[1]
        },
        {
          text: register.texts.interestSaving,
          selected: register.data.customer.interest[2]
        },
        {
          text: register.texts.interestInsurance,
          selected: register.data.customer.interest[3]
        },
        {
          text: register.texts.interestOthers,
          selected: register.data.customer.interest[4]
        }
      ],
      result = [];

    for (var i in interests) {
      var interest = interests[i];
      if (interest.selected) {
        result.push(interest.text);
      }
    }

    return result.join(", ");
  };

  register.sendValidationError = (validationMsg) => {
    var alertPopup = $ionicPopup.alert({
      title: register.texts.info,
      template: validationMsg,
      okText: register.texts.ok,
    });
    register.data.popup = alertPopup;
    alertPopup.then(() => {
      register.data.popup = null;
    });
    return false;
  };

  register.doConfirm = () => {

    if (!!register.data.popup) {
      register.data.popup.close();
      register.data.popup = null;
      return false;
    }
    if (!register.data.customer.firstName || !register.data.customer.firstSurname
      || !register.data.customer.phone || !register.data.customer.phoneType){
      var alertPopup = $ionicPopup.alert({
        title: register.texts.info,
        template: register.texts.legend,
        okText: register.texts.ok,
      });
      register.data.popup = alertPopup;
      alertPopup.then(() => {
        register.data.popup = null;
      });
      return false;
    }
    if(!!register.data.autocompleteGeo){
      if(!register.data.autocompleteGeo.description.label || !register.data.autocompleteGeo.description.idDept
        || !register.data.autocompleteGeo.description.idProv || !register.data.autocompleteGeo.description.idDistr){
        var alertPopup = $ionicPopup.alert({
          title: register.texts.info,
          template: 'El campo Departamento, Ciudad o Barrio/Vereda es obligatorio',
          okText: register.texts.ok,
        });
        register.data.popup = alertPopup;
        alertPopup.then(() => {
          register.data.popup = null;
        });
        return false;
      } else {
        register.data.customer.city = register.data.autocompleteGeo.description.idProv;
        register.data.customer.district = register.data.autocompleteGeo.description.idDistr;
      }
    } else {
      var alertPopup = $ionicPopup.alert({
        title: register.texts.info,
        template: 'El campo Departamento, Ciudad o Barrio/Vereda es obligatorio',
        okText: register.texts.ok,
      });
      register.data.popup = alertPopup;
      alertPopup.then(() => {
        register.data.popup = null;
      });
      return false;
    }


    if (isNaN(register.data.customer.phone) || register.data.customer.phone % 1 != 0
      || register.data.customer.phone.indexOf(',') != -1 || register.data.customer.phone.indexOf('.') != -1 ||
      register.data.customer.phone.indexOf('e') != -1 || register.data.customer.phone.indexOf('E') != -1) {
      let validationMsg = 'Campo teléfono comercial debe ser un número.';
      register.sendValidationError(validationMsg);
      return false;
    } else {
      switch(register.data.customer.phoneType){
        case '1':
          if(register.data.customer.phone.length != 7){
            let validationMsg = 'Campo teléfono comercial debe tener una longitud de 7 dígitos (Teléfono fijo).';
            register.sendValidationError(validationMsg);
            return false;
          } else {
            if(register.data.customer.phone.charAt(0) == 0 || register.data.customer.phone.charAt(0) == 1){
              let validationMsg = 'Campo teléfono comercial no puede comenzar por 0 ó 1 (Teléfono fijo).';
              register.sendValidationError(validationMsg);
              return false;
            }
          }
          break;
        case '2':
          if(register.data.customer.phone.length != 10){
            let validationMsg = 'Campo teléfono comercial debe tener una longitud de 10 dígitos (Teléfono celular).';
            register.sendValidationError(validationMsg);
            return false;
          } else {
            if(register.data.customer.phone.charAt(0) != 3){
              let validationMsg = 'Campo teléfono comercial debe comenzar por 3 (Teléfono celular).';
              register.sendValidationError(validationMsg);
              return false;
            }
          }
          break;
        case '3':
          if(register.data.customer.phone.length != 7){
            let validationMsg = 'Campo teléfono comercial debe tener una longitud de 7 dígitos (Fax).';
            register.sendValidationError(validationMsg);
            return false;
          }
          break;
      }
    }

    var alertPopup = $ionicPopup.confirm({
      scope: $scope,
      cssClass: 'popup-register-confirm',
      templateUrl: 'views/customer/register/registerConfirm.html',
      okText: register.texts.register,
      cancelText: register.texts.modify,
      title: register.texts.dataConfirm
    });
    alertPopup.then(e => {
      if (!!e) {
        register.doRegister();
      }
    });
  };

  register.doRegister = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid; // eslint-disable-line
      }
    } catch (e) {
      //intentional
    }

    /*
      interesEnCredito:
        type: boolean
        description: Interes En Credito 001
      interesEnCdt:
        type: boolean
        description: Interes En CDT 002
      interesEnAhorro:
        type: boolean
        description: Interes En Ahorro 003
      interesEnSeguro:
        type: boolean
        description: Interes En Seguro 004
      interesEnOtros:
        type: boolean
        description: Interes En Otros 005
     */
    swagger.api.corresponsales.referidos.post.call({
      referidosBody: {
        nombre1: register.data.customer.firstName,
        nombre2: register.data.customer.secondName,
        apellido1: register.data.customer.firstSurname,
        apellido2: register.data.customer.secondSurname,
        tipoTelefono: register.data.customer.phoneType,
        telefono: register.data.customer.phone,
        actEconomica: register.data.customer.activity,
        observacion: register.data.customer.observations,
        interesEnCredito: !!register.data.customer.interest[0],
        interesEnCdt: !!register.data.customer.interest[1],
        interesEnAhorro: !!register.data.customer.interest[2],
        interesEnSeguro: !!register.data.customer.interest[3],
        interesEnOtros: !!register.data.customer.interest[4],
        codCiudad: register.data.customer.city,
        codDistrito: register.data.customer.district,
        vinculo: register.data.customer.refRelationship,
        udid: udid,
      }
    }).then(() => {
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: register.texts.info,
        template: register.texts.success,
        okText: register.texts.ok,
      });
      register.data.popup = alertPopup;
      alertPopup.then(() => {
        $state.go("menu.homeCustomer");
        register.data.popup = null;
      });
    }).catch((err) => {
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: register.texts.info,
        template: err.data.message,
        okText: register.texts.ok,
      });
      register.data.popup = alertPopup;
      alertPopup.then(() => {
        $state.go("menu.homeCustomer");
        register.data.popup = null;
      });
      $scope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Referidos',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
          {
            name: "referido",
            value: JSON.stringify({
              referidosBody: {
                nombre1: register.data.customer.firstName,
                nombre2: register.data.customer.secondName,
                apellido1: register.data.customer.firstSurname,
                apellido2: register.data.customer.secondSurname,
                tipoTelefono: register.data.customer.phoneType,
                telefono: register.data.customer.phone,
                actEconomica: register.data.customer.activity,
                observacion: register.data.customer.observations,
                interesEnCredito: !!register.data.customer.interest[0],
                interesEnCdt: !!register.data.customer.interest[1],
                interesEnAhorro: !!register.data.customer.interest[2],
                interesEnSeguro: !!register.data.customer.interest[3],
                interesEnOtros: !!register.data.customer.interest[4],
                codCiudad: register.data.customer.city,
                codDistrito: register.data.customer.district,
                udid: udid
              }
            })
          }]
      });
    });
  };
  $scope.$watch("register.data.customer.department", (value) => {
    if (value != null) {
      $scope.cityAuxList = register.provincesFinalList.filter(p => p.deptCode == value);
    } else {
      $scope.cityAuxList = null;
    }
  });
  $scope.$watch("register.data.customer.city", (value) => {
    if (value != null) {
      $scope.districtAuxList = register.districtsFinalList.filter(p => p.provCode == value);
    } else {
      $scope.districtAuxList = null;
    }
  });

  $scope.inputChanged = function(str) {
    if ((str.length > 0) && (str.length < 5)) {
      $scope.ubigeoCountdown = "Inserta "+ (5 - str.length) + " " + ((str.length == 4) ? "caracter": "caracteres" ) +" más para comenzar a buscar";
    } else {
      $scope.ubigeoCountdown = "";
    }
  };
}

export default RegisterController;