import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/customer/register/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    localStorage.setItem('bm-configuracion', JSON.stringify({
      cabecera: {
        nombre: "Maria Dolores",
        codCorresponsal: "1"
      }
    }));
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('RegisterController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'swagger': {
          api: {
            corresponsales: {
              referidos: {
                post: {
                  call: function () {
                    return $q.when()
                  }
                }
              }
            }
          }
        },
        'printerService': {
          printErrorTicket: function (type, text) {
            return true;
          }
        }
      });
    };
  }));


  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Customer_register Controller', function () {
    it('initLoad defined', function () {
      var RegisterController = this.createController();
      expect(RegisterController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var RegisterController = this.createController();
      RegisterController.initLoad();
    });
    it('doNavigate defined', function () {
      var RegisterController = this.createController();
      expect(RegisterController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var RegisterController = this.createController();
      RegisterController.doNavigate('login');
    });
    it('doRegister defined', function () {
      var RegisterController = this.createController();
      expect(RegisterController.doRegister).toBeDefined();
    });
    it('doRegister run', function () {
      var RegisterController = this.createController();
      RegisterController.doRegister();
    });
    it('doRegister run with popup', function () {
      var RegisterController = this.createController();
      RegisterController.data.customer = 1;
      RegisterController.data.firstSurname = "María Dolores";
      RegisterController.data.phone = 987654321;
      expect(RegisterController.doRegister()).toBeFalsy();
    });
  });
});
