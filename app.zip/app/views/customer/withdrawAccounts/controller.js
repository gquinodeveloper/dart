WithdrawAccountsController.$inject = ['menuActive', '$state', '$scope'];

/**
 * @class corresponsales.customer_WithdrawAccountsController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $state Objeto angular par a la realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function WithdrawAccountsController(menuActive, $state, $scope) {
  let withdrawAccounts = this;
  menuActive.active = 1;
  withdrawAccounts.data = {
    popUp: null,
    transactionData: {}
  };

  withdrawAccounts.texts = {
    title: "Retirar dinero",
    name: "Titular",
    info: "Información",
    select: "Seleccione una cuenta",
    ok: "Aceptar",
    account: "Cuenta "
  };

  /**
   * @memberOf corresponsales.customer_WithdrawAccountsController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista. Obtiene los datos alamacenados en local sobre la transaccion
   * @returns {undefined} la función emite el cambio de título
   */
  withdrawAccounts.initLoad = () => {
    $scope.$emit("titleChange", withdrawAccounts.texts.title);
    withdrawAccounts.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    if (!withdrawAccounts.data.transactionData || withdrawAccounts.data.transactionData == undefined) {
      withdrawAccounts.doNavigate('menu.homeCustomer');
    }
    if(!!withdrawAccounts.data.transactionData.searchAccByAcc) {
      let temp = [];
      temp.push(withdrawAccounts.data.transactionData.cuentas[0]);
      withdrawAccounts.data.transactionData.cuentas = temp;
    }
  };

  /**
   * @memberOf corresponsales.customer_WithdrawAccountsController
   * @name doNavigate
   * @description función que centraliza las navegaciones de la vista
   * @param {type} path ruta de destino de la navegación 
   */
  withdrawAccounts.doNavigate = (path) => {
    $state.go(path);
  };

  /**
   * @memberOf corresponsales.customer_WithdrawAccountsController
   * @name goTransaction
   * @description funcion a invocar para avanzar en la transaccion. prepara el nuevo objeto con la información 
   * @param item objeto json con la cuenta seleccionada
   * @returns {undefined} realiza una transaccion a la vista para terminar la operación
   */
  withdrawAccounts.goTransaction = (item) => {
    withdrawAccounts.data.transactionData.selected = item;
    localStorage.setItem('bm-transaction-data', JSON.stringify(withdrawAccounts.data.transactionData));
    withdrawAccounts.doNavigate('menu.withdrawOperate');
  };
  withdrawAccounts.initLoad();
}

export default WithdrawAccountsController;