routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.withdrawAccounts', {
            url: '/withdrawAccounts',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/withdrawAccounts/template.html',
                controllerAs: 'withdrawAccounts',
                controller: "WithdrawAccountsController"
              }
            }
          });
}

export default routing;
