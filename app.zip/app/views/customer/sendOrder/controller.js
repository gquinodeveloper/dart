SendOrderController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$rootScope', '$filter', 'cyptojsService'];

/**
 * @class corresponsales.customer_DepositWayController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */

function SendOrderController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope, $filter, cyptojsService) {

}


