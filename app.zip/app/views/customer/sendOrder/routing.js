routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.sendOrder', {
            url: '/sendOrder',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/sendOrder/template.html',
                controllerAs: 'sendOrder',
                controller: "SendOrderController"
              }
            }
          });
}

export default routing;