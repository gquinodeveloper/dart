routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.depositAccounts', {
            url: '/depositAccounts',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/depositAccounts/template.html',
                controllerAs: 'depositAccounts',
                controller: "DepositAccountsController"
              }
            }
          });
}

export default routing;
