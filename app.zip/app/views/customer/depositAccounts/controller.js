DepositAccountsController.$inject = ['menuActive', '$state', '$scope'];

/**
 * @class corresponsales.customer_DepositAccountsController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $state Objeto angular par a la realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function DepositAccountsController(menuActive, $state, $scope) {
  let depositAccounts = this;
  menuActive.active = 1;
  depositAccounts.data = {
    popUp: null,
    transactionData: {}
  };

  depositAccounts.texts = {
    title: "Hacer un depósito",
    name: "Titular",
    info: "Información",
    select: "Seleccione una cuenta",
    ok: "Aceptar",
    account: "Cuenta "
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista. Obtiene los datos alamacenados en local sobre la transaccion
   * @returns {undefined} la función emite el cambio de título
   */
  depositAccounts.initLoad = () => {
    $scope.$emit("titleChange", depositAccounts.texts.title);
    depositAccounts.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    if (!depositAccounts.data.transactionData || depositAccounts.data.transactionData == undefined) {
      depositAccounts.doNavigate('menu.homeCustomer');
    }
    if(!!depositAccounts.data.transactionData.searchAccByAcc) {
      let temp = [];
      temp.push(depositAccounts.data.transactionData.cuentas[0]);
      depositAccounts.data.transactionData.cuentas = temp;
    }
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name doNavigate
   * @description función que centraliza las navegaciones de la vista
   * @param {type} path ruta de destino de la navegación 
   */
  depositAccounts.doNavigate = (path) => {
    $state.go(path);
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name goTransaction
   * @description funcion a invocar para avanzar en la transaccion. prepara el nuevo objeto con la información 
   * @param item objeto json con la cuenta seleccionada
   * @returns {undefined} realiza una transaccion a la vista para terminar la operación
   */
  depositAccounts.goTransaction = (item) => {
    depositAccounts.data.transactionData.selected = item;
    localStorage.setItem('bm-transaction-data', JSON.stringify(depositAccounts.data.transactionData));
    depositAccounts.doNavigate('menu.depositOperate');
  };
  depositAccounts.initLoad();
}

export default DepositAccountsController;