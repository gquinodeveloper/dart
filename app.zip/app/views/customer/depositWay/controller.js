DepositWayController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$rootScope', '$filter', 'cyptojsService'];

/**
 * @class corresponsales.customer_DepositWayController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function DepositWayController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope, $filter, cyptojsService) {
  let depositWay = this;
  menuActive.active = 1;
  depositWay.data = {
    homeData: {},
    document: {
      label: "DNI",
      value: "21"
    },
    documents: [
      {
        label: "DNI",
        value: "21"
      },
      {
        label: "Pasaporte",
        value: "5"
      },
      {
        label: "Carné Extranjería",
        value: "2"
      },
      {
        label: "Doc. Institución Fin",
        value: "99"
      },
      {
        label: "Otro Documento",
        value: "31"
      },
      {
        label: "PTP",
        value: "25"
      },
      {
        label: "SWIFT",
        value: "13"
      },
      {
        label: "Trámite",
        value: "15"
      }
    ],
    documentNumber: '',
    accountNumber: '',
    popUp: null
  };

  depositWay.texts = {
    title: "Hacer un depósito",
    info: "Información",
    ok: "Aceptar",
    numberPlaceholder: "Número de documento",
    accountPlaceholder: "Número de cuenta",
    getAccounts: "Consultar cuentas >",
    getAccount: "Consultar cuenta >",
    usingDocument: "Acceder ingresando DOI:",
    usingAccount: "O introducir número de cuenta:",
    switchOn: "Nº de cuenta",
    switchOff: "Documento",
    otp: "Introduzca el OTP que ha recibido el cliente en su celular",
    err001: "Complete el formulario para continuar.",
    err002: "Cliente sin operaciones que permitan hacer un depósito.",
    err003: "OTP incorrecta. La OTP debe ser numérica.",
    err004: "OTP incorrecta. La longitud del OTP es de 6 caracteres.",
    err005: "OTP incorrecta.",
    err006: "No existe ese número de cuenta. Revise los datos introducidos.",
    err007: "El número de cuenta debe contener 12 dígitos."
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  depositWay.initLoad = () => {
    $scope.$emit("titleChange", depositWay.texts.title);
  };
  depositWay.initLoad();

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  depositWay.doNavigate = (path) => {
    $state.go(path);
  };

  depositWay.validateOtp = (eOtp) => {
    if ((eOtp + "").length != 6) {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP longitud incorrecta',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP con una longitud incorrecta (!=6) en consulta de cuentas de depósitos."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: depositWay.texts.info,
        template: depositWay.texts.err004,
        okText: depositWay.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else if (isNaN(eOtp) || eOtp % 1 != 0 || eOtp.indexOf(',') != -1 || eOtp.indexOf('.') != -1 || eOtp.indexOf('e') != -1 || eOtp.indexOf('E') != -1) {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'evento: Error OTP is NaN',
        tag: 'Error OTP',
        data: [{
          name: "err",
          value: "Se ha introducido una OTP isNaN en consulta de cuentas de depósitos."
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: depositWay.texts.info,
        template: depositWay.texts.err003,
        okText: depositWay.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
    } else {
      return true;
    }
  };

  /**
   * @memberOf corresponsales.customer_DepositWayController
   * @name getAccounts
   * @description función que realiza la buscqueda en servidor de todas las cuentas de un usuario seleccionado mediante tipo de documento y número
   * @returns {undefined} la función emite el cambio de título
   */
  depositWay.getAccounts = () => {
    if (!!depositWay.data.popup) {
      depositWay.data.popup.close();
      depositWay.data.popup = null;
      return false;
    }
    if (!depositWay.data.document.value || !depositWay.data.documentNumber) {
      var alertPopup = $ionicPopup.alert({
        title: depositWay.texts.info,
        template: depositWay.texts.err001,
        okText: depositWay.texts.ok,
      });
      depositWay.data.popup = alertPopup;
      alertPopup.then(() => {
        depositWay.data.popup = null;
      });
    } else {
      if ( ( depositWay.data.document.value == '21' || depositWay.data.document.value == '25' ) && (depositWay.data.documentNumber.length < depositWay.docTypeLimits(depositWay.data.document.value))){
        var alertPopup = $ionicPopup.alert({
          title: depositWay.texts.info,
          template: 'Es necesario introducir '+ depositWay.docTypeLimits(depositWay.data.document.value) +' dígitos',
          okText: depositWay.texts.ok,
        });
        depositWay.data.popup = alertPopup;
        alertPopup.then(() => {
          depositWay.data.popup = null;
        });
        return false;
      }
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.otpCuentas.get.call({
        tipoDoc: depositWay.data.document.value + "",
        numDoc: depositWay.data.documentNumber + "",
        udid: "86361b9cf75b7182"//udid,
      }).then((data) => {
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.prompt({
          title: depositWay.texts.otp,
          okText: depositWay.texts.continue,
          cancelText: depositWay.texts.cancel,
          inputType: 'text',
          inputPlaceholder: 'OTP'
        });
        depositWay.data.popup = alertPopup;
        alertPopup.then((eOtp) => {
          depositWay.data.popup = null;
          if (!!eOtp) {
            $ionicLoading.show({
              template: '<ion-spinner icon="ripple"></ion-spinner>',
              hideOnStateChange: true
            });
            if(depositWay.validateOtp(eOtp)) {
              swagger.api.corresponsales.cuentas.get.call({
                tipoOp: '1',
                tipoDoc: depositWay.data.document.value,
                numDoc: depositWay.data.documentNumber + "",
                udid: "86361b9cf75b7182",//udid,
                otpEncriptado: cyptojsService.encryptOTP(eOtp, cyptojsService.encryptPassphrase(data.data.message)),
                numTx: data.data.message
              }).then((data) => {
                $ionicLoading.hide();
                if (data.data.cuentas.length == 0) {
                  var alertPopup = $ionicPopup.alert({
                    title: depositWay.texts.info,
                    template: depositWay.texts.err002,
                    okText: depositWay.texts.ok,
                  });
                  depositWay.data.popup = alertPopup;
                  alertPopup.then(() => {
                    depositWay.data.popup = null;
                    //printerService.printErrorTicket("Deposito", depositWay.texts.err002);
                  });
                } else {
                  data.data.tipoDoc = depositWay.data.document;
                  data.data.numDoc = depositWay.data.documentNumber;
                  localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
                  depositWay.doNavigate('menu.depositAccounts');
                }
              }).catch((err) => {
                $ionicLoading.hide();
                $rootScope.$emit('metrics-custom', {
                  event: 'Error en respuesta de servicio',
                  tag: 'Deposito - identificacion usuario',
                  data: [{
                    name: "msg",
                    value: JSON.stringify(err)
                  }]
                });
                var alertPopup = $ionicPopup.alert({
                  title: depositWay.texts.info,
                  template: err.data.message,
                  okText: depositWay.texts.ok,
                });
                depositWay.data.popup = alertPopup;
                alertPopup.then(() => {
                  depositWay.data.popup = null;
                  // printerService.printErrorTicket("Deposito", err.data.message);
                });
              });
            }
          }
        });
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error generando OTP cuentas depositos',
          tag: 'Cuentas',
          data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: depositWay.texts.info,
          template: (!!err.data.message ? err.data.message : "ERROR GENERANDO OTP" ),
          okText: depositWay.texts.ok,
        });
        depositWay.data.popup = alertPopup;
        alertPopup.then(() => {
          depositWay.data.popup = null;
        });
      });
    }
  };

  depositWay.getAccount = () => {
    if (!!depositWay.data.accountNumber) {
      if (depositWay.data.accountNumber.length < 12){
        var alertPopup = $ionicPopup.alert({
          title: depositWay.texts.info,
          template: depositWay.texts.err007,
          okText: depositWay.texts.ok,
        });
        depositWay.data.popup = alertPopup;
        alertPopup.then(() => {
          depositWay.data.popup = null;
        });
        return false;
      }
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.cuentas.get.call({
        tipoOp: '1',
        numProd: depositWay.data.accountNumber + "",
        udid: "86361b9cf75b7182",//udid
      }).then((data) => {
        $ionicLoading.hide();
        if (data.data.cuentas.length == 0) {
          var alertPopup = $ionicPopup.alert({
            title: depositWay.texts.info,
            template: depositWay.texts.err006,
            okText: depositWay.texts.ok,
          });
          depositWay.data.popup = alertPopup;
          alertPopup.then(() => {
            depositWay.data.popup = null;
          });
        } else {
          let valueTipoDoc = data.data.tipoDoc;
          data.data.tipoDoc = $filter('filter')(depositWay.data.documents, {'value': valueTipoDoc});
          data.data.searchAccByAcc = true;
          localStorage.setItem('bm-transaction-data', JSON.stringify(data.data));
          depositWay.doNavigate('menu.depositAccounts');
        }
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error en respuesta de servicio',
          tag: 'Cuentas',
          data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: depositWay.texts.info,
          template: err.data.message,
          okText: depositWay.texts.ok,
        });
        depositWay.data.popup = alertPopup;
        alertPopup.then(() => {
          depositWay.data.popup = null;
          // printerService.printErrorTicket("Retiro", err.data.message);
        });
      });
    } else {
      var alertPopup = $ionicPopup.alert({
        title: depositWay.texts.info,
        template: depositWay.texts.err001,
        okText: depositWay.texts.ok,
      });
      depositWay.data.popup = alertPopup;
      alertPopup.then(() => {
        depositWay.data.popup = null;
      });
    }
  };

  depositWay.docTypeLimits = (docType) => {
    switch (docType){
      case '21': //DNI
        return 8;
      case '25': //PTP
        return 9;
      case '5': //PASAPORTE
      case '2': //CARNÉ EXTRANJERÍA
        return 12;
      case '31': //OTRO DOCUMENTO
        return 15;
      default:
        return 20;
    }
  };

  depositWay.limitFieldsTo = (newVal,oldVal,limit) => {
    if(newVal.length > limit){
      depositWay.data.documentNumber = oldVal;
    } else {
      depositWay.data.documentNumber = newVal;
    }
  };

  $scope.$watch("depositWay.data.documentNumber", function(newVal, oldVal) {
    depositWay.limitFieldsTo(newVal,oldVal,depositWay.docTypeLimits(depositWay.data.document.value));
  });

  $scope.$watch("depositWay.data.document.value", function(newVal, oldVal) {
    depositWay.data.documentNumber = '';
  });
}

export default DepositWayController;
