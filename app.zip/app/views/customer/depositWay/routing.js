routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.depositWay', {
            url: '/depositWay',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/depositWay/template.html',
                controllerAs: 'depositWay',
                controller: "DepositWayController"
              }
            }
          });
}

export default routing;
