import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/customer/depositWay/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('DepositWayController', {'$scope': this.$scope, 'menuActive': {active:1},
        'swagger': {
          api: {
            corresponsales: {
              cuentas: {
                get: {
                  call: function () {return $q.when()}
                }
              }
            }
          }
        },
        'printerService':{
          printErrorTicket: function(type, text){
            return true;
          }
        }
      });
    };
  }));
  
  
  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Customer_depositWay Controller', function () {
    it('initLoad defined', function () {
      var DepositWayController = this.createController();
      expect(DepositWayController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var DepositWayController = this.createController();
      DepositWayController.initLoad();
    });
    it('doNavigate defined', function () {
      var DepositWayController = this.createController();
      expect(DepositWayController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var DepositWayController = this.createController();
      DepositWayController.doNavigate();
    });
    it('getAccounts defined', function () {
      var DepositWayController = this.createController();
      expect(DepositWayController.getAccounts).toBeDefined();
    });
    it('getAccounts run', function () {
      var DepositWayController = this.createController();
      DepositWayController.getAccounts();
    });
  });
});
