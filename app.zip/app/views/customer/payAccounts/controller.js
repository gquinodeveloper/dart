PayAccountsController.$inject = ['menuActive', '$state', '$scope'];

/**
 * @class corresponsales.customer_DepositAccountsController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $state Objeto angular par a la realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function PayAccountsController(menuActive, $state, $scope) {
  let payAccounts = this;
  menuActive.active = 1;
  payAccounts.data = {
    popUp: null,
    transactionData: {}
  };

  payAccounts.texts = {
    title: "Pago de cuota",
    name: "Titular",
    info: "Información",
    select: "Seleccione un crédito",
    ok: "Aceptar",
    account: "Obligación ",
    minimum: "Pago Mínimo:",
    total: "Pago Total:",
    period: "Cuota"
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista. Obtiene los datos alamacenados en local sobre la transaccion
   * @returns {undefined} la función emite el cambio de título
   */
  payAccounts.initLoad = () => {
    $scope.$emit("titleChange", payAccounts.texts.title);
    payAccounts.data.transactionData = JSON.parse(localStorage.getItem('bm-transaction-data'));
    if (!payAccounts.data.transactionData || payAccounts.data.transactionData == undefined) {
      payAccounts.doNavigate('menu.homeCustomer');
    }
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name doNavigate
   * @description función que centraliza las navegaciones de la vista
   * @param {type} path ruta de destino de la navegación 
   */
  payAccounts.doNavigate = (path) => {
    $state.go(path);
  };

  /**
   * @memberOf corresponsales.customer_DepositAccountsController
   * @name goTransaction
   * @description funcion a invocar para avanzar en la transaccion. prepara el nuevo objeto con la información 
   * @param item objeto json con la cuenta seleccionada
   * @returns {undefined} realiza una transaccion a la vista para terminar la operación
   */
  payAccounts.goTransaction = (item) => {
    payAccounts.data.transactionData.selected = item;
    localStorage.setItem('bm-transaction-data', JSON.stringify(payAccounts.data.transactionData));
    payAccounts.doNavigate('menu.payOperate');
  };
  payAccounts.initLoad();
}

export default PayAccountsController;