routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.payAccounts', {
            url: '/payAccounts',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/customer/payAccounts/template.html',
                controllerAs: 'payAccounts',
                controller: "PayAccountsController"
              }
            }
          });
}

export default routing;
