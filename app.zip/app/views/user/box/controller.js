BoxController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$scope', '$ionicPopup', '$filter', '$rootScope', 'printerService'];

/**
 * @class corresponsales.user_BoxController
 * @memberOf corresponsales
 * @description Controlador de la vista de cuadre diario
 * @param {Object} $ionicLoading - Dependencia para la referencia al manejo del spinner
 * @param {Object} $ionicPopup - Objeto que referencia el componente popup para los mensajes emergentes
 * @param {Object} $state - Objeto angular para la realización de la navegación
 * @param {Object} $rootScope - Objeto que referencia el ambito global de la aplicación
 * @param {Object} menuActive - Factory para marcar el elemento seleccionado del menú
 * @param {Object} swagger - Referencia al objeto swagger para el manejo de los endpoints
 * @param {function} $filter - Filtros de AngularJS
 * @param {Object} $scope - Objeto que hace referencia al modelo de la aplicación
 * @param {Object} printerService - Servicio propio con funciones de impresora
 */
function BoxController(menuActive, swagger, $ionicLoading, $state, $scope, $ionicPopup, $filter, $rootScope, printerService) {
  let box = this;
  menuActive.active = 2;
  box.data = {
    search: new Date(),
    searchAux: new Date(),
    closed: true,
    lines: [],
    detailBlocks: [],
    ini: "",
    end: "",
    quota: "",
    endwallet: 0,
    showingDetail: false,
    diffJustification: "",
    pressedConfirm: false,
    pressedPrint: false,
    saldocierre: ''
  };

  box.texts = {
    title: "Cuadre diario",
    search: "Buscar cuadre por día",
    doSearch: "Ver cuadre >",
    boxDay: "Cuadre a ",
    info: "Información",
    ok: "Aceptar",
    cancel: "Cancelar",
    return: "Volver",
    acceptBox: "Aceptar cuadre",
    continue: "Continuar",
    boxOk: "Aceptar cuadre",
    succes: "Se ha lanzado el procedimiento de cierre de cuadre.",
    summary: "< Volver a resumen",
    detail: "Detalle >",
    quota: "Cupo utilizado",
    breakdown: [
      "Saldo inicial: ",
      "Fondos própios: ",
      "Pago de obligaciones: ",
      "Depósitos: ",
      "Retiros de efectivo: ",
      "Valor total reversiones del día: ",
      "Valor cupo utilizado:",
      "Consignaciones banco convenio: ",
      "Saldo final esperado: "
    ],
    ini: "Saldo inicial: ",
    end: "Saldo neto efectivo: ",
    future: "No se pueden realizar búsquedas a fechas futuras.",
    print: "Imprimir ",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde.",
    closeBalance: "Saldo a la hora de cierre",
    bills: "Billetes",
    coins: "Monedas",
    endwallet: "Saldo final billetero",
    difference: "Diferencia",
    diffWarning: "Tiene una diferencia de %DIFF%, por favor revise los datos del billetero",
    diffJustification: "Tiene una diferencia de %DIFF%, por favor justifique el descuadre:",
    noOk: "No aceptar"
  };

  box.wallet = {};

  /**
   * @memberOf corresponsales.user_BoxController
   * @function initLoad
   * @description Función que realiza la carga inicial de la vista
   */
  box.initLoad = () => {
    $scope.$emit("titleChange", box.texts.title);
    box.doSearch();
    $scope.$watch('box.data.search', () => {
      box.data.closed = true;
      box.data.lines = [];
      box.data.conceptosNoContables = [];
      box.data.conceptosReversiones = [];
      box.data.ini = "";
      box.data.end = "";
      box.data.quota = "";
      box.data.detailBlocks = [];
      box.data.showingDetail = false;
      box.initWallet();
    });
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function initWallet
   * @description Función que inicializa el valor del monedero
   */
  box.initWallet = () => {
    box.wallet = {
      active: true,
      billetes: [
        {
          cantidad: 0,
          valor: "200.0",
          codigo: "COP",
          simbolo: "S/ "
        },
        {
          cantidad: 0,
          valor: "100.0",
          codigo: "COP",
          simbolo: "S/ "
        },
        {
          cantidad: 0,
          valor: "50.0",
          codigo: "COP",
          simbolo: "S/ "
        },
        {
          cantidad: 0,
          valor: "20.0",
          codigo: "COP",
          simbolo: "S/ "
        },
        {
          cantidad: 0,
          valor: "10.0",
          codigo: "COP",
          simbolo: "S/"
        }
      ],
      monedas: [
        {
          cantidad: 0,
          valor: "5.0",
          codigo: "COP",
          simbolo: "S/"
        },
        {
          cantidad: 0,
          valor: "2.0",
          codigo: "COP",
          simbolo: "S/"
        },
        {
          cantidad: 0,
          valor: "1.0",
          codigo: "COP",
          simbolo: "S/"
        },
        {
          cantidad: 0,
          valor: "0.50",
          codigo: "COP",
          simbolo: "S/",
        },
        {
          cantidad: 0,
          valor: "0.20",
          codigo: "COP",
          simbolo: "S/"
        },
        {
          cantidad: 0,
          valor: "0.10",
          codigo: "COP",
          simbolo: "S/"
        }
      ]
    };
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function doNavigate
   * @param {String} path - Ruta de destino de la navegacion
   * @description Función que centraliza las navegaciones de la vista
   */
  box.doNavigate = (path) => {
    $state.go(path);
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function showDetail
   * @description Función que establece si muestra el detalle del cuadre
   */
  box.showDetail = () => {
    box.data.showingDetail = !box.data.showingDetail;
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function doSearch
   * @description Función que busca el cuadre del dia introducido
   */
  box.doSearch = () => {
    if (box.data.search > new Date()) {
      let alertPopup = $ionicPopup.alert({
        title: box.texts.info,
        template: box.texts.future,
        okText: box.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    }
    if (!box.data.search || box.data.search == null) {
      return false;
    }
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "86361b9cf75b7182";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    box.data.searchAux = box.data.search;
    swagger.api.corresponsales.cuadreDiario.get.call({
      udid: udid,
      fecha: $filter('date')(box.data.search, 'yyyy/MM/dd')
    }).then((data) => {
      box.data.ini = data.data.saldoIni;
      box.data.end = data.data.saldoFin;
      box.data.quota = data.data.cupoUtilizado;
      box.data.lines = data.data.conceptos;
      box.data.conceptosNoContables = data.data.conceptosNoContables;
      box.data.conceptosReversiones = data.data.conceptosReversiones;
      box.data.detailBlocks = data.data.bloquesDetalle;
      box.data.closed = data.data.estaCerrado;
      box.data.showingDetail = false;
      box.data.fromDate = data.data.fechaDesde;
      box.data.toDate = data.data.fechaHasta;
      box.wallet.billetes = data.data.billetes.length > 0 ? data.data.billetes : box.wallet.billetes;
      box.wallet.monedas = data.data.monedas.length > 0 ? data.data.monedas : box.wallet.monedas;
      box.wallet.active = data.data.billeteroActivo;
      box.calculateWallet();
      $ionicLoading.hide();
    }).catch((err) => {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Obtener cuadre',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
        {
          name: "cuadre",
          value: JSON.stringify({
            udid: udid,
            fecha: $filter('date')(box.data.search, 'yyyy/MM/dd')
          })
        }]
      });
      if (!err.data) {
        err.data = {
          message: box.texts.err004
        };
        let alertPopup = $ionicPopup.alert({
          title: box.texts.info,
          template: err.data.message,
          okText: box.texts.ok,
        });
        alertPopup.then(() => {
          $state.go("menu.homeUser");
          return false;
        });
      } else {
        let alertPopup = $ionicPopup.alert({
          title: box.texts.info,
          template: err.data.message,
          okText: box.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
      }
      return false;
    });
  };
  box.initLoad();

  /**
   * @memberOf corresponsales.user_BoxController
   * @function isPrintable
   * @description Función que determina si se puede imprimir el cuadre o no
   * @returns {Boolean} - True si esta cerrado el día y false en caso contrario
   */
  box.isPrintable = () => {
    if (!!box.data.closed && (!!box.data.lines.length || !!box.data.conceptosNoContables.length || !!box.data.conceptosReversiones.length)) {
      return true;
    }
    return false;
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function getQuotaClass
   * @description Función que determina si añadir una clase o no
   * @returns {String} - Etiqueta para controlar una clase del DOM
   */
  box.getQuotaClass = () => {
    if (box.data.quota < 0) {
      return 'primary-label';
    }
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function getQuota
   * @description Función que construye un string de la cuota calculada
   * @returns {String} - Valor de la cuota
   */
  box.getQuota = () => {
    if (!box.data.quota) {
      return "";
    }
    let simbol = "S/ ";
    if (box.data.quota < 0) {
      box.data.quota = box.data.quota * (-1);
      simbol = "-S/ ";
    }
    return simbol + $filter('number')(box.data.quota, 2);
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function doPrint
   * @description Función que imprime el cuadre
   */
  box.doPrint = () => {
    box.data.pressedPrint = true;
    printerService.printBox({
      ini: box.data.ini,
      end: box.data.end,
      lines: box.data.lines,
      date: box.data.search,
      quota: box.getQuota(),
      revs: box.data.conceptosReversiones
    });
    box.data.pressedPrint = false;
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function doClose
   * @description Función que cierra y valida el cuadre introducido
   */
  box.doClose = () => {
    box.data.pressedConfirm = true;
    if (box.wallet.active && box.getDifference() != 0) {
      $ionicPopup.show({
        scope: $scope,
        title: box.texts.info,
        template: '<p>' + box.texts.diffWarning.replace('%DIFF%', 'S/ ' + $filter('number')(box.getDifference(), 2)) + '</p>',
        buttons: [
          {
            text: box.texts.return,
            type: 'button-stable',
            onTap: () => {
              box.data.pressedConfirm = false;
            }
          },
          {
            text: box.texts.acceptBox,
            type: 'button-positive',
            onTap: () => {
              if (box.getDifference() >= 1000) {
                $ionicPopup.show({
                  scope: $scope,
                  title: box.texts.info,
                  template: box.texts.diffJustification.replace('%DIFF%', 'S/ ' + $filter('number')(box.getDifference(), 2)) + `
                      <p class="textarea-container">
                        <textarea ng-click="" ng-model="box.data.diffJustification"></textarea>
                      </p>`,
                  buttons: [
                    {
                      text: box.texts.noOk,
                      type: 'button-stable',
                      onTap: () => {
                        box.data.pressedConfirm = false;
                      }
                    },
                    {
                      text: box.texts.ok,
                      type: 'button-positive',
                      onTap: () => {
                        box.finalizeClose();
                        box.data.pressedConfirm = false;
                      }
                    }
                  ]
                });
              } else {
                box.finalizeClose();
                box.data.pressedConfirm = false;
              }
            }
          }
        ]
      });
    } else {
      box.finalizeClose();
      box.data.pressedConfirm = false;
    }
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function finalizeClose
   * @description Función que envia el cuadre introducido cerrado
   */
  box.finalizeClose = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    box.data.searchAux = box.data.search;
    //Nuevo cálculo - Distribuir monto en monedas de 1 y 0.10
    console.log('Saldo final =>', box.data.saldocierre);

    var saldodec = (box.data.saldocierre+"").split(".")[1];
    if (saldodec == undefined) {
      saldodec = 0;
    } else {
      if (saldodec.length > 1) {
        saldodec = saldodec.substring(0, 1);
      }
    }

    for (let i = 0; i < box.wallet.monedas.length; i++) {
      if (!box.wallet.monedas[i].cantidad) {
        box.wallet.monedas[i].cantidad = 0;
      }
      if (box.wallet.monedas[i].valor == "1.0") {
        console.log('Monedas de 1');
        box.wallet.monedas[i].cantidad = Math.trunc(box.data.saldocierre);
      }

      if (box.wallet.monedas[i].valor == "0.10") {
        console.log('Monedas de 0.10');
        box.wallet.monedas[i].cantidad = Math.trunc(saldodec);
      }
    }
    for (let i = 0; i < box.wallet.billetes.length; i++) {
      if (!box.wallet.billetes[i].cantidad) {
        box.wallet.billetes[i].cantidad = 0;
      }
    }

    console.log('Wallet', box.wallet);
    
    var monedas = box.wallet.monedas,
      billetes = box.wallet.billetes;      
    swagger.api.corresponsales.cuadreDiarioConBilletero.put.call({
      cierreBilleteroDTO: {
        udid: udid,
        monedas: monedas,
        billetes: billetes,
        descuadre: box.data.diffJustification ? box.data.diffJustification : ""
      }
    }).then(() => {
      $ionicLoading.hide();
      let alertPopup = $ionicPopup.alert({
        title: box.texts.info,
        template: box.texts.succes,
        okText: box.texts.ok,
      });
      alertPopup.then(() => {
        box.doSearch();
        return false;
      });
    }).catch((err) => {
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Enviar cuadre',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
          {
            name: "cuadre",
            value: JSON.stringify({
              udid: udid
            })
          }]
      });
      $ionicLoading.hide();
      let alertPopup = $ionicPopup.alert({
        title: box.texts.info,
        template: err.data.message,
        okText: box.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    });
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function calculateWallet
   * @description Función que calcula el valor de lo introducido en el monedero
   */
  box.calculateWallet = () => {
    //box.data.endwallet = 0;
    box.data.saldocierre = 0;
    let money = ['billetes', 'monedas'];
    for (var i in money) {
      for (var x in box.wallet[money[i]]) {
        var b = box.wallet[money[i]][x];
        if (b.cantidad > 0) {
          //box.data.endwallet += b.valor * b.cantidad;
          box.data.saldocierre += b.valor * b.cantidad;
        }
      }
    }
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function getDifference
   * @description Función que calcula la diferencia del valor de lo que debería tener con lo introducido
   * @returns {Number} - Diferencia entre valores
   */
  box.getDifference = () => {
    //return Math.abs(box.data.end - box.data.endwallet);
    return Math.abs(box.data.end - box.data.saldocierre);
  };

  /**
   * @memberOf corresponsales.user_BoxController
   * @function getDifferenceSign
   * @description Función que devuelve el signo a poner con la diferencia del valor de lo que debería tener con lo introducido
   * @returns {String} - Tipo de signo dependiendo de la resta
   */
  box.getDifferenceSign = () => {
    //let diff = box.data.end - box.data.endwallet;
    let diff = box.data.end - box.data.saldocierre;
    if (diff == 0) {
      return '';
    }
    return diff < 0 ? '+' : '-';
  };
}

export default BoxController;