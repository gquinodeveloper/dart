routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.box', {
            url: '/box',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/user/box/template.html',
                controllerAs: 'box',
                controller: "BoxController"
              }
            }
          });
}

export default routing;
