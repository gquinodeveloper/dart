import UserModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/user/operations/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(UserModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('BoxController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'printerService':{
          printErrorTicket: function(type, text){
            return true;
          },
          connectForTicket: function([]){
            return true;
          },
          testPrinter: function(){return true;}
        },
        'swagger': {
          api: {
            corresponsales: {
              cuadreDiario: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                },
                put: {
                  call: function () {
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('User_BoxController', function () {
    it('initLoad defined', function () {
      var BoxController = this.createController();
      expect(BoxController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var BoxController = this.createController();
      BoxController.initLoad();
    });
    it('doNavigate defined', function () {
      var BoxController = this.createController();
      expect(BoxController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var BoxController = this.createController();
      BoxController.doNavigate('login');
    });
    it('doSearch defined', function () {
      var BoxController = this.createController();
      expect(BoxController.doSearch).toBeDefined();
    });
    it('doSearch run', function () {
      var BoxController = this.createController();
      BoxController.doSearch();
    });
    it('doClose defined', function () {
      var BoxController = this.createController();
      expect(BoxController.doClose).toBeDefined();
    });
    it('doClose run', function () {
      var BoxController = this.createController();
      BoxController.udid = "123456789";
      BoxController.doClose();
    });
    it('showDetail defined', function () {
      var BoxController = this.createController();
      expect(BoxController.showDetail).toBeDefined();
    });
    it('showDetail run show detail', function () {
      var BoxController = this.createController();
      BoxController.data.showingDetail = false;
      BoxController.showDetail();
      expect(BoxController.data.showingDetail).toBeTruthy();
    });
    it('getQuotaClass defined', function () {
      var BoxController = this.createController();
      expect(BoxController.getQuotaClass).toBeDefined();
    });
    it('getQuotaClass run', function () {
      var BoxController = this.createController();
      BoxController.getQuotaClass();
    });
    it('getQuotaClass run negative quota', function () {
      var BoxController = this.createController();
      BoxController.data.quota = -1;
      expect(BoxController.getQuotaClass()).toBe("primary-label");
    });
    it('getQuotaCgetQuotalass defined', function () {
      var BoxController = this.createController();
      expect(BoxController.getQuota).toBeDefined();
    });
    it('getQuota run', function () {
      var BoxController = this.createController();
      expect(BoxController.getQuota()).toBe("");
    });
    it('getQuota run positive Quota', function () {
      var BoxController = this.createController();
      BoxController.data.quota = 1;
      expect(BoxController.getQuota()).toBe("$1,00");
    });
    it('getQuota run negative Quota', function () {
      var BoxController = this.createController();
      BoxController.data.quota = -1;
      expect(BoxController.getQuota()).toBe("-$1,00");
    });
    it('wallet initWallet defined', function () {
      var BoxController = this.createController();
      expect(BoxController.initWallet).toBeDefined();
    });
    it('wallet initWallet run', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      expect(BoxController.wallet).toBeDefined();
    });
    it('wallet calculateWallet defined', function () {
      var BoxController = this.createController();
      expect(BoxController.calculateWallet).toBeDefined();
    });
    it('wallet calculateWallet run', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      BoxController.wallet.billetes[0].cantidad=1;
      BoxController.wallet.monedas[0].cantidad=2;
      BoxController.calculateWallet();
      expect(BoxController.data.endwallet).toBe(52000);
    });
    it('wallet getDifference defined', function () {
      var BoxController = this.createController();
      expect(BoxController.getDifference).toBeDefined();
    });
    it('wallet getDifference run', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      BoxController.wallet.billetes[0].cantidad=1;
      BoxController.wallet.monedas[0].cantidad=2;
      BoxController.calculateWallet();
      BoxController.data.end = 50000;
      expect(BoxController.getDifference()).toBe(2000);
    });
    it('wallet getDifferenceSign defined', function () {
      var BoxController = this.createController();
      expect(BoxController.getDifferenceSign).toBeDefined();
    });
    it('wallet getDifference run unsigned', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      BoxController.wallet.billetes[0].cantidad=1;
      BoxController.wallet.monedas[0].cantidad=2;
      BoxController.calculateWallet();
      BoxController.data.end = 52000;
      expect(BoxController.getDifferenceSign()).toBe('');
    });
    it('wallet getDifference run positive', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      BoxController.wallet.billetes[0].cantidad=1;
      BoxController.wallet.monedas[0].cantidad=2;
      BoxController.calculateWallet();
      BoxController.data.end = 1000;
      expect(BoxController.getDifferenceSign()).toBe('+');
    });
    it('wallet getDifference run negative', function () {
      var BoxController = this.createController();
      BoxController.initWallet()
      BoxController.wallet.billetes[0].cantidad=1;
      BoxController.wallet.monedas[0].cantidad=2;
      BoxController.calculateWallet();
      BoxController.data.end = 100000;
      expect(BoxController.getDifferenceSign()).toBe('-');
    });
  });
});
