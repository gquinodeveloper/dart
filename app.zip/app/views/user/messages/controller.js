MessagesController.$inject = ['menuActive', '$ionicLoading', '$state', '$scope', '$ionicPopup', '$rootScope', 'msjService', 'swagger'];

/**
 * @class corresponsales.MessagesController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function MessagesController(menuActive, $ionicLoading, $state, $scope, $ionicPopup, $rootScope, msjService, swagger, errorLogService) {
  let messages = this;
  menuActive.active = 2;
  messages.data = {
    list: [],
    subject: "",
    predef: false,
    message: {
      label: "",
      value: ""
    },
    subjects: []
  };

  messages.texts = {
    title: "Mensajería",
    subject: "Asunto",
    predef: "Predefinido",
    switchOn: "Si",
    switchOff: "No",
    send: "Enviar",
    required: "Es obligatorio introducir asunto y mensaje.",
    search: "Introduzca texto para buscar",
    noPredef: "No ha sido posible obtener ningún mensaje predefinido",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde."
  };

  /**
   * @memberOf corresponsales.BoxController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  messages.initLoad = () => {
    $scope.$emit("titleChange", messages.texts.title);
    $scope.$on("newMsjArrive", (event, data) => {
      messages.loadMessages();
    });
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.mensajesPredefinidos.get.call().then((data) => {
      for (let i = 0; i < data.data.length; i++) {
        var item = {
          label: data.data[i].asunto,
          value: data.data[i].texto,
        };
        messages.data.subjects.push(item);
      }
      if (messages.data.subjects.length == 0) {
        var alertPopup = $ionicPopup.alert({
          title: messages.texts.info,
          template: messages.texts.noPredef,
          okText: messages.texts.ok,
        });
        alertPopup.then(() => {
          messages.doNavigate("menu.homeUser");
          return false;
        });
        return false;
      }
      messages.loadMessages();
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Mensajes predefinidos',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      if (!err.data) {
        err.data = {
          message: messages.texts.err004
        };
      }
      var alertPopup = $ionicPopup.alert({
        title: messages.texts.info,
        template: err.data.message,
        okText: messages.texts.ok,
      });
      alertPopup.then(() => {
        messages.doNavigate("menu.homeUser");
        return false;
      });    
    });
  };

  messages.loadMessages = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });

    var udid = "86361b9cf75b7182";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.mensajes.get.call({
      udid: udid
    }).then((data) => {
      $ionicLoading.hide();
      messages.data.list = data.data;
      msjService.setNumber(0);
      msjService.setNumber(0);
      if(!!JSON.parse(localStorage.getItem("BM-messages-tx"))){
        let tx = JSON.parse(localStorage.getItem("BM-messages-tx"));
        messages.data.subject = `Caso - ${tx.solicitudReversion.idSolicitudRev}`;
        localStorage.removeItem("BM-messages-tx");
      }
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Obtener mensajes',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      if (!err.data) {
        err.data = {
          message: messages.texts.err004
        };
      }
      var alertPopup = $ionicPopup.alert({
        title: messages.texts.info,
        template: err.data.message,
        okText: messages.texts.ok,
      });
      alertPopup.then(() => {
        messages.doNavigate("menu.homeUser");
        return false;
      });
    });
    $ionicLoading.hide();
  };

  messages.initLoad();

  /**
   * @memberOf corresponsales.BoxController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion 
   * @description función que centraliza las navegaciones de la vista
   */
  messages.doNavigate = (path) => {
    $state.go(path);
  };

  messages.doReply = (item) => {
    messages.data.subject = item.asunto;
    messages.data.predef = false;
    messages.data.message.value = item.texto;
  };

  messages.doSend = () => {
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    var params = {
      texto: messages.data.message.value,
      udid: udid
    };
    if (!!messages.data.predef) {
      params.asunto = messages.data.message.label;
    } else {
      params.asunto = messages.data.subject;
    }
    if (!params.texto || !params.asunto) {
      var alertPopup = $ionicPopup.alert({
        title: messages.texts.info,
        template: messages.texts.required,
        okText: messages.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    } else {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      swagger.api.corresponsales.mensaje.post.call({
        MensajeDTO: params
      }).then(() => {
        messages.loadMessages();
        messages.data.message.value = "";
        messages.data.message.label = "";
        messages.data.subject = "";
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
            event: 'Error en respuesta de servicio',
            tag: 'Mensajes',
            data: [{
              name: "msg",
              value: JSON.stringify(err)
            }]
        });
        if (!err.data) {
          err.data = {
            message: messages.texts.err004
          };
        }
        var alertPopup = $ionicPopup.alert({
          title: messages.texts.info,
          template: err.data.message,
          okText: messages.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
      });
    }
  };
}

export default MessagesController;