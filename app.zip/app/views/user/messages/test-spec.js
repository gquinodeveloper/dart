import UserModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/user/messages/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(UserModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('MessagesController', {'$scope': this.$scope,
        'menuActive': {active: 2},
        swagger: {
          api: {
            corresponsales: {
              mensajesPredefinidos: {
                get: {
                  call: function(){
                    return $q.when();
                  }
                }
              },
              mensaje: {
                post: {
                  call: function(){
                    return $q.when();
                  }
                }
              }
            }
          }
        },
        'msjService': {
          props:{
            current: 0,
            last: 0
          }
        }
      });
    };
  }));


  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('User_MessagesController', function () {
    describe('InitLoad', function () {
      it('initLoad defined', function () {
        var MessagesController = this.createController();
        expect(MessagesController.initLoad).toBeDefined();
      });
      it('initLoad run', function () {
        var MessagesController = this.createController();
        MessagesController.initLoad();
      });
    });
    describe('doNavigate', function () {
      it('doNavigate defined', function () {
        var MessagesController = this.createController();
        expect(MessagesController.doNavigate).toBeDefined();
      });
      it('doNavigate run', function () {
        var MessagesController = this.createController();
        MessagesController.doNavigate();
      });
    });
    describe('doReply', function () {
      it('doReply defined', function () {
        var MessagesController = this.createController();
        expect(MessagesController.doReply).toBeDefined();
      });
      it('doReply run', function () {
        var MessagesController = this.createController();
        MessagesController.data.predef = true;
        MessagesController.doReply({
          asunto: "",
          texto: ""
        });
        expect(MessagesController.data.predef).toBeFalsy();
      });
    });
    describe('doSend', function (){
      it('doSend defined', function(){
        var MessagesController = this.createController();
        expect(MessagesController.doSend).toBeDefined();
      });
      it('doSend run without text', function(){
        var MessagesController = this.createController();
        expect(MessagesController.doSend()).toBeFalsy();
      });
      it('doSend run  predef with text', function(){
        var MessagesController = this.createController();
        MessagesController.data.message.value = "texto";
        MessagesController.data.message.label = "asunto";
        MessagesController.data.predef = true;
        MessagesController.doSend();
      });
      it('doSend run no predef with text', function(){
        var MessagesController = this.createController();
        MessagesController.data.message.value = "texto";
        MessagesController.data.subject = "asunto";
        MessagesController.data.predef = false;
        MessagesController.doSend();
      });
    })
  });
});
