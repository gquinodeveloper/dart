routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.messages', {
            url: '/messages',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/user/messages/template.html',
                controllerAs: 'messages',
                controller: "MessagesController"
              }
            }
          });
}

export default routing;
