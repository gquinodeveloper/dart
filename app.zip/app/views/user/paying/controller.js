PayingController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$rootScope'];

/**
 * @class corresponsales.PayingController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @returns {undefined}
 */
function PayingController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope) {
  let paying = this;
  menuActive.active = 2;
  paying.data = {
    motivoRechazo: "",
    pending: [
    ],
    accepted: [
    ],
    review: [
    ],
    reviewedPending: [
    ]
  };

  paying.texts = {
    title: "Liquidación de comisiones",
    info: "Información",
    disclaimer: "Tener en cuenta que las comisiones por transacciones exitosas son susceptibles de descuentos por temas tributarios.",
    ok: "Aceptar",
    denay: "Rechazar",
    cancel: "Cancelar",
    reason: "Motivo del rechazo",
    cancel: "Cancelar",
    paying: "Comisión: ",
    number: "Nº de operaciones: ",
    accepted: "Aceptadas ",
    pending: "Pendientes de aceptación",
    review: "Solicitada revisión",
    reviewedPending: "Revisadas pendientes de aceptacion",
    obligatory: "Es obligatorio añadir el motivo del rechazo.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde."
  };

  /**
   * @memberOf corresponsales.OperationsController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  paying.initLoad = () => {
    $scope.$emit("titleChange", paying.texts.title);
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    paying.data = {
      motivoRechazo: "",
      pending: [
      ],
      accepted: [
      ],
      review: [
      ],
      reviewedPending: [
      ]
    };
    var udid = "86361b9cf75b7182";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.liquidaciones.get.call({
      udid: udid
    }).then((data) => {
      $ionicLoading.hide();
      for (let i = 0; i < data.data.pendienteAceptacion.length; i++) {
        let item = {
          id: data.data.pendienteAceptacion[i].mesNro,
          month: data.data.pendienteAceptacion[i].mes,
          amount: data.data.pendienteAceptacion[i].valorPagar,
          operations: data.data.pendienteAceptacion[i].cantidadTx,
          original: data.data.pendienteAceptacion[i]
        };
        paying.data.pending.push(item);
      }
      for (let i = 0; i < data.data.solicitadaRevision.length; i++) {
        let item = {
          id: data.data.solicitadaRevision[i].mesNro,
          month: data.data.solicitadaRevision[i].mes,
          amount: data.data.solicitadaRevision[i].valorPagar,
          operations: data.data.solicitadaRevision[i].cantidadTx,
          justificacionCB: data.data.solicitadaRevision[i].justificacionCB
        };
        paying.data.review.push(item);
      }
      for (let i = 0; i < data.data.revisadaPendienteAceptacion.length; i++) {
        let item = {
          id: data.data.revisadaPendienteAceptacion[i].mesNro,
          month: data.data.revisadaPendienteAceptacion[i].mes,
          amount: data.data.revisadaPendienteAceptacion[i].valorPagar,
          operations: data.data.revisadaPendienteAceptacion[i].cantidadTx,
          justificacionCB: data.data.revisadaPendienteAceptacion[i].justificacionCB,
          justificacionBO: data.data.revisadaPendienteAceptacion[i].justificacionBO,
          original: data.data.revisadaPendienteAceptacion[i]
        };
        paying.data.reviewedPending.push(item);
      }
      for (let i = 0; i < data.data.aceptada.length; i++) {
        let item = {
          id: data.data.aceptada[i].mesNro,
          month: data.data.aceptada[i].mes,
          amount: data.data.aceptada[i].valorPagar,
          operations: data.data.aceptada[i].cantidadTx
        };
        paying.data.accepted.push(item);
      }
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'liquidaciones',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: paying.texts.info,
        template: err.data.message,
        okText: paying.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    });
  };
  paying.initLoad();

  /**
   * @memberOf corresponsales.OperationsController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion 
   * @description función que centraliza las navegaciones de la vista
   */
  paying.doNavigate = (path) => {
    $state.go(path);
  };

  paying.doAcceptPending = (item) => {
    paying.data.motivoRechazo = "";
    paying.doResolveLiq(item, true);
  };

  paying.doDenay = (item) => {
    var alertPopup = $ionicPopup.prompt({
      title: paying.texts.reason,
      inputType: "text",
      inputPlaceholder: "Motivo del rechazo",
      okText: paying.texts.ok,
      cancelText: paying.texts.cancel,
    });
    alertPopup.then(function (res) {
      if (!!res) {
        paying.data.motivoRechazo = res;
        paying.doResolveLiq(item, false);
      } else {
        if (res == "") {
          var alertPopup = $ionicPopup.alert({
            title: paying.texts.info,
            template: paying.texts.obligatory,
            okText: paying.texts.ok,
          });
          paying.data.popup = alertPopup;
          alertPopup.then(() => {
            paying.data.popup = null;
          });
        } else {
          return false;
        }
      }
    });
  };
  paying.doResolveLiq = (item, resolve) => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    if (!!resolve) {
      item.original.estado = '1';
    } else {
      item.original.estado = '4';
    }
    item.original.udid = udid;
    item.original.justificacionCB = paying.data.motivoRechazo;
    swagger.api.corresponsales.liquidacion.put.call({
      Comisión: item.original
    }).then((data) => {
      paying.data.motivoRechazo = "";
      paying.initLoad();
    }).catch((err) => {
      paying.data.motivoRechazo = "";
      $ionicLoading.hide();
      if (!err.data || !err.data.message) {
        err = {
          data: {
            message: paying.texts.err004
          }
        };
      }
      var alertPopup = $ionicPopup.alert({
        title: paying.texts.info,
        template: err.data.message,
        okText: paying.texts.ok,
      });
      paying.data.popup = alertPopup;
      alertPopup.then(() => {
        paying.data.popup = null;
      });
    });
  };



}

export default PayingController;