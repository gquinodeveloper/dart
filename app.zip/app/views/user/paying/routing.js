routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.paying', {
            url: '/paying',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/user/paying/template.html',
                controllerAs: 'paying',
                controller: "PayingController"
              }
            }
          });
}

export default routing;
