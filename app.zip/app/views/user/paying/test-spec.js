import UserModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/user/paying/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(UserModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('PayingController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'swagger': {
          api: {
            corresponsales: {
              liquidaciones: {
                get: {
                  call: function () {
                    return $q.when()
                  }
                }
              },
              liquidacion: {
                put: {
                  call: function () {
                    return $q.when()
                  }
                }
              }
            }
          }
        }
      });
    };
  }));


  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('User_paying Controller', function () {
    describe('initload', function () {
      it('initLoad defined', function () {
        var PayingController = this.createController();
        expect(PayingController.initLoad).toBeDefined();
      });
      it('initLoad run', function () {
        var PayingController = this.createController();
        PayingController.initLoad();
      });
    });
    describe('doNavigate', function () {
      it('doNavigate run', function () {
        var PayingController = this.createController();
        PayingController.doNavigate('login');
      });
      it('doNavigate defined', function () {
        var PayingController = this.createController();
        expect(PayingController.doNavigate).toBeDefined();
      });
    });
    describe('doAcceptPending', function () {
      it('doAcceptPending defined', function () {
        var PayingController = this.createController();
        expect(PayingController.doAcceptPending).toBeDefined();
      });
      it('doAcceptPending run', function () {
        var PayingController = this.createController();
        PayingController.doAcceptPending({original: {}});
      });
    })
    describe('doDenay', function () {
      it('doDenay defined', function () {
        var PayingController = this.createController();
        expect(PayingController.doDenay).toBeDefined();
      });
      it('doDenay run', function () {
        var PayingController = this.createController();
        PayingController.doDenay({original: {}});
      });
    })
    describe('doResolveLiq', function () {
      it('doResolveLiq defined', function () {
        var PayingController = this.createController();
        expect(PayingController.doResolveLiq).toBeDefined();
      });
    })
  });
});
