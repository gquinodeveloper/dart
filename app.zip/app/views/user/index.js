import HomeUserController from './homeUser/controller';
import HomeUserRouting from './homeUser/routing';
import OperationsController from './operations/controller';
import OperationsRouting from './operations/routing';
import BoxController from './box/controller';
import BoxRouting from './box/routing';
import PayingController from './paying/controller';
import PayingRouting from './paying/routing';
import MessagesController from './messages/controller';
import MessagesRouting from './messages/routing';
export default angular.module('UserModule', [
  'ui.router',
  'ionic'
])

        .controller('HomeUserController', HomeUserController)
        .config(HomeUserRouting)

        .controller('OperationsController', OperationsController)
        .config(OperationsRouting)
        .controller('BoxController', BoxController)
        .config(BoxRouting)
        .controller('PayingController', PayingController)
        .config(PayingRouting)
        .controller('MessagesController', MessagesController)
        .config(MessagesRouting)

        .name;
