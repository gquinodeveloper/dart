routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.homeUser', {
            url: '/homeUser',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/user/homeUser/template.html',
                controllerAs: 'homeUser',
                controller: "HomeUserController"
              }
            }
          });
}

export default routing;
