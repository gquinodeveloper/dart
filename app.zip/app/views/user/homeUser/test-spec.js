import CustomerModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/user/homeUser/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(CustomerModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.$rootScope = $injector.get('$rootScope');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('HomeUserController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'swagger': {
          api: {
            corresponsales: {
              transacciones: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                }
              }
            }
          }
        },
        'printerService': {
          printLast: function () {
            return true;
          }
        },
        'txFailureService': {
          printLastTxErr: function () {
            return true;
          },
          printLastTx: function () {
            return true;
          }
        },
        'msjService': {
          props: {
            last: 0,
            current: 0
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
    localStorage.setItem('bm-configuracion', JSON.stringify({
      homeCorresponsal: {
        cupoUtilizado: 20,
        cupoTotal: 100
      }
    }));
  }));

  describe('User Controller', function () {
    it('captionSpin defined', function () {
      var HomeUserController = this.createController();
      expect(HomeUserController.captionSpin).toBeDefined();
    });
    it('captionSpin run', function () {
      var HomeUserController = this.createController();
      HomeUserController.captionSpin(0);
    });
    it('initLoad defined', function () {
      var HomeUserController = this.createController();
      expect(HomeUserController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var HomeUserController = this.createController();
      HomeUserController.initLoad();
    });
    it('doNavigate defined', function () {
      var HomeUserController = this.createController();
      expect(HomeUserController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var HomeUserController = this.createController();
      HomeUserController.doNavigate('login');
    });
    it('callLastPrint defined', function () {
      var HomeUserController = this.createController();
      expect(HomeUserController.callLastPrint).toBeDefined();
    });
    it('callLastPrint run', function () {
      var HomeUserController = this.createController();
      HomeUserController.callLastPrint();
    });
  });
});
