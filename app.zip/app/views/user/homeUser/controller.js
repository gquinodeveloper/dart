HomeUserController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', 'printerService', 'msjService', '$filter', 'txFailureService'];

/**
 * @class corresponsales.user_HomeUserController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @returns {undefined}
 */
function HomeUserController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, printerService, msjService, $filter, txFailureService) {
  let homeUser = this;
  menuActive.active = 2;
  homeUser.data = {
    homeData: {},
    msjNumber: 0,
    dailys: ""// "2 cuadres pendientes"
  };
  homeUser.texts = {
    title: "Panel Corresponsal",
    info: "Información",
    ok: "Aceptar",
    operations: "Operaciones",
    last: "Imprimir última transacción",
    daily: "Cuadre diario",
    message: "Mensajes",
    fees: "Comisiones",
    quota: "Cupo total: ",
    usedQuota: "Cupo utilizado: ",
    freeQuota: "Cupo disponible: ",
    days: "días",
    left: "Faltan",
    daysToGo: "Días de periodicidad",
  };

  homeUser.initLoad = () => {
    $scope.$emit("titleChange", homeUser.texts.title);
    localStorage.removeItem('bm-transaction-data');
    homeUser.data.msjNumber = msjService.props.current;
    $scope.$on("newMsjArrive", (event, data) => {
      homeUser.data.msjNumber = msjService.props.current;
    });
    homeUser.data.homeData = JSON.parse(localStorage.getItem('bm-configuracion')).homeCorresponsal;
    homeUser.data.homeData.used = ((homeUser.data.homeData.cupoUtilizado * 100) / homeUser.data.homeData.cupoTotal).toFixed(2) + "%";
    homeUser.data.homeData.usedQuota = homeUser.data.homeData.cupoUtilizado;
    homeUser.data.homeData.freeQuota = homeUser.data.homeData.cupoTotal - homeUser.data.homeData.cupoUtilizado;
    homeUser.data.homeData.caption = ((homeUser.data.homeData.cupoUtilizado * 100) / homeUser.data.homeData.cupoTotal);
  };

  homeUser.doNavigate = (path) => {
    $state.go(path);
  };

  homeUser.callLastPrint = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    var dIni = new Date();
    dIni.setMonth(dIni.getMonth() - 1);
    swagger.api.corresponsales.transacciones.get.call({
      udid: udid,
      tipoTX: "",
      fechaInicio: $filter('date')(dIni, 'yyyy/MM/dd'),
      fechaFin: $filter('date')(new Date(), 'yyyy/MM/dd'),
    }).then((data) => {
      $ionicLoading.hide();
      localStorage.removeItem('bm-last-ticket');
      for (let i = 0; i < data.data.length; i++) {
        if (data.data[i].tipoTX + '' != '3') {
          if(data.data[i].estadoTx + '' == '0'){
            txFailureService.printLastTx(data.data[i]);
            return false;
          } else {
            txFailureService.printLastTxErr(data.data[i]);
            return false;
          }
        }
      }
      //printerService.printLast();
    }).catch((err) => {
      $ionicLoading.hide();
      localStorage.removeItem('bm-last-ticket');
      //printerService.printLast();
    });
  };

  homeUser.initLoad();
}

export default HomeUserController;
