import UserModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/user/operations/test-spec.js', function () {
  'use strict';
  beforeEach(angular.mock.module(UserModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.
  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('OperationsController', {'$scope': this.$scope, 'menuActive': {active: 1},
        'swagger': {
          api: {
            corresponsales: {
              transacciones: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                }
              },
              solicitarReversion: {
                post: {
                  call: function() {
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));


  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('User_operations Controller', function () {
    it('initLoad defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var OperationsController = this.createController();
      OperationsController.initLoad();
    });
    it('doSearch defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.doSearch).toBeDefined();
    });
    it('doSearch run', function () {
      var OperationsController = this.createController();
      OperationsController.doSearch();
    });
    it('loadMore defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.loadMoreOperations).toBeDefined();
    });
    it('loadMore run', function () {
      var OperationsController = this.createController();
      OperationsController.data.operationsShowed = ['a', 'b'];
      OperationsController.data.operations = ['a', 'b', 'c'];
      OperationsController.loadMoreOperations();
    });
    it('continueInfinite defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.continueInfinite).toBeDefined();
    });
    it('continueInfinite run', function () {
      var OperationsController = this.createController();
      expect(OperationsController.continueInfinite()).toBeFalsy();
    });
    it('continueInfinite run with listUser', function () {
      var OperationsController = this.createController();
      OperationsController.data.operationsShowed = ['a', 'b'];
      OperationsController.data.operations = ['a', 'b'];
      expect(OperationsController.continueInfinite()).toBeFalsy();
    });
    it('showDetail defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.showDetail).toBeDefined();
    });
    it('showDetail run', function () {
      localStorage.setItem('bm-configuracion', JSON.stringify({cabecera: {telefono: '5555555'}}))
      var OperationsController = this.createController();      
      OperationsController.showDetail({solicitudReversion:{idSolicitudRev:3}});
    });
    it('showDetail run with solicitud del extorno', function () {
      var OperationsController = this.createController();
      OperationsController.showDetail({solicitudReversion: true});
    });
    it('doNavigate defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.doNavigate).toBeDefined();
    });
    it('doNavigate run', function () {
      var OperationsController = this.createController();
      OperationsController.doNavigate('login');
    });
    it('closeReversionPanel defined', function (){
      var OperationsController = this.createController();
      expect(OperationsController.closeReversionPanel).toBeDefined();
    });
    it('closeReversionPanel run', function (){
      var OperationsController = this.createController();
      OperationsController.closeReversionPanel();
    });
    it('closeReversionPanel run expecting false', function (){
      var OperationsController = this.createController();
      OperationsController.closeReversionPanel();
      expect(OperationsController.data.doingRev).toBeFalsy();
    });
    it('doReversion is defined', function (){
      var OperationsController = this.createController();
      expect(OperationsController.doReversion).toBeDefined();
    });
    it('doReversion run without reversion desc', function(){
      var OperationsController = this.createController();
      OperationsController.data.reversionData.desc = null;
      OperationsController.doReversion();
    });
    it('doReversion run with reversion desc', function(){
      var OperationsController = this.createController();
      OperationsController.data.reversionData.desc = true;
      OperationsController.doReversion();
    });
    it('getReversionStateIcon defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon).toBeDefined();
    });
    it('getReversionStateIcon run', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon()).toBe("");
    });
    it('getReversionStateIcon run reversion in process', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon('3')).toBe("ion-android-warning");
    });
    it('getReversionStateIcon run reversion in process manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon('6')).toBe("ion-android-warning");
    });
    it('getReversionStateIcon run reversion ok manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon('7')).toBe("ion-android-done");
    });
    it('getReversionStateIcon run reversion denied', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon('5')).toBe("ion-android-close");
    });
    it('getReversionStateIcon run reversion denied manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateIcon('8')).toBe("ion-android-close");
    });
    it('getReversionStateLabel run', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel()).toBe("");
    });
    it('getReversionStateLabel run reversion in process', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('3')).toBe("Solicitada");
    });
    it('getReversionStateLabel run reversion in process manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('6')).toBe("Solicitada");
    });
    it('getReversionStateLabel run reversion ok', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('4')).toBe("Automática");
    });
    it('getReversionStateLabel run reversion ok manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('7')).toBe("Aceptada");
    });
    it('getReversionStateLabel run reversion denied', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('5')).toBe("Rechazada");
    });
    it('getReversionStateLabel run reversion denied manual', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getReversionStateLabel('8')).toBe("Rechazada");
    });
    it('getTxType defined', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getTxType).toBeDefined();
    });
    it('getTxType run unknown type', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getTxType()).toBe("Desconocido");
    });
    it('getTxType run deposito', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getTxType('1')).toBe("Depósito");
    });
    it('getTxType run deposito', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getTxType('2')).toBe("Pago de Cuota");
    });
    it('getTxType run deposito', function () {
      var OperationsController = this.createController();
      expect(OperationsController.getTxType('3')).toBe("Registro de Referidos");
    });
  });
});
