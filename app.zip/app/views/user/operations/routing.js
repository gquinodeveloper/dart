routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.operations', {
            url: '/operations',
            params: {normalizeConfiguration: null},
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/user/operations/template.html',
                controllerAs: 'operations',
                controller: "OperationsController"
              }
            }
          });
}

export default routing;
