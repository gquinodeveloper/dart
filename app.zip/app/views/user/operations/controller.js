OperationsController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$filter', '$rootScope', '$ionicModal', '$document', '$stateParams'];

/**
 * @class corresponsales.OperationsController
 * @memberOf corresponsales
 * @description Controlador de la vista/componente de menú del perfil officeProfile
 * @param {object} $ionicLoading dependencia para la referencia al manejo del spiner
 * @param {object} $ionicPopup objeto que referencia el component epopup para los mensajes emergentes
 * @param {object} $state Objeto angular par ala realización de la navegación
 * @param {object} menuActive Factory para marcar el elemento seleccionado del menú
 * @param {object} swagger referencia al objeto swagger para el manejo de los endpoints
 * @param {object} $scope referencia al objeto angular utilizado para poder transmitir el cambio de titulo
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param {Object} $stateParams - Objeto de Angular UI Router que permite pasar valores entre rutas
 * @returns {undefined}
 */
function OperationsController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $filter, $rootScope, $ionicModal, $document, $stateParams) {
  let operations = this;
  menuActive.active = 2;
  operations.data = {
    scrollBottom: false,
    directiveScrollBottom: false,
    popUp: null,
    showPortraitFilter: false,
    slideOptions: {
      loop: false,
      effect: 'cube',
      speed: 500,
    },
    reversionItem: {},
    reversionData: {
      q1: false,
      q1Value: null,
      q2: false,
      q2Value1: null,
      q2Value2: null,
      q3: false,
      desc: "",
    },
    showedItem: null,
    transactionType: {
      label: "Todas",
      id: ""
    },
    transactionTypes: [
      {
        label: "Todos",
        id: ""
      },
      {
        label: "Depósitos",
        id: "1"
      },
      {
        label: "Pagos de cuota",
        id: "2"
      },
      {
        label: "Referidos",
        id: "3"
      },
      {
        label: "Retiros",
        id: "4"
      },
      {
        label: "Solicitud de crédito",
        id: "5"
      },
      {
        label: "Reversiones",
        id: "rev"
      }
    ],
    fIni: new Date(),
    fEnd: new Date(),
    operations: [
    ],
    operationsShowed: [

    ],
    observationType: {
      label: "",
      id: ""
    },
    observationTypes: [
      {
        label: "",
        id: ""
      },
      {
        label: "Error en el monto de la transacción",
        id: "1"
      },
      {
        label: "Error en el cliente de la transacción",
        id: "2"
      },
      {
        label: "Transacción duplicada por error",
        id: "3"
      }
    ],
    fromTransaction: $stateParams.normalizeConfiguration,
  };

  operations.texts = {
    title: "Operaciones",
    info: "Información",
    filter: "Filtrar",
    ok: "Aceptar",
    continue: "Solicitar extorno >",
    cancel: "Cerrar x",
    transactionType: "Tipo de transacción",
    fIni: "Fecha Inicio",
    fEnd: "Fecha fin",
    search: "Ver resultados >",
    date: "Fecha",
    txType: "Tipo",
    doc: "Documento",
    cta: "Operación",
    sendMsg: "Enviar mensaje de chat",
    ammount: "Monto",
    reversion: "Extorno",
    reversionOk: "Se ha solicitado el extorno de la solicitud. Número de caso: ",
    reversionDesc: "Es obligatorio introducir el motivo de la solciitud del extorno",
    observationSelect: "Es obligatorio seleccionar y justificar un motivo de la solicitud del extorno",
    switchOn: "Si",
    switchOff: "No",
    form: "Solicitud",
    answer: "Para presentar la solicitud de extorno, responda a las siguientes preguntas",
    question1: "¿Ha realizado otra operación corrigiendo esta?",
    question2: "¿Recibió o entregó dinero en esta operación?",
    question3: "¿El cliente se ha llevado el ticket de la operación?",
    questionValueNewTx: "Valor de la nueva operación realizada",
    questionValFromCust: "Valor entregado por el cliente",
    questionValToUser: "Valor recibido por el corresponsal",
    descTitle: "Observaciones",
    descExplain: "Por favor, seleccione el motivo de la solicitud del extorno.",
    descExplainOb: "Justifique el motivo de la solicitud, escríbalo con sus propias palabras.",
    phoneNumber: 'Por favor, introduzca un número de teléfono para contactar en caso de dudas sobre el motivo del extorno.',
    finishReversion: "Cuando haya completado todas las preguntas, pulse el botón para solicitar el extorno de la transacción.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde." //Este mensaje es utilizado por las reversiones. debe ser el msmo en cada transaccion y validarse para llamar a clearData en la impresora
  };

  operations.getTxType = (type) => {
    switch (type) {
      case '1':
        return "Depósito";
      case '2':
        return "Pago de Cuota";
      case '3':
        return "Registro de Referidos";
      case '4':
        return "Retiro";
      case '5':
        return "Solicitud de crédito";
      default:
        return "Desconocido";
    }
  };

  operations.getReversionStateIcon = (type) => {
    switch (type) {
      case '3':
      case '6':
        return "ion-android-warning";
      case '7':
        return "ion-android-done";
      case '5':
      case '8':
        return "ion-android-close";
      default:
        return "";
    }
  };

  operations.getReversionStateLabel = (type) => {
    switch (type) {
      case '3':
      case '6':
        return "Solicitada";
      case '4':
        return 'Automática';
      case '7':
        return "Aceptada";
      case '5':
      case '8':
        return "Rechazada";
      default:
        return "";
    }
  };

  operations.doSearch = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    operations.data.showPortraitFilter = false;
    var udid = "86361b9cf75b7182";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }

    operations.data.operations = [];
    operations.data.operationsShowed = [];

    swagger.api.corresponsales.transacciones.get.call({
      udid: udid,
      tipoTX: operations.data.transactionType.id,
      fechaInicio: $filter('date')(operations.data.fIni, 'yyyy/MM/dd'),
      fechaFin: $filter('date')(operations.data.fEnd, 'yyyy/MM/dd'),
    }).then((data) => {
      $ionicLoading.hide();
      operations.data.operations = data.data;
      operations.data.operationsShowed = operations.data.operations.slice(0, 50);
    }).catch((err) => {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Transacciones',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
          {
            name: "operacion",
            value: JSON.stringify({
              udid: udid,
              tipoTX: operations.data.transactionType.id,
              fechaInicio: $filter('date')(operations.data.fIni, 'yyyy/MM/dd'),
              fechaFin: $filter('date')(operations.data.fEnd, 'yyyy/MM/dd'),
            })
          }]
      });
      if (!err.data) {
        var alertPopup = $ionicPopup.alert({
          title: operations.texts.info,
          template: operations.texts.err004,
          okText: operations.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
        operations.doNavigate('menu.homeUser');
        return false;
      } else {
        if (!err.data.message) {
          err.data = {message: operations.texts.err004};
        }
        var alertPopup = $ionicPopup.alert({
          title: operations.texts.info,
          template: err.data.message,
          okText: operations.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
        operations.doNavigate('menu.homeUser');
        return false;
      }
    });
  };
  
  operations.showTransaccion = () => {
    operations.data.showPortraitFilter = false;
    var alertPopup = $ionicPopup.alert({
      title: 'Información',
      template: 'Transacción realizada satisfactoriamente',
    });
    operations.data.popup = alertPopup;
    alertPopup.then(() => {
      operations.data.popup = null;
    });
  };

  /**
   * @memberOf corresponsales.OperationsController
   * @name initLoad
   * @description función que realiza la carga inicial de la vista
   * @returns {undefined} la función emite el cambio de título
   */
  operations.initLoad = () => {
    $scope.$emit("titleChange", operations.texts.title);
    console.log('fromTransaction =>' , operations.data.fromTransaction);
    if (!!operations.data.fromTransaction) {
      console.log('entra');
      operations.showTransaccion();
    }
    operations.doSearch();
  };
  operations.initLoad();

  operations.loadMoreOperations = () => {
    setTimeout(() => {
      operations.data.operationsShowed = operations.data.operations.slice(0, operations.data.operationsShowed.length + 50);
      $scope.$broadcast('scroll.infiniteScrollComplete');
    }, 1000);
  };

  operations.continueInfinite = () => {
    if (operations.data.operationsShowed.length == operations.data.operations.length) {
      return false;
    }
    return true;
  };

  operations.scrollBottom = () =>{
    operations.data.scrollBottom = operations.data.directiveScrollBottom;
  };

  $scope.$on("$ionicSlides.sliderInitialized", function(event, data){
    operations.data.scrollBottom = (!!data.slider.slides.find('.content-revertion')[0])
      ? (data.slider.slides.find('.content-revertion')[0].scrollHeight > data.slider.slides.find('.content-revertion')[0].offsetHeight ? true : false)
      : 'false';
  });

  operations.showDetail = (item) => {
    operations.data.phoneNumber =  JSON.parse(localStorage.getItem('bm-configuracion')).cabecera.telefono;
    operations.data.showedItem = item;

    if (!!item.solicitudReversion.idSolicitudRev) {
      $scope.openOperationDetailModal();
      return false;
    }
    var template = '<h3>Detalle de la transacción</h3>' +
      '<h4>' + $filter('date')(operations.data.showedItem.fechaTx, "dd/MM/yyyy") + '</h4>' +
      '<br/>' +
      '<div class="row"><div class="col col-50">Titular:</div><div class="col col-50">' + (!!operations.data.showedItem.titular ? operations.data.showedItem.titular : "") + '</div></div>' +
      '<div class="row"><div class="col col-50">Cuenta:</div><div class="col col-50">' + (!!operations.data.showedItem.numCta ? operations.data.showedItem.numCta : "") + '</div></div>' +
      '<div class="row"><div class="col col-50">Documento:</div><div class="col col-50">' + (!!operations.data.showedItem.numDoc ? operations.data.showedItem.numDoc : '-') + '</div></div>' +
      '<div class="row"><div class="col col-50">Tipo de transacción:</div><div class="col col-50">' + operations.getTxType(operations.data.showedItem.tipoTX) + '</div></div>' +
      '<div class="row"><div class="col col-50">Monto:</div><div class="col col-50">S/ {{ ' + operations.data.showedItem.monto + ' | number:2 }}</div></div>' +
      '<div class="row"><div class="col col-50">Costo de la transacción:</div><div class="col col-50">S/ {{ ' +operations.data.showedItem.costoTx + ' | number:2 }}</div></div>' +
      '<div class="row"><div class="col col-50">Código de respuesta:</div><div class="col col-50">' + operations.data.showedItem.rpta + '</div></div>';

    var cssClasses = 'popup-big ' + ((!!operations.getReversionStateLabel(item.estadoTx) || (item.estadoTx + "" == "1") || (item.estadoTx + "" == "2") || (item.tipoTX + "" == "3") || (item.tipoTX + "" == '5')) ? 'no-ok-btn' : '');
    var alertPopup = $ionicPopup.confirm({
      cssClass: cssClasses,
      template: template,
      okText: operations.texts.continue,
      cancelText: operations.texts.cancel,
    });
    alertPopup.then((e) => {
      if (!!e) {
        $scope.openOperationReversionModal();
        operations.data.reversionItem = item;
      } else {
        operations.data.reversionItem = {};
      }
    });
  };

  /**
   * @memberOf corresponsales.OperationsController
   * @name doNavigate
   * @param {type} path ruta de destino de la navegacion
   * @description función que centraliza las navegaciones de la vista
   */
  operations.doNavigate = (path) => {
    $state.go(path);
  };

  operations.clearReversionPanel = () => {
    operations.data.reversionItem = {};
    operations.data.reversionData = {
      q1: false,
      q1Value: null,
      q2: false,
      q2Value1: null,
      q2Value2: null,
      q3: false,
      desc: ""
    };
    operations.data.observationType = { label: "", id: ""};
  };

  operations.sendMessage = (tx) => {
    var alertPopup = $ionicPopup.confirm({
      title: "Información",
      template: "¿Quiere enviar un mensaje por chat con el asunto de este caso?",
      okText: "Si",
      cancelText: "Cancelar",
    });
    alertPopup.then((e) => {
      if (!!e) {
        $scope.closeModal();
        localStorage.setItem("BM-messages-tx", JSON.stringify(tx));
        $state.go('menu.messages');
      }
    });
  };

  operations.doReversion = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }

    if(operations.data.observationType.label === '' || !operations.data.reversionData.desc){
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: operations.texts.info,
        template: operations.texts.observationSelect,
        okText: operations.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    }
    swagger.api.corresponsales.solicitarReversion.post.call({
      reversionBody: {
        udid: udid,
        numTx: operations.data.reversionItem.numTx,
        corregido: operations.data.reversionData.q1,
        plata: operations.data.reversionData.q2,
        ticket: operations.data.reversionData.q3,
        observaciones: operations.data.reversionData.desc,
        telefono: operations.data.phoneNumber,
        motivoReversion: operations.data.observationType.label,
        valorNuevaTx: operations.data.reversionData.q1Value,
        valorEntregadoPorCliente: operations.data.reversionData.q2Value1,
        valorRecibidoPorCorresponsal: operations.data.reversionData.q2Value2,
      }
    }).then((data) => {
      $ionicLoading.hide();
      $scope.closeModal();
      var alertPopup = $ionicPopup.alert({
        title: operations.texts.info,
        template: operations.texts.reversionOk + data.data.idSolicitudRev,
        okText: operations.texts.ok,
      });
      alertPopup.then(() => {
        operations.doSearch();
        return false;
      });
    }).catch((err) => {
      $ionicLoading.hide();
      $scope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Solicitud reversion',
        data: [{
          name: "err",
          value: JSON.stringify(err)
        },
          {
            name: "operacion",
            value: JSON.stringify({
              reversionBody: {
                udid: udid,
                numTx: operations.data.reversionItem.numTx,
                corregido: operations.data.reversionData.q1,
                plata: operations.data.reversionData.q2,
                ticket: operations.data.reversionData.q3,
                observaciones: operations.data.reversionData.desc,
                telefono: operations.data.phoneNumber,
                motivoReversion: operations.data.observationType.label,
                valorNuevaTx: operations.data.reversionData.q1Value,
                valorEntregadoPorCliente: operations.data.reversionData.q2Value1,
                valorRecibidoPorCorresponsal: operations.data.reversionData.q2Value2,
              }
            })
          }]
      });
      $scope.closeModal();
      if (!err.data) {
        var alertPopup = $ionicPopup.alert({
          title: operations.texts.info,
          template: operations.texts.err004,
          okText: operations.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
        operations.doNavigate('menu.homeUser');
        return false;
      } else {
        if (!err.data.message) {
          err.data = {message: operations.texts.err004};
        }
        var alertPopup = $ionicPopup.alert({
          title: operations.texts.info,
          template: err.data.message,
          okText: operations.texts.ok,
        });
        alertPopup.then(() => {
          return false;
        });
        return false;
      }
    });
  };

  $scope.openOperationDetailModal = function() {
    $ionicModal.fromTemplateUrl('views/user/operations/modalDetails.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
      $scope.modal.show();
    });
  };

  $scope.openOperationReversionModal = function() {
    $ionicModal.fromTemplateUrl('views/user/operations/modalReversion.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
      $scope.modal.show();
    });
  };

  $scope.closeModal = function() {
    $document.find('body').removeClass('modal-open');
    $scope.modal.remove();
    operations.clearReversionPanel();
  };

  $scope.$on('$destroy', function() {
    if(!!$scope.modal){
      $scope.modal.remove();
    }
  });
}

export default OperationsController;
