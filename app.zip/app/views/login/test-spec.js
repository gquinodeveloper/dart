import LoginModule from './index';
import AuthModule from '../../../node_modules/@atmira/fm-auth/index';

describe('app/views/login/test-spec.js', function () {
  beforeEach(angular.mock.module(LoginModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicLoading = $injector.get('$ionicLoading');
    this.$http = $injector.get('$http');
    this.$window = $injector.get('$window');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;

    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('LoginController', {'$scope': this.$scope,
        menuActive: {
          active: 1
        },
        'reversionService' : {
          setReversionData: function({}){return true;},
          clearReversionData: function(){return true;},
          doReversion: function(){return true;}
        },
        'dukptService':{
          encryptForKey:function(){return true;}
        },
        'swagger': {
          api: {
            corresponsales: {
              reversionOperacion: {
                post: {
                  call: function () {return $q.when()}
                }
              },
              configuracion: {
                get: {
                  call: function () {return $q.when()}
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn(this.authFactory, 'getClientId').and.callFake(function (state, params) {
      return 'demo';
    });
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Login Controller', function () {
    it('checkConnection defined', function () {
      var LoginController = this.createController();
      expect(LoginController.checkConnection).toBeDefined();
    });
    it('checkConnection run', function () {
      var LoginController = this.createController();
      LoginController.checkConnection();
    });
    it('initLoad defined', function () {
      var LoginController = this.createController();
      expect(LoginController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var LoginController = this.createController();
      LoginController.initLoad();
    });
    it('doReverseTx defined', function () {
      var LoginController = this.createController();
      expect(LoginController.doReverseTx).toBeDefined();
    });
    it('doReverseTx run', function () {
      var LoginController = this.createController();
      localStorage.setItem("bm-persistent-tx-data",
        JSON.stringify({
          cuenta: {
            id: 1
          },
          monto: 1
        })
      )      
      LoginController.doReverseTx();
    });
    it('getConfiguration defined', function () {
      var LoginController = this.createController();
      expect(LoginController.getConfiguration).toBeDefined();
    });
    it('getConfiguration run', function () {
      var LoginController = this.createController();
      LoginController.getConfiguration();
    });
    it('makeMask defined', function () {
      var LoginController = this.createController();
      expect(LoginController.makeMask).toBeDefined();
    });
    it('makeMask with 3 characters', function () {
      var LoginController = this.createController();
      expect(LoginController.makeMask(3)).toBe("***");
    });
    it('getPersistedUser defined', function () {
      var LoginController = this.createController();
      expect(LoginController.getPersistedUser).toBeDefined();
    });
    it('getPersistedUser without user', function () {
      var LoginController = this.createController();
      LoginController.getPersistedUser();
    });
    it('getPersistedUser with user', function () {
      var LoginController = this.createController();
      localStorage.setItem("persistUser", "usuario")
      LoginController.getPersistedUser();
    });
    it('isPersisted defined', function () {
      var LoginController = this.createController();
      expect(LoginController.isPersisted).toBeDefined();
    });
    it('isPersisted without user', function () {
      var LoginController = this.createController();
      localStorage.removeItem("persistUser")
      expect(LoginController.isPersisted()).toBeFalsy();
    });
    it('isPersisted with user', function () {
      var LoginController = this.createController();
      localStorage.setItem("persistUser", "usuario")
      expect(LoginController.isPersisted()).toBeTruthy();
    });
    it('cancelPersist defined', function () {
      var LoginController = this.createController();
      expect(LoginController.cancelPersist).toBeDefined();
    });
    it('cancelPersist remove persisted user', function () {
      var LoginController = this.createController();
      LoginController.cancelPersist();
    });
    it('doLogin defined', function () {
      var LoginController = this.createController();
      expect(LoginController.doLogin).toBeDefined();
    });
    it('doLogin execution without data', function () {
      var LoginController = this.createController();
      LoginController.doLogin();
    });
    it('doLogin execution with data', function () {
      var LoginController = this.createController();
      LoginController.data.user = "user"
      LoginController.data.pass = "pass"
      LoginController.doLogin();
    });
    it('doChange defined', function () {
      var LoginController = this.createController();
      expect(LoginController.doChange).toBeDefined();
    });
    it('doChange run', function () {
      var LoginController = this.createController();
      LoginController.doChange();
    });
  });
});