routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
            .state('login', {
                url: '/login',
                controller: 'LoginController',
                controllerAs: 'login',
                templateUrl: 'views/login/template.html'
            });
}

export default routing;
