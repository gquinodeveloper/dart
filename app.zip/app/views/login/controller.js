/**
 * Controlador de la vista de login
 */

LoginController.$inject = ['$ionicLoading', '$ionicPopup', 'authFactory', '$http', '$state', '$window', '$rootScope', 'swagger', 'reversionService', 'menuActive', 'dukptService', '$scope', 'privateIpService', 'cacher'];

/**
 * @class corresponsales.login
 * @memberOf corresponsales
 * @desc vista de login
 * Controlador de la vista de login
 * @param $ionicPopup dependency dependencia para el uso de los popups emergentes en la vista de login
 * @param authFactory dependencia para la autentificación oauth 
 * @param $http dependencia para el acceso http a servicio
 * @param $window acceso angular al objeto window
 * @param $ionicLoading para la gestión del spiner de loading
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param $state dependencia del objeto angular para la realización de navegación
 */
function LoginController($ionicLoading, $ionicPopup, authFactory, $http, $state, $window, $rootScope, swagger, reversionService, menuActive, dukptService, $scope, privateIpService, cacher) {
  let login = this;

  login.data = {
    user: "",
    maskedUser: "",
    pass: "",
    popup: null,
    udid: "--------------",
    serial: "--------------",
    ksn: "",
    version: "1.0.3",
    bg1: false,
    bg1Img: 0,
    bg2Img: 0,
  };

  login.data.udid = "86361b9cf75b7182";
  login.data.serial = "4709459B65C87EBD";

  login.texts = {
    user: "Usuario",
    pass: "clave",
    cancelPersist: "Cambiar de usuario",
    login: "Ingresar >",
    info: "Información",
    ok: "Aceptar",
    err001: "Es necesario introducir Usuario y clave",
    err002: "Error en el login, por favor, verifique sus credenciales.",
    err003: "No tiene conexión a la red.",
    err004: "Se ha producido un error en la conexión. Por favor, vuelva a acceder pasados unos minutos.",
    err005: "Se ha producido un error en el proceso de actualización de su aplicación. Por favor, contacte con su oficina.",
    changePass: "Olvido de clave"
  };

  /**
   * @memberOf corresponsales.login
   * @name checkConnection
   * @type function
   * @description función que valida el acceso a red
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  login.checkConnection = () => {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  };
  
  login.rotateBg = () => {
    setTimeout(() => {
      login.data.bg1 = !login.data.bg1;
      setTimeout(() => {
        if(!!login.data.bg1){
          login.data.bg2Img = login.data.bg1Img -(-1);
          if(login.data.bg2Img>4){
            login.data.bg2Img = 1;
          }
        } else {
          login.data.bg1Img = login.data.bg2Img -(-1);
          if(login.data.bg1Img>4){
            login.data.bg1Img = 1;
          }
        }
      },4000);   
      $scope.$apply();
      login.rotateBg();
    },10000);
  };

  login.serial = () => {
    try {
      if (device != undefined) {
        let version = device.version;
        let versionNumber = 0;
        let versionSplit = version.split(".");

        if(versionSplit.length > 0){
          versionNumber = Number(versionSplit[0]);
        } else {
          versionNumber = Number(device.version);
        }

        if (versionNumber < 10) {
          login.data.serial = device.serial;// eslint-disable-line
        } else {
          login.generarSerial();
        }

        if(login.data.serial.trim().toUpperCase() == 'UNKNOWN' || login.data.serial == null || login.data.serial == '') {
          login.generarSerial();
        }
      }
    } catch (e) {
      //intentional
    }
  };

  login.generarSerial = () => {
    //Generar Hash del udid para Android 10
    let CryptoJS = require("crypto-js/crypto-js");
    let keySerial = require('../../configuration/default-config.json').keySerial;
    let serialSHA = CryptoJS.SHA256(keySerial + device.uuid + "").toString(CryptoJS.enc.Hex);
    login.data.serial = serialSHA.toString().substr(0, 16).toUpperCase();
  };

  login.initLoad = () => {
    setTimeout(() => {
      // login.rotateBg(); //Slider Images
      try {
        if (device != undefined) {
          login.data.udid = device.uuid;// eslint-disable-line
          login.serial();

          console.log(login.data.udid);
        }
      } catch (e) {
        //intentional
      }
    }, 1000);
    
  };
  login.initLoad();

  login.doReverseTx = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner><h4>Se está realizando un proceso interno.<br/> Por favor, espere...</h4>',
      hideOnStateChange: true
    });
    var reverseTxData = JSON.parse(localStorage.getItem("bm-persistent-tx-data"));
    var idTx = localStorage.getItem("bm-tx-id");
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.reversionOperacion.post.call({
      operacionARevertirDTO: {
        udid: "86361b9cf75b7182",//udid,
        id: (reverseTxData.cuenta ? reverseTxData.cuenta.id : reverseTxData.obligacion.id) + "",
        idTx: idTx + "",
        monto: reverseTxData.monto
      }
    }).then(() => {
      $ionicLoading.hide();
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      reversionService.clearReversionData();
      login.getConfiguration();
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Login - Reversion operacion',
        data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
      });
      if (err.data.code + "" == "400") {
        $ionicLoading.show({
          template: '<ion-spinner icon="ripple"></ion-spinner>',
          hideOnStateChange: true
        });
        reversionService.clearReversionData();
        login.getConfiguration();
      } else {
        var alertPopup = $ionicPopup.alert({
          title: login.texts.info,
          template: login.texts.err004,
          okText: login.texts.ok,
        });
        login.data.popup = alertPopup;
        alertPopup.then(() => {
          login.data.popup = null;
          localStorage.removeItem('ngStorage-accessToken');
          localStorage.removeItem('bm-configuracion');
          localStorage.removeItem('bm-transaction-data');
        });
      }

    });
  };

  login.doAudit = (success) => {
    let udid ="";
    let username = localStorage.getItem('persistUser');
    privateIpService.getPrivateIp(function(ip){
      let ipDispositivo = null;
      if(ip.length > 0){
        ipDispositivo= ip[0];
      } else {
        ipDispositivo = '0.0.0.0';
      }
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.loginApp.put.call({
        udid: "86361b9cf75b7182",//udid,
        success: success,
        userName: username,
        ipDispositivo: ipDispositivo,
      });
    });
  };

  login.getConfiguration = () => {
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
        login.data.udid =  device.uuid;// eslint-disable-line
        login.serial();
      }
    } catch (e) {
      //intentional
    }

    if (!localStorage.getItem('bm-key-ksn')) {
      var udidKSN = "11111111111111111111111";
      try {
        if (device != undefined) {// eslint-disable-line
          udidKSN = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      if (udid.length > 10) {
        udidKSN = udid.substring(0, 10);
      }
      while (udidKSN.length < 10) {
        udidKSN = "F" + udidKSN;
      }
      login.data.ksn = udidKSN + "E00000";
      console.log(login.data.ksn);
      localStorage.setItem('bm-key-ksn', dukptService.encryptForKey(login.data.ksn));
    }

    swagger.api.corresponsales.configuracion.get.call({
      udid: "86361b9cf75b7182"//udid
    }).then((data) => {
      $ionicLoading.hide();
      if (!!data.data.bloqueoLlavesTerminal) {
        localStorage.removeItem("bm-key-bdk");
        localStorage.removeItem("bm-key-ipek");
        localStorage.removeItem("bm-key-ksn");
        swagger.api.corresponsales.llavesBorradas.put.call({
          udid: "86361b9cf75b7182"//udid
        }).then((data) => {
          $rootScope.$emit('metrics-custom', {
            event: 'Borrado de llaves',
            tag: 'Borrado de llaves',
            data: [{
                name: "msg",
                value: 'Queda confirmado en servidor el borrado de las llaves.'
              }]
          });
        }).catch((err) => {
          $rootScope.$emit('metrics-custom', {
            event: 'Borrado de llaves',
            tag: 'Borrado de llaves',
            data: [{
                name: "err",
                value: JSON.stringify(err)
              }]
          });
        });

        $rootScope.$emit('metrics-custom', {
          event: 'Borrado de llaves',
          tag: 'Borrado de llaves',
          data: [{
              name: "msg",
              value: 'Borrado de llaves por peticion desde el servidor.'
            }]
        });
        var alertPopup = $ionicPopup.alert({
          title: login.texts.info,
          template: login.texts.err005,
          okText: login.texts.ok,
        });
        login.data.popup = alertPopup;
        alertPopup.then(() => {
          login.data.popup = null;
        });
        return false;
      }
      localStorage.setItem('bm-configuracion', JSON.stringify(data.data));
      $state.go("menu.homeCustomer");
    }).catch((err) => {
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Login - Configuracion',
        data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
      });
      if (err.data.code == "403") {
        $state.go("setQuest");
        return false;
      }
      $ionicLoading.hide();
      if(err.status == 400 || err.status == 401){
        var alertPopup = $ionicPopup.alert({
          title: login.texts.info,
          template: err.data.message,
          okText: login.texts.ok,
        });
      } else {
        var alertPopup = $ionicPopup.alert({
          title: login.texts.info,
          template: login.texts.err002,
          okText: login.texts.ok,
        });
      }
      login.data.popup = alertPopup;
      alertPopup.then(() => {
        login.data.popup = null;
      });
    });
  };

  /**
   * @memberOf corresponsales.login
   * @name makeMask
   * @description función que realiza una cadena de asteriscos según una longitud dada
   * @param number num número de asteríscos en la cadena
   * @returns {String} cadena de asteríscos
   */
  login.makeMask = (num) => {
    var chain = "";
    for (let i = 0; i < num; i++) {
      chain = chain + '*';
    }
    return chain;
  };

  /**
   * @memberOf corresponsales.login
   * @name getPersistedUser
   * @description function que obtiene el usuario del almacenamiento local
   */
  login.getPersistedUser = () => {
    let user = localStorage.getItem('persistUser');
    if (!!user) {
      let chars = 3;
      let chain = login.makeMask(user.length - chars);
      login.data.maskedUser = chain + user.substring(user.length - chars);
      login.data.user = user;
    }
  };

  /**
   * @memberOf corresponsales.login
   * @name isPersisted
   * @description función que determina si hay usuario persistido o no en el almacenamiento local
   * @returns {Boolean} true si hay usuario persistido, false si no
   */
  login.isPersisted = () => {
    let user = localStorage.getItem('persistUser');
    if (!!user) {
      login.getPersistedUser();
      return true;
    } else {
      return false;
    }
  };

  /**
   * @memberOf corresponsales.login
   * @name cancelPersist
   * @description funcion que elimina el usuario persistido del alamcenamiento local, resetea los datos del scope y lanza la funcion login.isPersisted() para resetear la vista
   */
  login.cancelPersist = () => {
    localStorage.removeItem('persistUser');
    login.data.maskedUser = '';
    login.data.user = '';
    login.data.pass = '';
    login.isPersisted();
  };


  /**
   * @memberOf corresponsales.login
   * @name doLogin
   * @type function
   * @description función que tras validar los campos, realiza el proceso de login contra el servidor y de ser este correcto, realiza la navegación a la home del perfil
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  login.doLogin = () => {
    console.log("click!");
    menuActive.active = 1;
    if (!!login.data.user && !!login.data.pass) {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });

      let formdata = new FormData();

      formdata.append('username', login.data.user);
      formdata.append('password', login.data.pass);
      formdata.append('grant_type', 'password');
      formdata.append('client_id', authFactory.getClientId());

      if (!login.checkConnection()) {
        $ionicLoading.hide();
        if (login.data.popup) {
          login.data.popup.close();
          login.data.popup = null;
          return false;
        }
        alertPopup = $ionicPopup.alert({
          title: login.texts.info,
          template: login.texts.err003,
          okText: login.texts.ok,
        });
        login.data.popup = alertPopup;
        alertPopup.then(() => {
          login.data.popup = null;
          return false;
        });
        return false;
      }

      let loginData = require('../../configuration/default-config.json').auth.accessTokenServer;
      localStorage.setItem('persistUser', login.data.user);
      $http({
        method: loginData.method,
        url: loginData.url,
        data: formdata,
        headers: {
          authorization: 'Basic ' + $window.btoa('demo' + ':' + 'secret_demo'),
          'content-type': undefined
        }
      }).then(success => {
        login.doAudit(true);
        login.output = success;
        authFactory.refreshToken(success.data.refresh_token);
        authFactory.accessToken(success.data.access_token);
        localStorage.setItem('logAcces', success.data.access_token);
        cacher.set('userId', login.data.user, true);
        if (login.data.popup) {
          login.data.popup.close();
          login.data.popup = null;
          return false;
        }
        var reverseTxData = JSON.parse(localStorage.getItem("bm-persistent-tx-data"));
        if (!reverseTxData) {
          $ionicLoading.show({
            template: '<ion-spinner icon="ripple"></ion-spinner>',
            hideOnStateChange: true
          });          
          login.getConfiguration();
        } else {
          login.doReverseTx();
        }
      }).catch((err) => {
        login.doAudit(false);
        localStorage.removeItem('persistUser');
        login.output = err;
        $ionicLoading.hide();
        if (login.data.popup) {
          login.data.popup.close();
          login.data.popup = null;
          return false;
        }

        if(!!err.data){
          if (err.data.error == 'invalid_grant') {
            var alertPopup = $ionicPopup.alert({
              title: login.texts.info,
              template: login.texts.err002,
              okText: login.texts.ok,
            });
            login.data.popup = alertPopup;
            alertPopup.then(() => {
              login.data.popup = null;
            });
          } else {
            if (login.data.popup) {
              login.data.popup.close();
              login.data.popup = null;
              return false;
            }
            alertPopup = $ionicPopup.alert({
              title: login.texts.info,
              template: login.texts.err002,
              okText: login.texts.ok,
            });
            login.data.popup = alertPopup;
            alertPopup.then(() => {
              login.data.popup = null;
            });
          }
        } else {
          if (login.data.popup) {
            login.data.popup.close();
            login.data.popup = null;
            return false;
          }
          alertPopup = $ionicPopup.alert({
            title: login.texts.info,
            template: login.texts.err003,
            okText: login.texts.ok,
          });
          login.data.popup = alertPopup;
          alertPopup.then(() => {
            login.data.popup = null;
          });
        }
      });
    } else {
      $ionicLoading.hide();
      if (login.data.popup) {
        login.data.popup.close();
        login.data.popup = null;
        return false;
      }
      var alertPopup = $ionicPopup.alert({
        title: login.texts.info,
        template: login.texts.err001,
        okText: login.texts.ok,
      });
      login.data.popup = alertPopup;
      alertPopup.then(() => {
        login.data.popup = null;
      });
    }
  };

  login.doChange = () => {
    $state.go('changeValidate');
  };

  login.openPdf = () =>{

    var permissions = cordova.plugins.permissions;
    permissions.checkPermission(permissions.READ_EXTERNAL_STORAGE, function(status) {
      if (!status.hasPermission) {
        permissions.requestPermission(
          permissions.READ_EXTERNAL_STORAGE,
          function(statusperm) {
            if(statusperm.hasPermission) {
              let url = 'www/public/docs/Manual-Operativo-Corresponsales-Bancarios.pdf';
              window.resolveLocalFileSystemURL(cordova.file.applicationDirectory +  url, function(fileEntry) {
                window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function(dirEntry) {
                  fileEntry.copyTo(dirEntry, url.split('/').pop(), function(newFileEntry) {
                    window.open(newFileEntry.nativeURL, '_system');
                  }, function(err){
                    console.log('fileEntry.copyTo error', err);
                  });
                }, function(err) {
                  console.log('resolveLocalFileSystemURL error', err);
                });
              }, function(err) {
                console.log('resolveLocalFileSystemURL error', err);
              });
            }
          },
          function(errorpermisos) {
            console.log("Error al obtener permiso al storage " + errorpermisos);
          }
        );
      } else {
        let url = 'www/public/docs/Manual-Operativo-Corresponsales-Bancarios.pdf';
        window.resolveLocalFileSystemURL(cordova.file.applicationDirectory +  url, function(fileEntry) {
          window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function(dirEntry) {
            fileEntry.copyTo(dirEntry, url.split('/').pop(), function(newFileEntry) {
              window.open(newFileEntry.nativeURL, '_system');
            }, function(err){
              console.log('fileEntry.copyTo error', err);
            });
          }, function(err) {
            console.log('resolveLocalFileSystemURL error', err);
          });
        }, function(err) {
          console.log('resolveLocalFileSystemURL error', err);
        });
      }
    }, null);
  };
}

export default LoginController;
