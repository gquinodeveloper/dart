import controller from './controller';
import routing from './routing';


export default angular.module('LoginModule', [
  'ui.router',
  'ionic'
])
  .controller('LoginController', controller)
  .config(routing)
  .name;