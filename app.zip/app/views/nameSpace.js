/**
 * @namespace corresponsales
 * @description corresponsales: Documentación.
 */


