routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

  $stateProvider
          .state('menu', {
            url: '/menu',
            abstract: true,
            controller: 'MenuController',
            controllerAs: 'menu',
            templateUrl: 'views/menu/template.html'
          });
}

export default routing;