import MenuModule from './index';
import AuthModule from '../../../node_modules/@atmira/fm-auth/index';
//import menuActive from '../../configuration/activeMenu';
describe('app/views/menu/test-spec.js', function () {
  beforeEach(angular.mock.module(MenuModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

//  beforeEach(angular.mock.module(menuActive));

  // antes de cada test instanciamos nuestro controlador y
  // todas las dependencias que necesitemos.


  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.$ionicPopup = $injector.get('$ionicPopup');
    this.$q = $injector.get('$q');
    var $q = this.$q

    // preparo la funcion para instanciar el controlador
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('MenuController', {'$scope': this.$scope, 'menuActive': {active: 1},
        msjService: {
          props: {
            current: 0,
            last: 0
          }
        },
        swagger: {
          api:{
            corresponsales: {
              mensajesNoLeidos:{
                get:{
                  call: function(){
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($injector) {
    this.$q = $injector.get('$q');
    var $q = this.$q;
    spyOn(this.authFactory, 'getClientId').and.callFake(function (state, params) {
      return 'demo';
    });
    spyOn(this.authFactory, 'logout').and.callFake(function (state, params) {
      return $q.when();
    });
    localStorage.setItem('bm-configuracion', JSON.stringify({cabecera: {nombre: 'corresponsal'}}))
  }));
  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('Menu Controller', function () {
    it('setActive defined', function () {
      var MenuController = this.createController();
      expect(MenuController.setActive).toBeDefined();
    });
    it('setActive menu active 4', function () {
      var MenuController = this.createController();
      MenuController.setActive(4);
    });
    it('isActive defined', function () {
      var MenuController = this.createController();
      expect(MenuController.isActive).toBeDefined();
    });
    it('isActive menu active 4', function () {
      var MenuController = this.createController();
      MenuController.setActive(4);
      expect(MenuController.isActive(4)).toBeTruthy()
    });
    it('doNavigate defined', function () {
      var MenuController = this.createController();
      expect(MenuController.doNavigate).toBeDefined();
    });
    it('doNavigate execution', function () {
      var MenuController = this.createController();
      MenuController.doNavigate('...');
    });
    it('initLoad defined', function () {
      var MenuController = this.createController();
      expect(MenuController.initLoad).toBeDefined();
    });
    it('initLoad execution', function () {
      var MenuController = this.createController();
      MenuController.initLoad();
    });
    it('doLogout defined', function () {
      var MenuController = this.createController();
      expect(MenuController.doLogout).toBeDefined();
    });
    it('doLogout execution', function () {
      var MenuController = this.createController();
      MenuController.doLogout();
    });
    it('startTimer defined', function () {
      var MenuController = this.createController();
      expect(MenuController.startTimer).toBeDefined();
    });
    it('startTimer run', function () {
      var MenuController = this.createController();
      MenuController.startTimer();
    });
    it('resetTimer defined', function () {
      var MenuController = this.createController();
      expect(MenuController.resetTimer).toBeDefined();
    });
    it('resetTimer run', function () {
      var MenuController = this.createController();
      MenuController.resetTimer();
    });
    it('idleSetup defined', function () {
      var MenuController = this.createController();
      expect(MenuController.idleSetup).toBeDefined();
    });
    it('idleSetup run', function () {
      var MenuController = this.createController();
      MenuController.idleSetup();
    });
    it('goInactive defined', function () {
      var MenuController = this.createController();
      expect(MenuController.goInactive).toBeDefined();
    });
    it('goInactive run', function () {
      var MenuController = this.createController();
      MenuController.goInactive();
    });
  });
});
