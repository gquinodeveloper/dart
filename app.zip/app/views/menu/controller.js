MenuController.$inject = ['menuActive', '$state', 'authFactory', '$ionicPopup', '$scope', '$timeout', '$window', 'msjService', 'swagger', '$rootScope'];

function MenuController(menuActive, $state, authFactory, $ionicPopup, $scope, $timeout, $window, msjService, swagger, $rootScope) {
  let menu = this;

  menu.data = {
    active: menuActive.active,
    msjNumber: msjService.props.current,
    msjLast: msjService.props.last,
    corresponsal: "",
    idle: null,
    idleTime: 900000, //milisegundos
    msjRefreshTime: 60000,
  };

  menu.texts = {
    logOut: "Cerrar sesión",
    logOutConfirm: "¿Está seguro de cerrar la sesión?",
    title: "Seleccionar Operación",
    ok: "Aceptar",
    cancel: "Cancelar"
  };

  menu.msjRefresh = () => {
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.mensajesNoLeidos.get.call({
      udid: "86361b9cf75b7182" //udid
    }).then((data) => {
      msjService.setNumber(data.data.noLeidos);
      menu.data.msjNumber = msjService.props.current;
      menu.data.msjLast = msjService.props.last;
      if (menu.data.msjNumber != menu.data.msjLast) {
        $scope.$broadcast("newMsjArrive", "");
      }
      if (!!menu.continueRefreshing()) {
        setTimeout(menu.msjRefresh, menu.data.msjRefreshTime);
      }
    }).catch((err) => {
      if (!!menu.continueRefreshing()) {
        setTimeout(menu.msjRefresh, menu.data.msjRefreshTime);
      }
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Menu - mensajes no leidos',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
    });
  };

  menu.continueRefreshing = () => {
    return ($state.current.name.indexOf("menu") != -1);
  };

  /**
   * @memberOf corresponsales.menu
   * @name setActive
   * @description función que establece el elemento activo en el factory
   * @param {integer} num numero del elemento a establcer como activo
   * @returns {undefined}
   */
  menu.setActive = (num) => {
    menuActive.active = num;
    menu.data.active = num;
    switch (num) {
      case 1:
        $state.go('menu.homeCustomer');
        break;
      case 2:
        $state.go('menu.homeUser');
        break;
      case 3:
        $state.go('menu.newPassword');
        break;
    }
  };

  /**
   * @memberOf corresponsales.menu
   * @name isActive
   * @description función que valida para cada elemento del menú cua está activo en ese momento y cual no
   * @param {integer} num posición del elemento a validar
   * @returns {Boolean} true si es el elemento activo almacenado en el factory, false en cualquer otro caso
   */
  menu.isActive = (num) => {
    if (num == menuActive.active) {
      return true;
    }
    return false;
  };

  /**
   * @memberOf corresponsales.menu
   * @name doNavigate
   * @type function
   * @description función que engloba las navegaciones realizadas desde el menú.
   * @param {string} path ruta de la vista de destino
   */
  menu.doNavigate = (path) => {
    $state.go(path);
  };

  menu.initLoad = () => {
    var conf = JSON.parse(localStorage.getItem('bm-configuracion'));
    try {
      menu.data.corresponsal = conf.cabecera.nombre;
    } catch (e) {
      menu.doNavigate('login');
    }
    $scope.$on("titleChange", (event, data) => {
      menu.texts.title = data;
    });
    menu.msjRefresh();
  };
  menu.initLoad();

  menu.doLogout = () => {
    var alertPopup = $ionicPopup.confirm({
      title: menu.texts.logOut,
      template: menu.texts.logOutConfirm,
      okText: menu.texts.ok,
      cancelText: menu.texts.cancel,
    });

    alertPopup.then(function (res) {
      if (!!res) {
        authFactory.logout()
          .then((success) => {
            menu.output = success;
          })
          .catch(err => {
            menu.output = err;
          });

        localStorage.removeItem('ngStorage-accessToken');
        localStorage.removeItem('bm-configuracion');
        localStorage.removeItem('bm-transaction-data');
        menu.doNavigate('login');
      }
      return false;
    });
  };

  /**
   * @memberOf corresponsales.menu
   * @name startTimer
   * @type function
   * @description función englobada en la funcionalidad que controla el comportamiento "idle" del usuario. resetea el contador de tiempo que lleva el usuario su realizar ninguna acción sobre la app y comienza a contar de nuebo
   */
  menu.startTimer = function () {
    $timeout.cancel(menu.data.timeoutID);
    menu.data.timeoutID = $timeout(menu.goInactive, menu.data.idleTime);
  };

  /**
   * @memberOf corresponsales.menu
   * @name restTimer
   * @type function
   * @description función englobada en la funcionalidad que controla el comportamiento "idle" del usuario y resetea el contador de tiempo. llama a startTimer para volver a ponerlo en marcha
   * @returns {undefined}
   */
  menu.resetTimer = function () {
    $timeout.cancel(menu.data.timeoutID);
    menu.data.timeoutID = null;
    menu.startTimer();
  };

  /**
   * @memberOf corresponsales.menu
   * @name goInactive
   * @type function
   * @description función a invocar una vez al terminar el tiempo de "idle" del usuario. se realizará una llamada a doLogout
   */
  menu.goInactive = function () {
    authFactory.logout()
      .then((success) => {
        menu.output = success;
      })
      .catch(err => {
        menu.output = err;
      });

    localStorage.removeItem('ngStorage-accessToken');
    localStorage.removeItem('bm-configuracion');
    localStorage.removeItem('bm-transaction-data');
    menu.doNavigate('login');
  };

  /**
   * @memberOf corresponsales.menu
   * @name idleSetup
   * @type function
   * @description función a invocar al realizar el acceso a cualquier vista de menú. Se añaden a nivel de document los eventos para validar si el usuario está realizando acciones sobre la aplicación
   * @returns {undefined}
   */
  menu.idleSetup = function () {
    $window.document.addEventListener("mousemove", menu.resetTimer, false);
    $window.document.addEventListener("mousedown", menu.resetTimer, false);
    $window.document.addEventListener("keypress", menu.resetTimer, false);
    $window.document.addEventListener("DOMMouseScroll", menu.resetTimer, false);
    $window.document.addEventListener("mousewheel", menu.resetTimer, false);
    $window.document.addEventListener("touchmove", menu.resetTimer, false);
    $window.document.addEventListener("MSPointerMove", menu.resetTimer, false);
    menu.resetTimer();
    menu.startTimer();
  };
  menu.idleSetup();

  $scope.$on("$destroy",function( event ) {
    $window.document.removeEventListener("mousemove", menu.resetTimer, false);
    $window.document.removeEventListener("mousedown", menu.resetTimer, false);
    $window.document.removeEventListener("keypress", menu.resetTimer, false);
    $window.document.removeEventListener("DOMMouseScroll", menu.resetTimer, false);
    $window.document.removeEventListener("mousewheel", menu.resetTimer, false);
    $window.document.removeEventListener("touchmove", menu.resetTimer, false);
    $window.document.removeEventListener("MSPointerMove", menu.resetTimer, false);
    $timeout.cancel( menu.data.timeoutID );
    menu.data.timeoutID = null;
  });
}

export default MenuController;
