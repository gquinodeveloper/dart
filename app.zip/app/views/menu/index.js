import controller from './controller';
import routing from './routing';


export default angular.module('MenuModule', [
  'ui.router',
  'ionic'
])
  .controller('MenuController', controller)
  .config(routing)
  .name;