routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
            .state('changeValidate', {
                url: '/changeValidate',
                controller: 'ChangeValidateController',
                controllerAs: 'changeValidate',
                templateUrl: 'views/externalViews/changeValidate/template.html'
            });
}

export default routing;
