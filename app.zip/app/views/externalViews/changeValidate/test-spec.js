import ExternalViewsModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/externalViews/changeValidate/test-spec.js', function () {
  beforeEach(angular.mock.module(ExternalViewsModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicLoading = $injector.get('$ionicLoading');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;

    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('ChangeValidateController', {'$scope': this.$scope,
        'swagger': {
          api: {
            corresponsales: {
              cuestionario: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                },
                put: {
                  call: function () {
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));
  describe('changeValidate Controller', function () {
    it('checkConnection defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.checkConnection).toBeDefined();
    });
    it('checkConnection run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.checkConnection();
    });
    it('initLoad defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.initLoad();
    });
    it('initLoad defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.initLoad();
    });
    it('initLoad run with popup', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.data.popup = {close: function () {
          return false;
        }};
      expect(ChangeValidateController.initLoad()).toBeFalsy();
    });
    it('initLoad run without user', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.data.user = "";
      expect(ChangeValidateController.initLoad()).toBeFalsy();
    });
    it('initLoad run with user', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.data.user = "user";
      ChangeValidateController.initLoad();
    });
    it('getQuest defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.getQuest).toBeDefined();
    });
    it('getQuest run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.getQuest();
    });
    it('getQuest run with popup', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.getQuest()).toBeFalsy();
    });
    it('validateQuest defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.validateQuest).toBeDefined();
    });
    it('validateQuest run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.validateQuest();
    });
    it('validateQuest run with popup', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.validateQuest()).toBeFalsy();
    });
    it('validateQuest run completed quest', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.data.quest = [
        {
          text: "texto 1",
          id: 1,
          quest: "pregunta 1"
        },
        {
          text: "texto 2",
          id: 2,
          quest: "pregunta 2"
        }
      ]
      ChangeValidateController.validateQuest();
    });
    it('validateQuest run uncompleted quest', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.data.quest = [
        {
          text: ""
        },
        {
          text: "texto 2"
        }
      ]
      expect(ChangeValidateController.validateQuest()).toBeFalsy();
    });
    it('makeMask defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.makeMask).toBeDefined();
    });
    it('makeMask run', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.makeMask(5);
    });
    it('getPersistedUser defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.getPersistedUser).toBeDefined();
    });
    it('getPersistedUser run without persisted user', function () {
      var ChangeValidateController = this.createController();
      ChangeValidateController.getPersistedUser();
    });
    it('getPersistedUser run with persisted user', function () {
      var ChangeValidateController = this.createController();
      localStorage.setItem("persistUser", "corresponsal1");
      ChangeValidateController.getPersistedUser();
    });
    it('isPersisted defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.isPersisted).toBeDefined();
    });
    it('isPersisted run without persisted user', function () {
      var ChangeValidateController = this.createController();
      localStorage.removeItem("persistUser");
      expect(ChangeValidateController.isPersisted()).toBeFalsy();
    });
    it('isPersisted run with persisted user', function () {
      var ChangeValidateController = this.createController();
      localStorage.setItem("persistUser", "corresponsal1");
      expect(ChangeValidateController.isPersisted()).toBeTruthy();
    });
    it('cancelPersist defined', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.cancelPersist).toBeDefined();
    });
    it('cancelPersist run', function () {
      var ChangeValidateController = this.createController();
      expect(ChangeValidateController.cancelPersist()).toBeFalsy();
    });
  });
});