/**
 * Controlador de la vista de firstQuest
 */

ChangeValidateController.$inject = ['$ionicLoading', '$ionicPopup', '$state',  '$rootScope', 'swagger', '$scope'];

/**
 * @class corresponsales.changeValidate
 * @memberOf corresponsales
 * @desc vista de firstQuest
 * Controlador de la vista de firstQuest
 * @param $ionicPopup dependency dependencia para el uso de los popups emergentes en la vista de login
 * @param authFactory dependencia para la autentificación oauth
 * @param $http dependencia para el acceso http a servicio
 * @param $window acceso angular al objeto window
 * @param $ionicLoading para la gestión del spiner de loading
 * @param $state dependencia del objeto angular para la realización de navegación
 * @param $rootScope objeto que referencia el ambito global de la aplicación
 */
function ChangeValidateController($ionicLoading, $ionicPopup, $state, $rootScope, swagger, $scope) {
  let changeValidate = this;

  changeValidate.data = {
    popup: null,
    user: "",
    maskedUser: "",
    showQuest: false,
    selectedUser: false,
    quest: [
      {
        id: 1,
        quest: "Pregunta 1",
        text: ""
      },
      {
        id: 2,
        quest: "Pregunta 2",
        text: ""
      },
      {
        id: 3,
        quest: "Pregunta 3",
        text: ""
      }
    ]
  };

  changeValidate.texts = {
    disclaimer: "Para poder establecer una nueva contraseña, debe responder sus preguntas de desafío que obtendrá tras validar su nombre de usuario.",
    nextStep: "Siguiente >",
    user: "Usuario",
    changeUser: "Cambiar usuario >",
    info: "Información",
    ok: "Validar >",
    err001: "Debe introducir su nombre de usuario para poder obtener las preguntas de desafío.",
    err002: "Debe responder a todas las preguntas."
  };

  /**
   * @memberOf corresponsales.changeValidate
   * @name checkConnection
   * @type function
   * @description función que valida el acceso a red
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  changeValidate.checkConnection = () => {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  };

  changeValidate.initLoad = () => {
  };
  changeValidate.initLoad();

  changeValidate.getQuest = () => {
    if (!!changeValidate.data.popup) {
      changeValidate.data.popup.close();
      changeValidate.data.popup = null;
      return false;
    }
    if (changeValidate.data.user == "") {
      var alertPopup = $ionicPopup.alert({
        title: changeValidate.texts.info,
        template: changeValidate.texts.err001,
        okText: changeValidate.texts.ok,
      });
      changeValidate.data.popup = alertPopup;
      alertPopup.then(() => {
        changeValidate.data.popup = null;
      });
      return false;
    } else {
      changeValidate.data.selectedUser = true;
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }

      swagger.api.corresponsales.cuestionario.get.call({
        userId: changeValidate.data.user,
        udid: udid
      }).then((data) => {
        changeValidate.data.showQuest = true;
        changeValidate.data.quest = [];
        changeValidate.pushQuest(data);
        $ionicLoading.hide();
      }).catch((err) => {
        changeValidate.data.selectedUser = false;
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error en respuesta de servicio',
          tag: 'Obtener Cuestionario',
          data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
        });
        var alertPopup = $ionicPopup.alert({
          title: changeValidate.texts.info,
          template: err.data.message,
          okText: changeValidate.texts.ok,
        });
        changeValidate.data.popup = alertPopup;
        alertPopup.then(() => {
          changeValidate.data.popup = null;
        });

      });
    }
  };

  changeValidate.pushQuest = (data) => {
    for (let i = 0; i < data.data.length; i++) {
      var item = {
        id: data.data[i].id,
        quest: data.data[i].texto,
        text: ""
      };
      changeValidate.data.quest.push(item);
    }
  };

  changeValidate.validateQuest = () => {
    if (!!changeValidate.data.popup) {
      changeValidate.data.popup.close();
      changeValidate.data.popup = null;
      return false;
    }
    for (let i = 0; i < changeValidate.data.quest.length; i++) {
      if (changeValidate.data.quest[i].text == "") {
        var alertPopup = $ionicPopup.alert({
          title: changeValidate.texts.info,
          template: changeValidate.texts.err002,
          okText: changeValidate.texts.ok,
        });
        changeValidate.data.popup = alertPopup;
        alertPopup.then(() => {
          changeValidate.data.popup = null;
        });
        return false;
      }
    }

    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });

    var resp = [];
    for (let i = 0; i < changeValidate.data.quest.length; i++) {
      var item = {
        id: changeValidate.data.quest[i].id,
        texto: changeValidate.data.quest[i].quest,
        respuesta: changeValidate.data.quest[i].text
      };
      resp.push(item);
    }
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.cuestionario.put.call({
      respuestas: {
        udid: udid,
        respuestas: resp,
        userId: changeValidate.data.user
      }
    }).then((data) => {
      $ionicLoading.hide();
      var changeData = {
        udid: udid,
        userId: changeValidate.data.user,
        tokenSSO: data.data.tokenSSO
      };
      localStorage.setItem("bm-changeData", JSON.stringify(changeData));
      $state.go('changeOperate');
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Cuestionario',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: changeValidate.texts.info,
        template: err.data.message,
        okText: changeValidate.texts.ok,
      });
      changeValidate.data.popup = alertPopup;
      alertPopup.then(() => {
        changeValidate.data.popup = null;
      });

    });

  };

  changeValidate.makeMask = (num) => {
    var chain = "";
    for (let i = 0; i < num; i++) {
      chain = chain + '*';
    }
    return chain;
  };

  changeValidate.getPersistedUser = () => {
    let user = localStorage.getItem('persistUser');
    if (!!user) {
      let chars = 3;
      let chain = changeValidate.makeMask(user.length - chars);
      changeValidate.data.maskedUser = chain + user.substring(user.length - chars);
      changeValidate.data.user = user;
    }
  };

  changeValidate.isPersisted = () => {
    let user = localStorage.getItem('persistUser');
    if (!!user) {
      changeValidate.getPersistedUser();
      return true;
    } else {
      return false;
    }
  };

  changeValidate.cancelPersist = () => {
    localStorage.removeItem('persistUser');
    changeValidate.data.maskedUser = '';
    changeValidate.data.user = '';
    changeValidate.isPersisted();
  };

  $scope.goLogin = function() {
    var alertPopup = $ionicPopup.confirm({
      title: changeValidate.texts.info,
      template: '¿Está seguro de querer cancelar el proceso y perder todos los cambios no guardados?',
      okText: 'Si',
      cancelText: 'No',
    });
    changeValidate.data.popup = alertPopup;
    alertPopup.then((e) => {
      if (!!e) {
        $rootScope.$emit('metrics-custom', {
          event: 'Error en validación de preguntas de seguridad',
          tag: 'Preguntas',
          data: [{
            name: "msg",
            value: 'El usuario ha cerrado la pantalla de validación de preguntas de seguridad deliberadamente'
          }]
        });
        $state.go("login");
      } else {}
      changeValidate.data.popup = null;
    });
  };
}

export default ChangeValidateController;
