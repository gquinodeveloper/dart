import SetQuestController from './setQuest/controller';
import SetQuestRouting from './setQuest/routing';
import FirstQuestController from './firstQuest/controller';
import firstQuestRouting from './firstQuest/routing';
import ChangeValidateController from './changeValidate/controller';
import ChangeValidateRouting from './changeValidate/routing';
import ChangeOperateController from './changeOperate/controller';
import ChangeOperateRouting from './changeOperate/routing';

export default angular.module('ExternalViewsModule', [
  'ui.router',
  'ionic'
])

        .controller('SetQuestController', SetQuestController)
        .config(SetQuestRouting)
        .controller('FirstQuestController', FirstQuestController)
        .config(firstQuestRouting)
        .controller('ChangeValidateController', ChangeValidateController)
        .config(ChangeValidateRouting)
        .controller('ChangeOperateController', ChangeOperateController)
        .config(ChangeOperateRouting)

        .name;
