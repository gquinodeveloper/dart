/**
 * Controlador de la vista de login
 */

SetQuestController.$inject = ['$ionicLoading', '$ionicPopup', 'authFactory', '$state', 'swagger','$rootScope', '$scope'];

/**
 * @class corresponsales.setQuest
 * @memberOf corresponsales
 * @desc vista de login
 * Controlador de la vista de login
 * @param $ionicPopup dependency dependencia para el uso de los popups emergentes en la vista de login
 * @param authFactory dependencia para la autentificación oauth
 * @param $http dependencia para el acceso http a servicio
 * @param $window acceso angular al objeto window
 * @param $ionicLoading para la gestión del spiner de loading
 * @param $rootScope objeto que referencia el ambito global de la aplicación
 * @param $state dependencia del objeto angular para la realización de navegación
 */
function SetQuestController($ionicLoading, $ionicPopup, authFactory, $state, swagger, $rootScope, $scope) {
  let setQuest = this;
  setQuest.data = {
    qShowed: 1,
    quest: [],
    selected: [
      {
        value: -1,
        label: "Seleccione una pregunta"
      },
      {
        value: -1,
        label: "Seleccione una pregunta"
      },
      {
        value: -1,
        label: "Seleccione una pregunta"
      },
      {
        value: -1,
        label: "Seleccione una pregunta"
      },
      {
        value: -1,
        label: "Seleccione una pregunta"
      },
    ],
    answers: ["", "", "", "", ""],
    popup: null
  };
  setQuest.texts = {
    disclaimer: "Seleccione sus 5 preguntas de desafío e introduzca las respuestas. Estas preguntas serán utilizadas cada vez que cambie su contraseña para verificar su identidad.",
    continue: "Continuar >",
    info: "Información",
    ok: "Aceptar",
    err001: "Debe seleccionar y responder las 5 preguntas de desafío."
  };
  /**
   * @memberOf corresponsales.login
   * @name checkConnection
   * @type function
   * @description función que valida el acceso a red
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  setQuest.checkConnection = () => {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  };
  setQuest.initLoad = () => {
    $ionicLoading.show({
      template: '<ion-spinner icon="ripple"></ion-spinner>',
      hideOnStateChange: true
    });
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    swagger.api.corresponsales.preguntas.get.call({
      udid: udid
    }).then((data) => {
      $ionicLoading.hide();
      setQuest.data.quest = [];
      for (let i = 0; i < data.data.length; i++) {
        let item = {
          value: data.data[i].id,
          label: data.data[i].texto
        };
        setQuest.data.quest.push(item);
      }
    }).catch(() => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Preguntas',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
    });
  };
  setQuest.initLoad();

  setQuest.getQuest = (num) => {
    let quest = setQuest.data.quest;
    for (let i = 0; i <= num; i++) {
      for (let j = 0; j < quest.length; j++) {
        if (quest[j].value == setQuest.data.selected[i].value) {
          quest.splice(j, 1);
          j = quest.length;
        }
      }
    }
    return quest;
  };

  setQuest.nextStep = () => {
    console.log(setQuest.data);
    let next = true;
    if (!!setQuest.data.popup) {
      setQuest.data.popup.close();
      setQuest.data.popup = null;
      return false;
    }
    for (let i = 0; i < setQuest.data.answers.length; i++) {
      if (setQuest.data.answers[i] == "") {
        next = false;
      }
      if (setQuest.data.selected[i].value == -1) {
        next = false;
      }
    }
    if (!next) {
      var alertPopup = $ionicPopup.alert({
        title: setQuest.texts.info,
        template: setQuest.texts.err001,
        okText: setQuest.texts.ok,
      });
      setQuest.data.popup = alertPopup;
      alertPopup.then(() => {
        setQuest.data.popup = null;
      });
    } else {
      let quest = {
        questions: setQuest.data.selected,
        answers: setQuest.data.answers
      };
      localStorage.setItem('bm-quest', JSON.stringify(quest));
      $state.go('firstQuest');
    }
  };

  setQuest.isQuestionShowed = (num) => {
    var tot = 1;
    for (let i = 0; i < setQuest.data.answers.length; i++) {
      if (setQuest.data.answers[i] != "") {
        tot = tot + 1;
      }
    }
    if (tot >= setQuest.data.qShowed) {
      setQuest.data.qShowed = tot;
    }
    if (num < setQuest.data.qShowed) {
      return true;
    }
    return false;
  };

  $scope.deleteSelected = function(num){
    setQuest.data.selected[num].value = -1;
    setQuest.data.selected[num].label = "Seleccione una pregunta";
  };

  $scope.goLogin = function() {
    var alertPopup = $ionicPopup.confirm({
      title: setQuest.texts.info,
      template: '¿Está seguro de querer cancelar el proceso y perder todos los cambios no guardados?',
      okText: 'Si',
      cancelText: 'No',
    });
    setQuest.data.popup = alertPopup;
    alertPopup.then((e) => {
      if (!!e) {
        $rootScope.$emit('metrics-custom', {
          event: 'Error en introducción de nuevas preguntas de seguridad',
          tag: 'Preguntas',
          data: [{
            name: "msg",
            value: 'El usuario ha cerrado la pantalla de preguntas de seguridad deliberadamente'
          }]
        });
        $state.go("login");
      } else {}
      setQuest.data.popup = null;
    });
  };
}

export default SetQuestController;
