routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
            .state('setQuest', {
                url: '/setQuest',
                controller: 'SetQuestController',
                controllerAs: 'setQuest',
                templateUrl: 'views/externalViews/setQuest/template.html'
            });
}

export default routing;
