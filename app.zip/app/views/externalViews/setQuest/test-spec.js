import ExternalViewsModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/externalViews/setQuest/test-spec.js', function () {
  beforeEach(angular.mock.module(ExternalViewsModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicLoading = $injector.get('$ionicLoading');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;

    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('SetQuestController', {'$scope': this.$scope,
        'swagger': {
          api: {
            corresponsales: {
              preguntas: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('setQuest Controller', function () {
    it('checkConnection defined', function () {
      var SetQuestController = this.createController();
      expect(SetQuestController.checkConnection).toBeDefined();
    });
    it('checkConnection run', function () {
      var SetQuestController = this.createController();
      SetQuestController.checkConnection();
    });
    it('initLoad defined', function () {
      var SetQuestController = this.createController();
      expect(SetQuestController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var SetQuestController = this.createController();
      SetQuestController.initLoad();
    });
    it('getQuest defined', function () {
      var SetQuestController = this.createController();
      expect(SetQuestController.getQuest).toBeDefined();
    });
    it('getQuest run', function () {
      var SetQuestController = this.createController();
      SetQuestController.getQuest(2);
    });
    it('nextStep defined', function () {
      var SetQuestController = this.createController();
      expect(SetQuestController.nextStep).toBeDefined();
    });
    it('nextStep run', function () {
      var SetQuestController = this.createController();
      SetQuestController.nextStep();
    });
    it('nextStep run with popup', function () {
      var SetQuestController = this.createController();
      SetQuestController.data.popup = {close: function(){}};
      SetQuestController.nextStep();
    });
    it('isQuestionShowed defined', function () {
      var SetQuestController = this.createController();
      expect(SetQuestController.isQuestionShowed).toBeDefined();
    });
    it('isQuestionShowed run', function () {
      var SetQuestController = this.createController();
      SetQuestController.isQuestionShowed();
    });
  });
});