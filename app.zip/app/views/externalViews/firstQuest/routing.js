routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
            .state('firstQuest', {
                url: '/firstQuest',
                controller: 'FirstQuestController',
                controllerAs: 'firstQuest',
                templateUrl: 'views/externalViews/firstQuest/template.html'
            });
}

export default routing;
