/**
 * Controlador de la vista de firstQuest
 */

FirstQuestController.$inject = ['$ionicLoading', '$ionicPopup', 'authFactory', '$state', '$rootScope', 'swagger', '$scope'];

/**
 * @class corresponsales.firstQuest
 * @memberOf corresponsales
 * @desc vista de firstQuest
 * Controlador de la vista de firstQuest
 * @param $ionicPopup dependency dependencia para el uso de los popups emergentes en la vista de login
 * @param authFactory dependencia para la autentificación oauth
 * @param $http dependencia para el acceso http a servicio
 * @param $window acceso angular al objeto window
 * @param $ionicLoading para la gestión del spiner de loading
 * @param {object} $rootScope objeto que referencia el ambito global de la aplicación
 * @param $state dependencia del objeto angular para la realización de navegación
 */
function FirstQuestController($ionicLoading, $ionicPopup, authFactory, $state, $rootScope, swagger, $scope) {
  let firstQuest = this;

  firstQuest.data = {
    popup: null,
    pass: "",
    pass2: "",
    userId: ""
  };

  firstQuest.texts = {
    disclaimer: "Introduzca su nueva clave.",
    pass: "Clave",
    pass2: "Confirme su clave",
    continue: "Aceptar >",
    info: "Información",
    ok: "Aceptar",
    cancel: "Cancelar",
    err001: "Debe introducir y validar la misma clave en ambos campos.",
    err002: "La nueva contraseña ha de tener al menos 8 caracteres."
  };

  /**
   * @memberOf corresponsales.firstQuest
   * @name checkConnection
   * @type function
   * @description función que valida el acceso a red
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  firstQuest.checkConnection = () => {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  };

  firstQuest.initLoad = () => {
  };
  firstQuest.initLoad();

  firstQuest.doSave = () => {
    if (!!firstQuest.data.popup) {
      firstQuest.data.popup.close();
      firstQuest.data.popup = null;
      return false;
    }
    if (firstQuest.data.pass == "" || firstQuest.data.pass != firstQuest.data.pass2) {
      var alertPopup = $ionicPopup.alert({
        title: firstQuest.texts.info,
        template: firstQuest.texts.err001,
        okText: firstQuest.texts.ok,
      });
      firstQuest.data.popup = alertPopup;
      alertPopup.then(() => {
        firstQuest.data.popup = null;
      });
      return false;
    }
    if (firstQuest.data.pass.length < 8) {
      var alertPopup = $ionicPopup.alert({
        title: firstQuest.texts.info,
        template: firstQuest.texts.err002,
        okText: firstQuest.texts.ok,
      });
      firstQuest.data.popup = alertPopup;
      alertPopup.then(() => {
        firstQuest.data.popup = null;
      });
      return false;
    }
    var udid = "";
    try {
      if (device != undefined) {// eslint-disable-line
        udid = device.uuid;// eslint-disable-line
      }
    } catch (e) {
      //intentional
    }
    var quest = JSON.parse(localStorage.getItem('bm-quest'));
    var preguntas = [];
    for (let i = 0; i < quest.questions.length; i++) {
      let pregunta = {
        id: quest.questions[i].value,
        texto: quest.questions[i].label,
        respuesta: quest.answers[i]
      };
      preguntas.push(pregunta);
    }

    swagger.api.corresponsales.user.put.call({registro: {
        udid: udid,
        password: firstQuest.data.pass,
        preguntas: preguntas
      }}).then(() => {
      $ionicLoading.hide();
      $state.go("login");
      localStorage.removeItem('bm-quest');
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Primera pregunta',
        data: [{
          name: "msg",
          value: JSON.stringify(err)
        }]
      });
      var alertPopup = $ionicPopup.alert({
        title: firstQuest.texts.info,
        template: err.data.message,
        okText: firstQuest.texts.ok,
      });
      firstQuest.data.popup = alertPopup;
      alertPopup.then(() => {
        firstQuest.data.popup = null;
      });
    });
  };

  $scope.goLogin = function() {
    var alertPopup = $ionicPopup.confirm({
      title: firstQuest.texts.info,
      template: '¿Está seguro de querer cancelar el proceso y perder todos los cambios no guardados?',
      okText: 'Si',
      cancelText: 'No',
    });
    firstQuest.data.popup = alertPopup;
    alertPopup.then((e) => {
      if (!!e) {
        $rootScope.$emit('metrics-custom', {
          event: 'Error en introducción de nueva contraseña despues de añadir preguntas de seguridad',
          tag: 'Preguntas',
          data: [{
            name: "msg",
            value: 'El usuario ha cerrado la pantalla de nueva contraseña deliberadamente'
          }]
        });
        $state.go("login");
      }
      firstQuest.data.popup = null;
    });
  };
}

export default FirstQuestController;
