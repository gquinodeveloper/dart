import ExternalViewsModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/externalViews/firstQuest/test-spec.js', function () {
  beforeEach(angular.mock.module(ExternalViewsModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicLoading = $injector.get('$ionicLoading');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;

    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('FirstQuestController', {'$scope': this.$scope,
        'swagger': {
          api: {
            corresponsales: {
              cuestionario: {
                get: {
                  call: function () {
                    return $q.when();
                  }
                },
                put: {
                  call: function () {
                    return $q.when();
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('firstQuest Controller', function () {
    it('checkConnection defined', function () {
      var FirstQuestController = this.createController();
      expect(FirstQuestController.checkConnection).toBeDefined();
    });
    it('checkConnection run', function () {
      var FirstQuestController = this.createController();
      FirstQuestController.checkConnection();
    });
    it('initLoad defined', function () {
      var FirstQuestController = this.createController();
      expect(FirstQuestController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var FirstQuestController = this.createController();
      FirstQuestController.initLoad();
    });
    it('doSave defined', function () {
      var FirstQuestController = this.createController();
      expect(FirstQuestController.doSave).toBeDefined();
    });
    it('doSave run', function () {
      var FirstQuestController = this.createController();
      FirstQuestController.doSave();
    });
    it('doSave run with popup', function () {
      var FirstQuestController = this.createController();
      FirstQuestController.data.popup = {close: function(){return false;}};
      expect(FirstQuestController.doSave()).toBeFalsy();
    });
    it('doSave run with pass', function () {
      var FirstQuestController = this.createController();
      FirstQuestController.data.pass = "pass";
      FirstQuestController.doSave();
    });
  });
});