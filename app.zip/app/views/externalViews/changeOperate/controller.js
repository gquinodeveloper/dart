/**
 * Controlador de la vista de firstQuest
 */

ChangeOperateController.$inject = ['$ionicLoading', '$ionicPopup', '$state', '$rootScope', 'swagger', '$scope'];

/**
 * @class corresponsales.changeValidate
 * @memberOf corresponsales
 * @desc vista de firstQuest
 * Controlador de la vista de firstQuest
 * @param $ionicPopup dependency dependencia para el uso de los popups emergentes en la vista de login
 * @param $http dependencia para el acceso http a servicio
 * @param $window acceso angular al objeto window
 * @param $ionicLoading para la gestión del spiner de loading
 * @param $state dependencia del objeto angular para la realización de navegación
 * @param $rootScope objeto que referencia el ambito global de la aplicación
 */
function ChangeOperateController($ionicLoading, $ionicPopup, $state, $rootScope, swagger, $scope) {
  let changeOperate = this;

  changeOperate.data = {
    popup: null,
    pass: "",
    pass2: ""
  };

  changeOperate.texts = {
    disclaimer: "Introduzca su nueva clave.",
    pass: "Clave",
    pass2: "Confirme su clave",
    continue: "Aceptar >",
    info: "Información",
    ok: "Aceptar",
    success: "Su clave ha sido cambiada de forma satisfactoria. Desde ahora puede utilizar su nueva clave para acceder a la plataforma",
    err001: "Debe introducir y validar la misma clave en ambos campos.",
    err002: "No dispone de conexión a internet",
    err003: "La nueva contraseña ha de tener al menos 8 caracteres.",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde.",
    err005: "Se ha producido un error en el servidor"
  };

  /**
   * @memberOf corresponsales.changeValidate
   * @name checkConnection
   * @type function
   * @description función que valida el acceso a red
   * @return {boolean} true si hay red, false si no hay red o no hay acceso al objeto navegador
   */
  changeOperate.checkConnection = () => {
    if (!navigator || !navigator.onLine) {
      return false;
    }
    return navigator.onLine;
  };

  changeOperate.initLoad = () => {
  };
  changeOperate.initLoad();

  changeOperate.doSave = () => {
    if (!!changeOperate.data.popup) {
      changeOperate.data.popup.close();
      changeOperate.data.popup = null;
      return false;
    }
    if (changeOperate.data.pass == "" || changeOperate.data.pass != changeOperate.data.pass2) {
      var alertPopup = $ionicPopup.alert({
        title: changeOperate.texts.info,
        template: changeOperate.texts.err001,
        okText: changeOperate.texts.ok,
      });
      changeOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        changeOperate.data.popup = null;
      });
      return false;
    }
    if (changeOperate.data.pass.length < 8) {
      var alertPopup = $ionicPopup.alert({
        title: changeOperate.texts.info,
        template: changeOperate.texts.err003,
        okText: changeOperate.texts.ok,
      });
      changeOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        changeOperate.data.popup = null;
      });
      return false;
    }
    if (!changeOperate.checkConnection()) {
      var alertPopupNC = $ionicPopup.alert({
        title: changeOperate.texts.info,
        template: changeOperate.texts.err002,
        okText: changeOperate.texts.ok,
      });
      changeOperate.data.popup = alertPopupNC;
      alertPopupNC.then(() => {
        changeOperate.data.popup = null;
      });
    }

    var dto = JSON.parse(localStorage.getItem("bm-changeData"));
    dto.password = changeOperate.data.pass;

    swagger.api.corresponsales.password.put.call({
      changePasswordDTO: dto
    }).then(() => {
      $ionicLoading.hide();
      var alertPopup = $ionicPopup.alert({
        title: changeOperate.texts.info,
        template: changeOperate.texts.success,
        okText: changeOperate.texts.ok,
      });
      changeOperate.data.popup = alertPopup;
      alertPopup.then(() => {
        changeOperate.data.popup = null;
        $state.go("login");
      });
    }).catch((err) => {
      $ionicLoading.hide();
      $rootScope.$emit('metrics-custom', {
        event: 'Error en respuesta de servicio',
        tag: 'Password',
        data: [{
            name: "msg",
            value: JSON.stringify(err)
          }]
      });
      if (!err.data) {
        err.data = {
          message: changeOperate.texts.err004
        };
        var alertPopup = $ionicPopup.alert({
          title: changeOperate.texts.info,
          template: err.data.message,
          okText: changeOperate.texts.ok,
        });
        alertPopup.then(() => {
          changeOperate.data.popup = null;
          return false;
        });
      } else {
        if (!err.data.message) {
          err.data = {
            message: changeOperate.texts.err005
          };
        }
        var alertPopup = $ionicPopup.alert({
          title: changeOperate.texts.info,
          template: err.data.message,
          okText: changeOperate.texts.ok,
        });
        changeOperate.data.popup = alertPopup;
        alertPopup.then(() => {
          changeOperate.data.popup = null;
        });
      }
    });
  };

  $scope.goLogin = function() {
    var alertPopup = $ionicPopup.confirm({
      title: changeOperate.texts.info,
      template: '¿Está seguro de querer cancelar el proceso y perder todos los cambios no guardados?',
      okText: 'Si',
      cancelText: 'No',
    });
    changeOperate.data.popup = alertPopup;
    alertPopup.then((e) => {
      if (!!e) {
        $rootScope.$emit('metrics-custom', {
          event: 'Error en introducción de cambio de contraseña despues de validar preguntas de seguridad',
          tag: 'Preguntas',
          data: [{
            name: "msg",
            value: 'El usuario ha cerrado la pantalla de cambio de contraseña deliberadamente'
          }]
        });
        $state.go("login");
      }
      changeOperate.data.popup = null;
    });
  };
}

export default ChangeOperateController;
