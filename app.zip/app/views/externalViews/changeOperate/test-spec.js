import ExternalViewsModule from '../index';
import AuthModule from '../../../../node_modules/@atmira/fm-auth/index';

describe('app/views/externalViews/changeOperate/test-spec.js', function () {
  beforeEach(angular.mock.module(ExternalViewsModule));
  beforeEach(angular.mock.module(AuthModule));
  beforeEach(angular.mock.module('angular-swagger'));
  beforeEach(angular.mock.module('cacherModule'));

  beforeEach(inject(function ($injector) {
    this.$scope = $injector.get('$rootScope');
    this.$ionicLoading = $injector.get('$ionicLoading');
    this.$state = $injector.get('$state');
    this.authFactory = $injector.get('authFactory');
    this.swagger = $injector.get('swagger');
    this.$q = $injector.get('$q');
    var $q = this.$q;
    
    let $controller = $injector.get('$controller');
    this.createController = function () {
      return $controller('ChangeOperateController', {'$scope': this.$scope,
        'swagger': {
          api: {
            corresponsales: {
              password: {
                put: {
                  call: function () {
                    return $q.when()
                  }
                }
              }
            }
          }
        }
      });
    };
  }));

  beforeEach(inject(function ($state) {
    spyOn($state, 'go').and.callFake(function (state, params) {
    });
  }));

  describe('changeOperate Controller', function () {
    it('checkConnection defined', function () {
      var ChangeOperateController = this.createController();
      expect(ChangeOperateController.checkConnection).toBeDefined();
    });
    it('checkConnection run', function () {
      var ChangeOperateController = this.createController();
      ChangeOperateController.checkConnection();
    });
    it('initLoad defined', function () {
      var ChangeOperateController = this.createController();
      expect(ChangeOperateController.initLoad).toBeDefined();
    });
    it('initLoad run', function () {
      var ChangeOperateController = this.createController();
      ChangeOperateController.initLoad();
    });
    it('doSave defined', function () {
      var ChangeOperateController = this.createController();
      expect(ChangeOperateController.doSave).toBeDefined();
    });
    it('doSave run', function () {
      var ChangeOperateController = this.createController();
      ChangeOperateController.doSave();
    });
    it('doSave run without password', function () {
      var ChangeOperateController = this.createController();
      expect(ChangeOperateController.doSave()).toBeFalsy();  
    });
    it('doSave run with popup', function () {
      var ChangeOperateController = this.createController();
      ChangeOperateController.data.popup ={close: function(){return false}};
      expect(ChangeOperateController.doSave()).toBeFalsy();  
    });
    it('doSave run with password', function () {
      var ChangeOperateController = this.createController();
      ChangeOperateController.data.pass = "pass";
      ChangeOperateController.doSave();
    });    
  });
});