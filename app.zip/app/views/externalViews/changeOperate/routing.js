routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
            .state('changeOperate', {
                url: '/changeOperate',
                controller: 'ChangeOperateController',
                controllerAs: 'changeOperate',
                templateUrl: 'views/externalViews/changeOperate/template.html'
            });
}

export default routing;
