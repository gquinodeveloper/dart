routing.$inject = ['$stateProvider', '$urlRouterProvider'];

function routing($stateProvider) {

    $stateProvider
    .state('menu.newPassword', {
            url: '/newPassword',
            abstract: false,
            views: {
              'menuContent': {
                templateUrl: 'views/profile/newPassword/template.html',
                controllerAs: 'newPassword',
                controller: "NewPasswordController"
              }
            }
          });
}

export default routing;
