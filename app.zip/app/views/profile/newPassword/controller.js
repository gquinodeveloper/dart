NewPasswordController.$inject = ['menuActive', 'swagger', '$ionicLoading', '$state', '$ionicPopup', '$scope', '$rootScope'];

function NewPasswordController(menuActive, swagger, $ionicLoading, $state, $ionicPopup, $scope, $rootScope) {
  let newPassword = this;
  menuActive.active = 3;
  newPassword.data = {
    pass: "",
    rePass: "",
    userCode: localStorage.getItem('persistUser'),
    cbName: JSON.parse(localStorage.getItem('bm-configuracion')).cabecera.nombre
  };

  newPassword.texts = {
    title: "Ajustes",
    titleChangePass: "Cambio de contraseña",
    titleManual: "Manual de ayuda",
    userCode: "Código de usuario: ",
    cbName: "Nombre de corresponsal: ",
    pass: "Digite la nueva contraseña",
    rePass: "Repita la nueva contraseña",
    diffPass: "Las dos contraseñas no coinciden",
    shortPass: "La contraseña ha de tener al menos 8 caracteres",
    success: "Su contraseña ha sido cambiada con éxito. Va a ser redirigido a la página de acceso",
    info: "Información",
    save: "Guardar",
    pdf: "Abrir manual",
    ok: "Aceptar",
    cancel: "Cancelar",
    err001: "Se ha producido un error en el servidor",
    err004: "Se ha producido un error en la conexión. Vuelva a intentarlo más tarde."
  };

  newPassword.initLoad = () => {
    $scope.$emit("titleChange", newPassword.texts.title);
  };
  newPassword.initLoad();

  newPassword.doNavigate = (path) => {
    $state.go(path);
  };

  newPassword.doSave = () => {
    if (newPassword.data.pass != newPassword.data.rePass) {
      var alertPopup = $ionicPopup.alert({
        title: newPassword.texts.info,
        template: newPassword.texts.diffPass,
        okText: newPassword.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    } else if (newPassword.data.pass.length < 8) {
      var alertPopup = $ionicPopup.alert({
        title: newPassword.texts.info,
        template: newPassword.texts.shortPass,
        okText: newPassword.texts.ok,
      });
      alertPopup.then(() => {
        return false;
      });
      return false;
    } else {
      $ionicLoading.show({
        template: '<ion-spinner icon="ripple"></ion-spinner>',
        hideOnStateChange: true
      });
      var udid = "";
      try {
        if (device != undefined) {// eslint-disable-line
          udid = device.uuid;// eslint-disable-line
        }
      } catch (e) {
        //intentional
      }
      swagger.api.corresponsales.newPassword.put.call({newPasswordDTO: {
          udid: udid,
          password: newPassword.data.pass
        }
      }).then(() => {
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
          title: newPassword.texts.info,
          template: newPassword.texts.success,
          okText: newPassword.texts.ok,
        });
        alertPopup.then(() => {
          newPassword.doNavigate('login');
        });
      }).catch((err) => {
        $ionicLoading.hide();
        $rootScope.$emit('metrics-custom', {
          event: 'Error en respuesta de servicio',
          tag: 'Password',
          data: [{
              name: "msg",
              value: JSON.stringify(err)
            }]
        });
        if (!err.data) {
          err.data = {
            message: newPassword.texts.err004
          };
          var alertPopup = $ionicPopup.alert({
            title: newPassword.texts.info,
            template: err.data.message,
            okText: newPassword.texts.ok,
          });
          alertPopup.then(() => {
            $state.go("menu.homeUser");
            return false;
          });
        } else {
          if (!err.data.message) {
            err.data = {
              message: newPassword.texts.err001
            };
          }
          var alertPopup = $ionicPopup.alert({
            title: newPassword.texts.info,
            template: err.data.message,
            okText: newPassword.texts.ok,
          });
          alertPopup.then(() => {
            return false;
          });
        }
        return false;
      });
    }
  };

  newPassword.openPdf = () =>{

    var permissions = cordova.plugins.permissions;
    permissions.checkPermission(permissions.READ_EXTERNAL_STORAGE, function(status) {
      if (!status.hasPermission) {
        permissions.requestPermission(
          permissions.READ_EXTERNAL_STORAGE,
          function(statusperm) {
            if(statusperm.hasPermission) {
              let url = 'www/public/docs/Manual-Operativo-Corresponsales-Bancarios.pdf';
              window.resolveLocalFileSystemURL(cordova.file.applicationDirectory +  url, function(fileEntry) {
                window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function(dirEntry) {
                  fileEntry.copyTo(dirEntry, url.split('/').pop(), function(newFileEntry) {
                    window.open(newFileEntry.nativeURL, '_system');
                  }, function(err){
                    console.log('fileEntry.copyTo error', err);
                  });
                }, function(err) {
                  console.log('resolveLocalFileSystemURL error', err);
                });
              }, function(err) {
                console.log('resolveLocalFileSystemURL error', err);
              });
            }
          },
          function(errorpermisos) {
            console.log("Error al obtener permiso al storage " + errorpermisos);
          }
        );
      } else {
        let url = 'www/public/docs/Manual-Operativo-Corresponsales-Bancarios.pdf';
        window.resolveLocalFileSystemURL(cordova.file.applicationDirectory +  url, function(fileEntry) {
          window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, function(dirEntry) {
            fileEntry.copyTo(dirEntry, url.split('/').pop(), function(newFileEntry) {
              window.open(newFileEntry.nativeURL, '_system');
            }, function(err){
              console.log('fileEntry.copyTo error', err);
            });
          }, function(err) {
            console.log('resolveLocalFileSystemURL error', err);
          });
        }, function(err) {
          console.log('resolveLocalFileSystemURL error', err);
        });
      }
    }, null);
  };
}

export default NewPasswordController;
