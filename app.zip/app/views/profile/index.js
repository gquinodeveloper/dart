import NewPasswordController from './newPassword/controller';
import NewPasswordRouting from './newPassword/routing';
export default angular.module('profileModule', [
  'ui.router',
  'ionic'
])
        .controller('NewPasswordController', NewPasswordController)
        .config(NewPasswordRouting)

        .name;
