import mensajeriaRouting from './mensajeria-routing';
import MensajeriaController from './mensajeria-controller';

export default angular.module('MensajeriaModule', [])
  .controller('MensajeriaController', MensajeriaController)
  .config(mensajeriaRouting)
  .name;
