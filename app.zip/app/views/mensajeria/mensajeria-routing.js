routing.$inject = ['$stateProvider'];

function routing($stateProvider) {

  $stateProvider
    .state('mensajeria', {
      url: '/mensajeria',
      controller  : 'MensajeriaController',
      controllerAs: 'mensajeria',
      templateUrl: 'views/mensajeria/mensajeria-template.html'
    });
}

export default routing;
