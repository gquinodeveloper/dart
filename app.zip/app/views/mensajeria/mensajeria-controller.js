/* eslint-disable */
MensajeriaController.$inject = ['$scope', 'mensajeriaService', 'swagger'];

import uuidV4 from 'uuid/v4';
import utils from '../../commons/utilidades/utils.download';

function MensajeriaController($scope, mensajeriaService, swagger) {
  let mensajeria = this;
  let aux = {
    client: null
  };
  mensajeria.nuevoContacto = (jid, client = aux.client) => {
    mensajeriaService.nuevoContacto(client, jid);
    getContactos();
  };
  mensajeria.fillUserPass = (user, pass) => {
    mensajeria.inputUser     = user;
    mensajeria.inputPassword = pass;
  };
  mensajeria.getContactos = (client = aux.client) => {
    mensajeriaService.getContactos(client, (data) => {
      mensajeria.contactos = data.roster.roster.items;
      getUsersTokens(data.roster.roster.items, mensajeria.contactos);
    });
  };
  mensajeria.getUsersTokens = (users, contactos) =>{
    // data.roster.roster.items[0].jid.local
    let locals = [];
    users.forEach(user => {
      locals.push({id: user.jid.local});
    });
    swagger.api.s3.mongoose.users.post.call({users: locals})
      .then(tokens => {
        tokens.data.forEach(token => {
          contactos.forEach(contacto => {
            if (contacto.jid.local === token.user) contacto.jid.device = token.device || '';
          });
        });
      })
      .catch(err => {
        throw err;
      });
  };
  mensajeria.iniciarSesion = (jid = mensajeria.inputUser, password = mensajeria.inputPassword) => {
    let conf   = {
      jid      : jid,
      transport: 'websocket',
      wsURL    : 'ws://52.213.132.189:5280/ws-xmpp'
    };
    aux.client = mensajeriaService.init(
      conf,
      mensajeria.sessionStartedCb,
      mensajeria.chatCb
    );
  };
  mensajeria.finalizarSesion = (client = aux.client) => {
    mensajeriaService.disconnect(client);
  };
  mensajeria.chatCb = (chat) => {
    console.log("chat");
    console.log(chat);
    let chatParsed;
    try{
      chatParsed = JSON.parse(chat.body);
    }catch(e){
      throw e;
    }
    if (chatParsed.fileName) {
      chatParsed.body = 'Te ha enviado un fichero';
      mensajeria.fileChat.push({
        fileUrl : chatParsed.fileUrl,
        fileName: chatParsed.fileName
      });
    }
//    mensajeria.chat.push({
//      body: chatParsed.body,
//      user: chat.from.bare
//    });
    $scope.$apply();
  };
  mensajeria.sessionStartedCb = ({jid, roster, presenceId}) => {
    mensajeria.loginAs   = jid.bare;
    mensajeria.contactos = roster.roster.items;
    $scope.$apply();
  };
  mensajeria.enviarMsg = (user, body = {body: mensajeria.inputMsg}, client = aux.client) => {
    let users = {
      ISMAEL: '02101017206@localhost',
      ROMAN : '02101534151@localhost'
    };
    // add device token to msg
    body.device = getDeviceForUser(users[user]);
    mensajeriaService.sendMessage({
      to    : users[user],
      body  : JSON.stringify(body),
      client: client
    });
  };
  mensajeria.getDeviceForUser = (user) => {
    let finded = mensajeria.contactos.find(current => {
      return user === current.jid.bare;
    });
    if (finded && finded.jid && finded.jid.device) return finded.jid.device;
    return '';
  };
}

export default MensajeriaController;


/*
mensajeriaController.$inject = ['$scope', '$http', '$q', 'mensajeriaService', 'swagger'];
import uuidV4 from 'uuid/v4';
import utils from '../../commons/utilidades/utils.download';
function mensajeriaController($scope, $http, $q, mensajeriaService, swagger) {
  let vm = this;
  vm.loginAs       = ' - ';
  vm.inputMsg      = '';
  vm.inputContacto = '';
  vm.contactos     = [];
  vm.chat          = [];
  vm.fileChat      = [];
  vm.selectedUserIsmael = fillUserPass;
  vm.iniciarSesion      = iniciarSesion;
  vm.finalizarSesion    = finalizarSesion;
  vm.enviarMsg          = enviarMsg;
  vm.nuevoContacto      = nuevoContacto;
  vm.getContactos       = getContactos;
  vm.fileHandler        = fileHandler;
  vm.getFileByUrl       = getFileByUrl;
  let aux = {
    client: null
  };
  function nuevoContacto(jid, client = aux.client) {
    mensajeriaService.nuevoContacto(client, jid);
    getContactos();
  }
  function fillUserPass(user, pass) {
    vm.inputUser     = user;
    vm.inputPassword = pass;
  }
  function getContactos(client = aux.client) {
    mensajeriaService.getContactos(client, (data) => {
      vm.contactos = data.roster.roster.items;
      getUsersTokens(data.roster.roster.items, vm.contactos);
    });
  }
  function getUsersTokens(users, contactos) {
    // data.roster.roster.items[0].jid.local
    let locals = [];
    users.forEach(user => {
      locals.push({id: user.jid.local});
    });
    swagger.api.s3.mongoose.users.post.call({users: locals})
      .then(tokens => {
        tokens.data.forEach(token => {
          contactos.forEach(contacto => {
            if (contacto.jid.local === token.user) contacto.jid.device = token.device || '';
          });
        });
      })
      .catch(err => {
        throw err;
      });
  }
  function iniciarSesion(jid = vm.inputUser, password = vm.inputPassword) {
    let conf   = {
      jid      : jid,
      password : password,
      transport: 'websocket',
      wsURL    : 'ws://52.213.132.189:5280/ws-xmpp'
    };
    aux.client = mensajeriaService.init(
      conf,
      sessionStartedCb,
      chatCb
    );
  }
  function finalizarSesion(client = aux.client) {
    mensajeriaService.disconnect(client);
  }
  function chatCb(chat) {
    let chatParsed;
    try{
      chatParsed = JSON.parse(chat.body);
    }catch(e){
      throw e;
    }
    if (chatParsed.fileName) {
      chatParsed.body = 'Te ha enviado un fichero';
      vm.fileChat.push({
        fileUrl : chatParsed.fileUrl,
        fileName: chatParsed.fileName
      });
    }
    vm.chat.push({
      body: chatParsed.body,
      user: chat.from.bare
    });
    $scope.$apply();
  }
  function getFileByUrl({fileName, fileUrl}) {
    $http({
      method: 'GET',
      url   : fileUrl
    })
      .then(response => {
        descargarFichero(fileName, response.data);
      })
      .catch(err => {
        console.log(err);
      });
  }
  function sessionStartedCb({jid, roster, presenceId}) {
    vm.loginAs   = jid.bare;
    vm.contactos = roster.roster.items;
    $scope.$apply();
  }
  function enviarMsg(user, body = {body: vm.inputMsg}, client = aux.client) {
    let users = {
      ISMAEL: '02101017206@localhost',
      ROMAN : '02101534151@localhost'
    };
    // add device token to msg
    body.device = getDeviceForUser(users[user]);
    mensajeriaService.sendMessage({
      to    : users[user],
      body  : JSON.stringify(body),
      client: client
    });
  }
  function fileHandler(user) {
    let file     = document.getElementById('file').files[0];
    let fileName = `${uuidV4()}_${file.name}`;
    let reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.addEventListener("load", function () {
      getUploadUrl(fileName)
        .then(url => {
          uploadFile(url, reader.result).then(() => {
            getDownloadUrl(fileName)
              .then(downloadUrl => {
                enviarMsg(user, {
                  body    : '',
                  fileName: file.name,
                  fileUrl : downloadUrl
                });
              })
              .catch(err => console.log(err));
          })
            .catch(err => console.log(err));
        })
        .catch(err => console.log(err));
    }, false);
  }
  function getDeviceForUser(user) {
    let finded = vm.contactos.find(current => {
      return user === current.jid.bare;
    });
    if (finded && finded.jid && finded.jid.device) return finded.jid.device;
    return '';
  }
  function getUploadUrl(fileName) {
    return new $q((response, reject) => {
      swagger.api.s3.signUploadUrl.get.call({fileName: fileName})
        .then(data => response(data.data.url))
        .catch(err => reject(err));
    });
  }
  function uploadFile(url, data) {
    return $http({
      url    : url,
      method : "PUT",
      data   : data,
      headers: {'Content-Type': undefined}
    });
  }
  function getDownloadUrl(fileName) {
    return new $q((response, reject) => {
      swagger.api.s3.signDownloadUrl.get.call({fileName: fileName})
        .then(data => response(data.data.url))
        .catch(err => reject(err));
    });
  }
  function descargarFichero(fileName, binaryData) {
    utils.downloadFileByString(fileName, binaryData);
  }
}
export default mensajeriaController;*/