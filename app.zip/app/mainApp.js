// configuration
import routing from './configuration/routing/routing';
//import routingEvents from './configuration/routing/routing-events-run';
import cordovaRun from './configuration/cordovaRun';
import logConfig from './configuration/loger-config';
import ionicCacheConfig from './configuration/ionic-cache';
import ionicWhitelistConfig from './configuration/ionic-whitelist';
import msjService from './configuration/mensajeria/msjService';
import printerService from './configuration/printer/printer-factory';
import reversionService from './configuration/reversion/reversion-factory';
import dukptService from './configuration/dukpt/dukpt-factory';
import txFailureService from './configuration/txFailure/txFailure-factory';
import privateIpService from './configuration/private-ip/private-ip-factory';
import cyptojsService from './configuration/cryptojs/cryptojs-factory';

// commons
// import comboIdioma from './commons/combo-translate';
import multilineSelector from './commons/multiline-selector';
import onScrollToBottom from './commons/scroll-bottom';
import formatedNumberInput from './commons/formated-number-input';
import formatedDecimalInput from './commons/formated-decimal-input';
import switcher from './commons/switcher';
import fileService from './commons/file-service';

// views
import LoginModule from './views/login';
import ExternalViewsModule from './views/externalViews';
import MenuModule from './views/menu';
import CustomerModule from './views/customer';
import UserModule from './views/user';
import profileModule from './views/profile';

import MensajeriaModule from './views/mensajeria';

export default angular.module('App', [
  // librerias externas
  'ngAria',
  'ngAnimate',
  'ngSanitize',
  'ui.router',
  'ionic',

  // config module created in app.js
  'configModule',

  // librerias externas propias
  'cacherModule',
  'angular-swagger',
  'angular-lingua',
  'AuthModule',
  'angular-metrics',

  // Librerias de terceros
  'angucomplete-alt',

  // commons
  // comboIdioma,
  multilineSelector,
  formatedNumberInput,
  formatedDecimalInput,
  switcher,
  fileService,
  onScrollToBottom,

  // views
  LoginModule,
  ExternalViewsModule,
  MenuModule,
  CustomerModule,
  UserModule,
  profileModule,

  MensajeriaModule
])

  .config(routing)
  .config(logConfig)
  .config(ionicCacheConfig)
  .config(ionicWhitelistConfig)

  .config(function ($provide, $httpProvider) {    
    $provide.factory('firebaseInterceptor', function ($q) {
      return {
        request: function (config) {
          var regex = /firebasedynamiclinks\.googleapis\.com/i;
          if(regex.test(config.url)) {
            config.headers = {
              'Authorization' : undefined
            };
          }

          return config || $q.when(config);
        },
      };
    });

    $httpProvider.interceptors.push('firebaseInterceptor');
  
  })

  .factory('msjService', msjService)
  .factory('printerService', printerService)
  .factory('reversionService', reversionService)
  .factory('dukptService', dukptService)
  .factory('txFailureService', txFailureService)
  .factory('privateIpService', privateIpService)
  .factory('cyptojsService', cyptojsService)
  .factory('menuActive', function () {
    return {active: 1};
  })

  .run(cordovaRun)
  //.run(routingEvents)


  .name;
