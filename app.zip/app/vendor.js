require('angular');
require('angular-animate');
require('angular-sanitize');
require('angular-resource');
require('angular-aria');
require('angular-ui-router');
require('angular-mocks');
require('ng-idle');
require('./public/js/vendor/ionic');
require('./public/js/vendor/ionic-angular');
require('ngstorage');

require('@atmira/angular-cacher');
require('@atmira/angular-swagger');
require('@atmira/fm-auth');
require('@atmira/angular-lingua');
require('@atmira/angular-metrics');
