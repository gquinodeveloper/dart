require('file-saver');

import fileSaver from 'file-saver';


function downloadB64(name, base64String) {
  let byteString = atob(base64String);

  downloadFileByString(name, byteString);
}

function downloadFileByString(name, byteString) {
  let ab = new ArrayBuffer(byteString.length);
  let ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }

  let blob = new Blob([ia]);

  fileSaver.saveAs(blob, name);
}

export default {
  downloadB64         : downloadB64,
  downloadFileByString: downloadFileByString,
};