import utils from './utils';

export default angular.module('utilsModule', [])
  .factory('utils', utils)
  .name;