/* eslint-disable */

// import downloadUtils from './utils.download';


utils.$inject = ['$window', /*'Upload'*/];

function utils($window) {
  let result = {
    urlBase64Decode: urlBase64Decode,
    date           : {
      isValidDate : isValidDate,
      parseUTCDate: parseUTCDate
    },
    isObject       : isObject
  };

  // Descomentar para obtener las funciones de descarga
  // angular.extend(result, downloadUtils);

  function isValidDate(dateObject) {
    let correcto = false;
    if (Object.prototype.toString.call(dateObject) === '[object Date]') {
      if (!isNaN(dateObject.getTime())) {
        correcto = true;
      }
    }

    return correcto;
  }

  function parseUTCDate(timestamp) {
    let parsedDate = timestamp;
    if (timestamp) {
      let MILISECONDS_PER_MINUTE = 60000;
      let fecha                  = new Date(timestamp);
      let diffInMilliseconds     = fecha.getTimezoneOffset() * -MILISECONDS_PER_MINUTE;
      parsedDate                 = fecha.getTime() + diffInMilliseconds;
    }
    return parsedDate;
  }

  /**
   * @description Descifra un string que este en base 64
   * @function urlBase64Decode
   * @param {String} str String codificado en base 64
   * @returns {string}
   * @example
   * urlBase64Decode('gflkknglskg3421klddjk414rkjkdf...');
   */
  function urlBase64Decode(str) {
    let output = str.replace('-', '+').replace('_', '/');
    switch (output.length % 4) {
      case 0:
        break;
      case 2:
        output += '==';
        break;
      case 3:
        output += '=';
        break;
      default:
        throw 'Illegal base64url string!';
    }

    return decodeURIComponent($window.escape($window.atob(output)));
  }

  function isObject(obj) {
    return Object.prototype.toString.call(obj) === '[object Object]';
  }

  return result;
}


export default utils;

