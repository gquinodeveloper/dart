comboIdioma.$inject = ['translate'];

function comboIdioma(translate) {

  return {
    restrict    : 'E',
    replace     : true,
    templateUrl : 'commons/combo-translate/combo-translate.html',
    scope       : true,
    controller  : function ($scope) {
      let comboIdioma = this;

      let prefix = 'IDIOMA.';

      comboIdioma.idiomasArray = null;
      comboIdioma.idiomaActual = null;

      comboIdioma.cambiarIdioma = cambiarIdioma;

      function cambiarIdioma() {
        translate.actualLang(comboIdioma.idiomaActual);
      }

      /////
      init();

      function init() {
        let languages = translate.getLanguages();
        let langs     = [];
        languages.forEach(lang => {
          langs.push({
            text : [prefix, lang.toUpperCase()].join(''),
            value: lang
          });
        });

        comboIdioma.idiomasArray = langs;
        comboIdioma.idiomaActual = translate.actualLang();
      }

      // escucho el evento de cambiar idioma pq al iniciar la aplicación si tiene que consultar un
      // idioma de forma asincrona no se actualiza el combo
      let unregisterTranslateChangeSuccess = $scope.$root.$on('$translateLoadingSuccess', (ev, lang)=>{
        comboIdioma.idiomaActual = lang.language;
      });

      $scope.$on('$destroy', ()=>{
        unregisterTranslateChangeSuccess();
      });

    },
    controllerAs: 'comboIdioma'
  };
}

export default angular.module('comboIdioma', [])
  .directive('comboIdioma', comboIdioma)
  .name;