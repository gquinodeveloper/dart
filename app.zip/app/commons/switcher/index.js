export default angular.module('switcher', [])
        .directive('switcher', switcher)
        .name;
switcher.$inject = [];
function switcher() {
  return {
    restrict: 'A',
    scope: {
      switchOn: '=',
      switchOff: '=',
      switchValue: '=',
    },
    template: `
            <span ng-click="switchValue = !switchValue">{{switchOn}}</span>
            <div ng-click="switchValue = !switchValue" class="{{switchValue ? 'switch-tracker-on' : 'switch-tracker-off'}}"></div>
            <span ng-click="switchValue = !switchValue">{{switchOff}}</span>
          `
  };
}