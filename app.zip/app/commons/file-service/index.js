import fileService from './file-service';

export default angular.module('fileModule', [])
  .factory('fileService', fileService)
  .name;
