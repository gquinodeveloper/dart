fileService.$inject = ['$window'];

function fileService($window) {
  var service = {
    scanDirectory: function(path, success, error) {
      if ($window.cordova.file === undefined) {
        console.log("fileService.scanDirectory: cordova-plugin-file is not present");
        return;
      }
      window.resolveLocalFileSystemURL(path,
        (fileSystem) => {
          var reader = fileSystem.createReader();
          reader.readEntries(success, error);
        },
        (err) => {
          console.log(err);
        }
      );
    },
    readFile: function(path, callback) {
      if ($window.cordova.file === undefined) {
        console.log("fileService.readFile: cordova-plugin-file is not present");
        return;
      }
      window.resolveLocalFileSystemURL(path,
        (fileEntry) => {
          fileEntry.file(
            (file) => {
              var reader = new FileReader();
              reader.onloadend = (evt) => {
                  callback.call(this, evt.target.result);
              };
              reader.readAsDataURL(file);
          }, (errorReading) => {
            console.log(errorReading);
          });
        },
        (errorResolving) => {
          console.log(errorResolving);
        }
      );
    }
  };

  return service;
}

export default fileService;
