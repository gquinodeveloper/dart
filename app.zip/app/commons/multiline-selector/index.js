export default angular.module('multilineSelector', [])
        .directive('multilineSelector', multilineSelector)
        .name;

multilineSelector.$inject = ['$document', '$timeout'];

function multilineSelector($document, $timeout) {
  return {
    restrict: 'A',
    scope: {
      msValue: '=msValue',
      msModel: '=',
    },
    template: `<div class="ms-container" ng-click="msDeploy = !msDeploy" ng-blur="msBlur()">
                <div class="ms-header">
                  <div class="ms-selected ellipsis">{{msValue.label}}</div>
                  <div class="ms-arrow"><i class="icon {{!msDeploy ? 'ion-ios-arrow-down' : 'ion-ios-arrow-up'}}"></i></div>
                </div>
                  <div class="ms-body" ng-if="!!msDeploy">
                  <div class="ms-item" ng-repeat="item in msModel" ng-click="selectItem(item)">
                    {{item.label}}
                  </div>
                </div>
              </div>`
    ,
    controller: function ($scope, $element) {
      $scope.selectItem = (item) => {
        $scope.msValue = item;
      };
      $scope.msBlur = () => {
        $timeout(() => {
          $scope.msDeploy = false;
        }, 250 );
      };
      $element.bind('click', (event) => {
        $element[0].style.width = $element[0].scrollWidth+'px';
        event.stopPropagation();
      });
      $document.bind('click', (event) => {
        var isClickedElementChildOfSelector = $element
                .find(event.target)
                .length > 0;
        if (!isClickedElementChildOfSelector) {
          $scope.$apply(() => {
            $scope.msDeploy = false;
          });
        }
      });
    }
  };
}