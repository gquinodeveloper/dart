export default angular.module('onScrollToBottom', [])
        .directive('onScrollToBottom', onScrollToBottom)
        .name;

onScrollToBottom.$inject = [];

function onScrollToBottom() {
  return {
    restrict: 'A',    
    link: function (scope, element, attrs) {
        var raw = element[0];         
        element.bind('scroll', function () {               
            if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) { //at the bottom                 
                 scope.operations.data.directiveScrollBottom = false;
            }else{
                 scope.operations.data.directiveScrollBottom = true;                    
            }
            scope.$apply(attrs.onScrollToBottom);
        });
    }    
  };
}