export default angular.module('formatedNumberInput', [])
        .directive('formatedNumberInput', formatedNumberInput)
        .name;
formatedNumberInput.$inject = [];
function formatedNumberInput() {
  return {
    restrict: 'A',
    scope: {
      numberModel: '=',
      disabled: '=',
    },
    template: `
          <input type="number" ng-model="numberModel" ng-keydown="keydown($event)" min="0" ng-disabled="!!disabled"/>{{!!numberModel ? (numberModel | number:2) : '0'}}`,
    controller: function ($scope) {
      $scope.keydown = (e) => {
        let keys = '01234567890,';
        if (keys.indexOf(e.key) == -1 && e.keyCode != 8 && e.keyCode != 13) { //exclude 13 (intro / submit) key
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
        if (e.key == '.' || e.key == ',') {
          if (($scope.numberModel + "").indexOf('.') > 0 && e.keyCode != 8) {
            e.preventDefault();
            e.stopPropagation();
            return false;
          } else {
            if (e.key == '.') {
              e.preventDefault();
              e.stopPropagation();
              $scope.numberModel=$scope.numberModel + ",";
            return false;
            }
          }
        }
      };
    }
  };
}